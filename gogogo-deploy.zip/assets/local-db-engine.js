/**
 * GoGoGo SuperApp — Dual-Mode Autonomous Database Engine
 * ------------------------------------------------------
 * Mode 1 (Default): LocalDB Engine (100% Mandiri di Browser / IndexedDB & LocalStorage)
 *   - Mengimplementasikan seluruh 34 Tabel + 52 Fungsi RPC Supabase + Auth + Storage + Realtime
 *   - 100% Terputus dari server pemilik asli (tidak ada trafik ke database pemilik asli)
 *   - Bisa login dengan email apa saja (termasuk email Anda sendiri)
 *   - Akun Anda otomatis memiliki akses Multi-Role: Pelanggan, Kurir, Restoran/Mart, & Super Admin
 *
 * Mode 2: Custom Supabase Cloud (Database Supabase Milik Anda Sendiri)
 *   - Masukkan SUPABASE_URL dan SUPABASE_ANON_KEY proyek Supabase gratis Anda melalui Panel Kontrol
 */
(function () {
  // ============================================================================
  // KONFIGURASI LAUNCHING PRODUKSI (GOGOGO SUPERAPP)
  // ============================================================================
  const LAUNCH_CONFIG = {
    // 1. Project URL & API Key dari Dashboard Supabase Anda:
    SUPABASE_URL: 'https://ugigyjrmmtsegpfjkjea.supabase.co',
    SUPABASE_ANON_KEY: 'sb_publishable_D4Z1RCxpQnt72loSXcs6gA_JqQVD4ib',

    // 2. Ubah ke true saat aplikasi sudah disebar ke pelanggan umum.
    //    Jika true, tombol melayang "Panel GoGoGo" disembunyikan dari publik
    //    (Anda tetap bisa membukanya kapan saja via URL /?panel=1 atau tekan Ctrl + Shift + G)
    PRODUCTION_PUBLIC_MODE: true
  };

  const STORAGE_KEY = 'gogogo_clone_db_v5';
  const SESSION_KEY = 'gogogo_clone_session_v5';
  const CONFIG_KEY = 'gogogo_custom_supabase_config_v1';
  const ROLE_CONFIG_KEY = 'gogogo_active_roles_v1';

  const nowIso = () => new Date().toISOString();
  const hoursAgoIso = (h) => new Date(Date.now() - h * 3600 * 1000).toISOString();
  const daysAgoIso = (d) => new Date(Date.now() - d * 86400 * 1000).toISOString();

  function uuid() {
    if (typeof crypto !== 'undefined' && crypto.randomUUID) return crypto.randomUUID();
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      const r = (Math.random() * 16) | 0;
      const v = c === 'x' ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
  }

  function getDefaultUser() {
    let savedSession = null;
    try {
      savedSession = JSON.parse(localStorage.getItem(SESSION_KEY) || 'null');
    } catch (e) {}
    if (savedSession && savedSession.user) return savedSession.user;
    return {
      id: 'user-owner-main-001',
      aud: 'authenticated',
      role: 'authenticated',
      email: 'owner@gogogo.app',
      email_confirmed_at: nowIso(),
      phone: '08215006669',
      created_at: daysAgoIso(30),
      updated_at: nowIso(),
      user_metadata: {
        full_name: 'Admin & Owner GoGoGo',
        phone: '08215006669'
      },
      app_metadata: { provider: 'email', providers: ['email'] }
    };
  }

  function buildInitialDatabase(currentUser) {
    const uid = currentUser.id;
    const uEmail = currentUser.email || 'owner@gogogo.app';
    const uName = currentUser.user_metadata?.full_name || uEmail.split('@')[0];

    const regions = [
      {
        id: 'abepura',
        name: 'Abepura & Sekitarnya',
        is_active: true,
        sort_order: 1,
        center_lat: -2.6068,
        center_lng: 140.6692,
        radius_km: 15,
        customer_filter_enabled: false,
        courier_partition_enabled: false,
        needs_location_review: false,
        created_at: daysAgoIso(60)
      },
      {
        id: 'jayapura',
        name: 'Kota Jayapura & Entrop',
        is_active: true,
        sort_order: 2,
        center_lat: -2.5337,
        center_lng: 140.7181,
        radius_km: 15,
        customer_filter_enabled: false,
        courier_partition_enabled: false,
        needs_location_review: false,
        created_at: daysAgoIso(60)
      },
      {
        id: 'waena',
        name: 'Waena & Sentani',
        is_active: true,
        sort_order: 3,
        center_lat: -2.5892,
        center_lng: 140.6311,
        radius_km: 15,
        customer_filter_enabled: false,
        courier_partition_enabled: false,
        needs_location_review: false,
        created_at: daysAgoIso(60)
      }
    ];

    const region_delivery_settings = [
      {
        region_id: 'abepura',
        fee: 8000,
        max_distance_km: 15,
        tiers: [
          { min_km: 0, max_km: 2, fee: 8000, label: 'Dekat (0-2 km)' },
          { min_km: 2, max_km: 5, fee: 12000, label: 'Sedang (2-5 km)' },
          { min_km: 5, max_km: 10, fee: 18000, label: 'Jauh (5-10 km)' },
          { min_km: 10, max_km: 15, fee: 25000, label: 'Antar Area (10-15 km)' }
        ],
        updated_at: nowIso()
      },
      {
        region_id: 'jayapura',
        fee: 10000,
        max_distance_km: 15,
        tiers: [
          { min_km: 0, max_km: 3, fee: 10000, label: 'Dalam Area' },
          { min_km: 3, max_km: 10, fee: 16000, label: 'Luar Area' }
        ],
        updated_at: nowIso()
      },
      {
        region_id: 'waena',
        fee: 10000,
        max_distance_km: 15,
        tiers: [
          { min_km: 0, max_km: 3, fee: 10000, label: 'Dalam Area' },
          { min_km: 3, max_km: 10, fee: 16000, label: 'Luar Area' }
        ],
        updated_at: nowIso()
      }
    ];

    const categories = [
      { id: 'cat-food-1', name: 'Nasi & Ayam', icon: '🍗', scope: 'food', sort_order: 1 },
      { id: 'cat-food-2', name: 'Bakso & Mie', icon: '🍜', scope: 'food', sort_order: 2 },
      { id: 'cat-food-3', name: 'Kopi & Minuman', icon: '☕', scope: 'food', sort_order: 3 },
      { id: 'cat-food-4', name: 'Seafood & Ikan', icon: '🐟', scope: 'food', sort_order: 4 },
      { id: 'cat-food-5', name: 'Jajanan & Camilan', icon: '🍟', scope: 'food', sort_order: 5 },
      { id: 'cat-mart-1', name: 'Sembako Harian', icon: '🌾', scope: 'mart', sort_order: 1 },
      { id: 'cat-mart-2', name: 'Minuman & Susu', icon: '🥛', scope: 'mart', sort_order: 2 },
      { id: 'cat-mart-3', name: 'Snack & Mie Instan', icon: '🍪', scope: 'mart', sort_order: 3 },
      { id: 'cat-mart-4', name: 'Sabun & Rumah Tangga', icon: '🧼', scope: 'mart', sort_order: 4 },
      { id: 'cat-mart-5', name: 'Obat & Kesehatan', icon: '💊', scope: 'mart', sort_order: 5 }
    ];

    const restaurants = [
      {
        id: 'rest-food-1',
        owner_id: uid,
        name: 'Ayam Geprek & Lalapan Juara Abepura',
        description: 'Ayam geprek krispi sambal bawang segar, bebek goreng, dan aneka paket nasi hemat di BTN Bawah Abepura.',
        address: 'BTN Bawah Abepura',
        category: 'Nasi & Ayam',
        merchant_type: 'food',
        region_id: 'abepura',
        latitude: -2.6068,
        longitude: 140.6692,
        rating: 4.9,
        review_count: 42,
        opening_hours: '08:00 - 22:00',
        is_active: true,
        is_temporarily_closed: false,
        temp_closed_until: null,
        temp_closed_reason: null,
        admin_status_override: null,
        image_url: 'https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?auto=format&fit=crop&w=800&q=80',
        logo_url: 'https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?auto=format&fit=crop&w=300&q=80',
        created_at: daysAgoIso(45)
      },
      {
        id: 'rest-food-2',
        owner_id: uid,
        name: 'Bakso Lava & Mie Ayam Mas Joko',
        description: 'Bakso urat sapi asli, bakso mercon, dan mie ayam pangsit kuah kaldu gurih.',
        address: 'Jl. Raya Abepura, dekat BTN Bawah Abepura',
        category: 'Bakso & Mie',
        merchant_type: 'food',
        region_id: 'abepura',
        latitude: -2.6052,
        longitude: 140.6710,
        rating: 4.8,
        review_count: 31,
        opening_hours: '09:00 - 22:00',
        is_active: true,
        is_temporarily_closed: false,
        temp_closed_until: null,
        temp_closed_reason: null,
        admin_status_override: null,
        image_url: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=800&q=80',
        logo_url: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=300&q=80',
        created_at: daysAgoIso(40)
      },
      {
        id: 'rest-food-3',
        owner_id: 'user-merchant-002',
        name: 'Kedai Kopi & Roti Bakar Nusantara',
        description: 'Es kopi susu gula aren, boba brown sugar, roti bakar coklat keju, dan pisang goreng krispi.',
        address: 'Simpang BTN Bawah Abepura',
        category: 'Kopi & Minuman',
        merchant_type: 'food',
        region_id: 'abepura',
        latitude: -2.6075,
        longitude: 140.6680,
        rating: 4.9,
        review_count: 28,
        opening_hours: '08:00 - 23:00',
        is_active: true,
        is_temporarily_closed: false,
        temp_closed_until: null,
        temp_closed_reason: null,
        admin_status_override: null,
        image_url: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=800&q=80',
        logo_url: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=300&q=80',
        created_at: daysAgoIso(35)
      },
      {
        id: 'rest-food-4',
        owner_id: 'user-merchant-002',
        name: 'RM Sari Laut & Ikan Bakar Spesial',
        description: 'Ikan bakar rica-rica segar, cumi saus padang, udang goreng tepung, dan sayur kangkung.',
        address: 'Jl. Baru Abepura',
        category: 'Seafood & Ikan',
        merchant_type: 'food',
        region_id: 'abepura',
        latitude: -2.6090,
        longitude: 140.6725,
        rating: 4.7,
        review_count: 19,
        opening_hours: '10:00 - 22:00',
        is_active: true,
        is_temporarily_closed: false,
        temp_closed_until: null,
        temp_closed_reason: null,
        admin_status_override: null,
        image_url: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=800&q=80',
        logo_url: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=300&q=80',
        created_at: daysAgoIso(30)
      },
      {
        id: 'rest-mart-1',
        owner_id: uid,
        name: 'Go Mart Abepura Pusat',
        description: 'Minimarket kebutuhan harian lengkap: beras, minyak goreng, telur, susu, snack, dan perlengkapan rumah.',
        address: 'BTN Bawah Abepura No. 12',
        category: 'Sembako Harian',
        merchant_type: 'mart',
        region_id: 'abepura',
        latitude: -2.6065,
        longitude: 140.6695,
        rating: 4.9,
        review_count: 54,
        opening_hours: '07:00 - 22:30',
        is_active: true,
        is_temporarily_closed: false,
        temp_closed_until: null,
        temp_closed_reason: null,
        admin_status_override: null,
        image_url: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=800&q=80',
        logo_url: 'https://images.unsplash.com/photo-1542838132-92c53300491e?auto=format&fit=crop&w=300&q=80',
        created_at: daysAgoIso(50)
      },
      {
        id: 'rest-mart-2',
        owner_id: 'user-merchant-002',
        name: 'Berkah Grosir & Sembako Murah',
        description: 'Belanja sembako, gas, air galon, mie instan kardusan, dan kebutuhan dapur harga grosir.',
        address: 'Pasar Abepura Blok A3',
        category: 'Sembako Harian',
        merchant_type: 'mart',
        region_id: 'abepura',
        latitude: -2.6080,
        longitude: 140.6702,
        rating: 4.8,
        review_count: 23,
        opening_hours: '07:00 - 21:30',
        is_active: true,
        is_temporarily_closed: false,
        temp_closed_until: null,
        temp_closed_reason: null,
        admin_status_override: null,
        image_url: 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?auto=format&fit=crop&w=800&q=80',
        logo_url: 'https://images.unsplash.com/photo-1578916171728-46686eac8d58?auto=format&fit=crop&w=300&q=80',
        created_at: daysAgoIso(25)
      }
    ];

    const restaurant_contacts = [
      { restaurant_id: 'rest-food-1', whatsapp_number: '628215006669' },
      { restaurant_id: 'rest-food-2', whatsapp_number: '628215006669' },
      { restaurant_id: 'rest-food-3', whatsapp_number: '628215006669' },
      { restaurant_id: 'rest-food-4', whatsapp_number: '628215006669' },
      { restaurant_id: 'rest-mart-1', whatsapp_number: '628215006669' },
      { restaurant_id: 'rest-mart-2', whatsapp_number: '628215006669' }
    ];

    const merchant_operating_hours = [];
    for (const r of restaurants) {
      for (let d = 0; d < 7; d++) {
        merchant_operating_hours.push({
          restaurant_id: r.id,
          day_of_week: d,
          open_time: '07:00',
          close_time: '23:00',
          is_closed: false
        });
      }
    }

    const menu_items = [
      {
        id: 'menu-101',
        restaurant_id: 'rest-food-1',
        name: 'Paket Nasi Ayam Geprek Sambal Bawang',
        description: 'Nasi hangat + ayam geprek krispi + lalapan + es teh manis.',
        price: 25000,
        category: 'Nasi & Ayam',
        is_available: true,
        is_recommended: true,
        has_spice_levels: true,
        image_url: 'https://images.unsplash.com/photo-1626082927389-6cd097cdc6ec?auto=format&fit=crop&w=600&q=80',
        created_at: daysAgoIso(40)
      },
      {
        id: 'menu-102',
        restaurant_id: 'rest-food-1',
        name: 'Paket Ayam Geprek Mozzarella Lumer',
        description: 'Ayam geprek pedas dengan lelehan keju mozzarella + nasi putih.',
        price: 32000,
        category: 'Nasi & Ayam',
        is_available: true,
        is_recommended: true,
        has_spice_levels: true,
        image_url: 'https://images.unsplash.com/photo-1562967914-608f82629710?auto=format&fit=crop&w=600&q=80',
        created_at: daysAgoIso(40)
      },
      {
        id: 'menu-103',
        restaurant_id: 'rest-food-1',
        name: 'Nasi Bebek Goreng Sambal Korek',
        description: 'Bebek goreng empuk bumbu rempah dengan sambal korek mantap.',
        price: 35000,
        category: 'Nasi & Ayam',
        is_available: true,
        is_recommended: false,
        has_spice_levels: true,
        image_url: 'https://images.unsplash.com/photo-1598515214211-89d3c73ae83b?auto=format&fit=crop&w=600&q=80',
        created_at: daysAgoIso(38)
      },
      {
        id: 'menu-104',
        restaurant_id: 'rest-food-1',
        name: 'Es Jeruk Peras Segar Jumbo',
        description: 'Perasan jeruk asli segar manis dingin.',
        price: 10000,
        category: 'Kopi & Minuman',
        is_available: true,
        is_recommended: false,
        has_spice_levels: false,
        image_url: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?auto=format&fit=crop&w=600&q=80',
        created_at: daysAgoIso(38)
      },
      {
        id: 'menu-201',
        restaurant_id: 'rest-food-2',
        name: 'Bakso Lava Mercon Spesial',
        description: 'Bakso jumbo isi cabai rawit merah dan daging cincang + bakso kecil.',
        price: 24000,
        category: 'Bakso & Mie',
        is_available: true,
        is_recommended: true,
        has_spice_levels: true,
        image_url: 'https://images.unsplash.com/photo-1569718212165-3a8278d5f624?auto=format&fit=crop&w=600&q=80',
        created_at: daysAgoIso(35)
      },
      {
        id: 'menu-202',
        restaurant_id: 'rest-food-2',
        name: 'Mie Ayam Bakso Urat Komplit',
        description: 'Mie ayam jamur manis gurih ditambah 2 butir bakso urat sapi.',
        price: 22000,
        category: 'Bakso & Mie',
        is_available: true,
        is_recommended: true,
        has_spice_levels: true,
        image_url: 'https://images.unsplash.com/photo-1555126634-323283e090fa?auto=format&fit=crop&w=600&q=80',
        created_at: daysAgoIso(35)
      },
      {
        id: 'menu-301',
        restaurant_id: 'rest-food-3',
        name: 'Es Kopi Susu Gula Aren Nusantara',
        description: 'Espresso arabika pilihan dengan susu segar dan gula aren asli.',
        price: 18000,
        category: 'Kopi & Minuman',
        is_available: true,
        is_recommended: true,
        has_spice_levels: false,
        image_url: 'https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=600&q=80',
        created_at: daysAgoIso(30)
      },
      {
        id: 'menu-302',
        restaurant_id: 'rest-food-3',
        name: 'Roti Bakar Coklat Keju Lumer',
        description: 'Roti bakar tebal dengan topping coklat crunchy dan parutan keju melimpah.',
        price: 20000,
        category: 'Jajanan & Camilan',
        is_available: true,
        is_recommended: true,
        has_spice_levels: false,
        image_url: 'https://images.unsplash.com/photo-1525351484163-7529414344d8?auto=format&fit=crop&w=600&q=80',
        created_at: daysAgoIso(30)
      },
      {
        id: 'menu-303',
        restaurant_id: 'rest-food-3',
        name: 'Pisang Goreng Krispi Sambal Roa',
        description: 'Pisang goreng renyah disajikan dengan sambal roa pedas gurih.',
        price: 18000,
        category: 'Jajanan & Camilan',
        is_available: true,
        is_recommended: true,
        has_spice_levels: true,
        image_url: 'https://images.unsplash.com/photo-1604908554025-aaa87c152c7b?auto=format&fit=crop&w=600&q=80',
        created_at: daysAgoIso(30)
      },
      {
        id: 'menu-401',
        restaurant_id: 'rest-food-4',
        name: 'Paket Ikan Bakar Rica-Rica + Nasi + Dabu-Dabu',
        description: 'Ikan segar bakar bumbu rica lengkap dengan nasi dan sambal dabu-dabu.',
        price: 38000,
        category: 'Seafood & Ikan',
        is_available: true,
        is_recommended: true,
        has_spice_levels: true,
        image_url: 'https://images.unsplash.com/photo-1544025162-d76694265947?auto=format&fit=crop&w=600&q=80',
        created_at: daysAgoIso(28)
      },
      {
        id: 'mart-501',
        restaurant_id: 'rest-mart-1',
        name: 'Beras Premium Pandan Wangi 5 Kg',
        description: 'Beras putih bersih pulen kemasan 5 kilogram.',
        price: 78000,
        category: 'Sembako Harian',
        is_available: true,
        is_recommended: true,
        has_spice_levels: false,
        image_url: 'https://images.unsplash.com/photo-1586201375761-83865001e31c?auto=format&fit=crop&w=600&q=80',
        created_at: daysAgoIso(25)
      },
      {
        id: 'mart-502',
        restaurant_id: 'rest-mart-1',
        name: 'Minyak Goreng Sawit Pouch 2 Liter',
        description: 'Minyak goreng jernih berkualitas kemasan pouch 2L.',
        price: 36000,
        category: 'Sembako Harian',
        is_available: true,
        is_recommended: true,
        has_spice_levels: false,
        image_url: 'https://images.unsplash.com/photo-1474979266404-7eaacbcd87c5?auto=format&fit=crop&w=600&q=80',
        created_at: daysAgoIso(25)
      },
      {
        id: 'mart-503',
        restaurant_id: 'rest-mart-1',
        name: 'Telur Ayam Negeri Segar 1 Rak (30 Butir)',
        description: 'Telur ayam negeri segar pilihan satu rak penuh.',
        price: 62000,
        category: 'Sembako Harian',
        is_available: true,
        is_recommended: false,
        has_spice_levels: false,
        image_url: 'https://images.unsplash.com/photo-1506976785307-8732e854ad03?auto=format&fit=crop&w=600&q=80',
        created_at: daysAgoIso(25)
      },
      {
        id: 'mart-504',
        restaurant_id: 'rest-mart-1',
        name: 'Susu UHT Full Cream 1 Liter',
        description: 'Susu sapi segar UHT 1000ml kaya kalsium.',
        price: 21000,
        category: 'Minuman & Susu',
        is_available: true,
        is_recommended: false,
        has_spice_levels: false,
        image_url: 'https://images.unsplash.com/photo-1563636619-e9143da7973b?auto=format&fit=crop&w=600&q=80',
        created_at: daysAgoIso(25)
      },
      {
        id: 'mart-505',
        restaurant_id: 'rest-mart-1',
        name: 'Paket 5 Bungkus Mie Instan Goreng',
        description: 'Paket hemat 5 bungkus mie instan goreng favorit.',
        price: 16500,
        category: 'Snack & Mie Instan',
        is_available: true,
        is_recommended: false,
        has_spice_levels: false,
        image_url: 'https://images.unsplash.com/photo-1612929633738-8fe44f7ec841?auto=format&fit=crop&w=600&q=80',
        created_at: daysAgoIso(25)
      },
      {
        id: 'mart-506',
        restaurant_id: 'rest-mart-2',
        name: 'Gula Pasir Kristal Putih 1 Kg',
        description: 'Gula pasir murni kemasan 1 kilogram.',
        price: 17500,
        category: 'Sembako Harian',
        is_available: true,
        is_recommended: false,
        has_spice_levels: false,
        image_url: 'https://images.unsplash.com/photo-1581441363689-1f3c3c414635?auto=format&fit=crop&w=600&q=80',
        created_at: daysAgoIso(20)
      }
    ];

    const profiles = [
      {
        id: uid,
        email: uEmail,
        full_name: uName,
        phone: '08215006669',
        phone_verified: true,
        phone_verified_at: daysAgoIso(10),
        address: 'BTN Bawah Abepura',
        latitude: -2.6068,
        longitude: 140.6692,
        region_id: 'abepura',
        avatar_url: null,
        driver_online: true,
        driver_online_changed_at: hoursAgoIso(3),
        driver_code: 'KRR-001',
        vehicle_plate: 'PA 4521 GG',
        wallet_balance: 350000,
        created_at: daysAgoIso(30),
        updated_at: nowIso()
      },
      {
        id: 'user-courier-002',
        email: 'kurir.rizky@gogogo.app',
        full_name: 'Rizky Pratama (Kurir Siaga)',
        phone: '08215006669',
        phone_verified: true,
        phone_verified_at: daysAgoIso(20),
        address: 'BTN Bawah Abepura',
        latitude: -2.6060,
        longitude: 140.6700,
        region_id: 'abepura',
        avatar_url: null,
        driver_online: true,
        driver_online_changed_at: hoursAgoIso(2),
        driver_code: 'KRR-002',
        vehicle_plate: 'PA 2819 GG',
        wallet_balance: 175000,
        created_at: daysAgoIso(25),
        updated_at: nowIso()
      },
      {
        id: 'user-merchant-002',
        email: 'merchant.nusantara@gogogo.app',
        full_name: 'Hj. Siti Aminah (Mitra Toko)',
        phone: '08215006669',
        phone_verified: true,
        phone_verified_at: daysAgoIso(15),
        address: 'BTN Bawah Abepura',
        latitude: -2.6075,
        longitude: 140.6680,
        region_id: 'abepura',
        avatar_url: null,
        driver_online: false,
        driver_online_changed_at: null,
        driver_code: null,
        vehicle_plate: null,
        wallet_balance: 520000,
        created_at: daysAgoIso(20),
        updated_at: nowIso()
      }
    ];

    const user_roles = [
      { id: 'role-1', user_id: uid, role: 'admin' },
      { id: 'role-2', user_id: uid, role: 'owner' },
      { id: 'role-3', user_id: uid, role: 'courier' },
      { id: 'role-4', user_id: 'user-courier-002', role: 'courier' },
      { id: 'role-5', user_id: 'user-merchant-002', role: 'owner' }
    ];

    const vouchers = [
      {
        id: 'vch-1',
        code: 'GRATISONGKIR',
        title: 'Gratis Ongkir s/d Rp 12.000',
        description: 'Gratis ongkos kirim untuk semua pesanan Go Makan & Go Mart minimal Rp 25.000.',
        discount_type: 'free_shipping',
        discount_value: 12000,
        max_discount: 12000,
        min_total_threshold: 25000,
        max_redemptions: 500,
        per_user_limit: 5,
        used_count: 14,
        is_active: true,
        is_public: true,
        starts_at: daysAgoIso(10),
        ends_at: new Date(Date.now() + 90 * 86400 * 1000).toISOString(),
        created_at: daysAgoIso(10)
      },
      {
        id: 'vch-2',
        code: 'GOGOGOHEMAT',
        title: 'Diskon Langsung Rp 10.000',
        description: 'Potongan langsung Rp 10.000 untuk pesanan minimal Rp 40.000.',
        discount_type: 'fixed',
        discount_value: 10000,
        max_discount: 10000,
        min_total_threshold: 40.000,
        max_redemptions: 200,
        per_user_limit: 3,
        used_count: 8,
        is_active: true,
        is_public: true,
        starts_at: daysAgoIso(10),
        ends_at: new Date(Date.now() + 90 * 86400 * 1000).toISOString(),
        created_at: daysAgoIso(10)
      },
      {
        id: 'vch-3',
        code: 'ABEPURAJUARA',
        title: 'Diskon Spesial 20% (s/d Rp 20.000)',
        description: 'Diskon 20% untuk kulineran di seluruh restoran Go Makan.',
        discount_type: 'percentage',
        discount_value: 20,
        max_discount: 20000,
        min_total_threshold: 35000,
        max_redemptions: 150,
        per_user_limit: 2,
        used_count: 5,
        is_active: true,
        is_public: true,
        starts_at: daysAgoIso(7),
        ends_at: new Date(Date.now() + 60 * 86400 * 1000).toISOString(),
        created_at: daysAgoIso(7)
      }
    ];

    const loyalty_settings = [
      {
        id: 1,
        enabled: true,
        spend_per_point: 10000,
        valid_days: 365,
        tiers: [
          { points: 50, discount: 10000, min_order: 25000, label: 'Voucher Belanja Rp 10.000' },
          { points: 100, discount: 25000, min_order: 50000, label: 'Voucher Belanja Rp 25.000' },
          { points: 200, discount: 55000, min_order: 100000, label: 'Voucher Spesial Rp 55.000' }
        ],
        updated_at: nowIso()
      }
    ];

    const user_points = [
      {
        user_id: uid,
        points: 185,
        lifetime_points: 350,
        updated_at: nowIso()
      }
    ];

    const orders = [
      {
        id: 'ord-sample-101',
        order_number: 'GGG-882401',
        customer_id: uid,
        restaurant_id: 'rest-food-1',
        courier_id: uid,
        customer_name: uName,
        customer_phone: '08215006669',
        customer_address: 'BTN Bawah Abepura',
        latitude: -2.6068,
        longitude: 140.6692,
        status: 'completed',
        fulfillment_type: 'delivery',
        self_delivery: false,
        subtotal: 57000,
        delivery_fee: 8000,
        delivery_tier: '0-2km',
        delivery_tier_label: 'Dekat (0-2 km)',
        admin_fee: 2000,
        app_fee: 2000,
        discount: 0,
        voucher_code: null,
        total: 67000,
        notes: 'Sambal bawang dipisah ya kak',
        auto_cancel_enabled: false,
        driver_timeout_minutes: 15,
        restaurant_responded_at: hoursAgoIso(4),
        accepted_at: hoursAgoIso(4),
        delivered_at: hoursAgoIso(3),
        courier_payout_status: 'paid',
        courier_paid_at: hoursAgoIso(2),
        created_at: hoursAgoIso(4),
        updated_at: hoursAgoIso(3)
      },
      {
        id: 'ord-sample-102',
        order_number: 'GGG-882402',
        customer_id: uid,
        restaurant_id: 'rest-food-1',
        courier_id: null,
        customer_name: 'Budi Santoso (Abepura)',
        customer_phone: '08215006669',
        customer_address: 'BTN Bawah Abepura Blok C2',
        latitude: -2.6072,
        longitude: 140.6698,
        status: 'waiting_restaurant',
        fulfillment_type: 'delivery',
        self_delivery: false,
        subtotal: 50000,
        delivery_fee: 8000,
        delivery_tier: '0-2km',
        delivery_tier_label: 'Dekat (0-2 km)',
        admin_fee: 2000,
        app_fee: 2000,
        discount: 0,
        voucher_code: null,
        total: 60000,
        notes: 'Level pedas sedang (Level 2)',
        auto_cancel_enabled: true,
        driver_timeout_minutes: 15,
        restaurant_responded_at: null,
        accepted_at: null,
        delivered_at: null,
        courier_payout_status: 'unpaid',
        courier_paid_at: null,
        created_at: hoursAgoIso(0.2),
        updated_at: hoursAgoIso(0.2)
      },
      {
        id: 'ord-sample-103',
        order_number: 'GGG-882403',
        customer_id: uid,
        restaurant_id: 'rest-food-2',
        courier_id: null,
        customer_name: 'Dewi Lestari (Abepura)',
        customer_phone: '08215006669',
        customer_address: 'BTN Bawah Abepura Jalur 2',
        latitude: -2.6058,
        longitude: 140.6712,
        status: 'pending',
        fulfillment_type: 'delivery',
        self_delivery: false,
        subtotal: 46000,
        delivery_fee: 8000,
        delivery_tier: '0-2km',
        delivery_tier_label: 'Dekat (0-2 km)',
        admin_fee: 2000,
        app_fee: 2000,
        discount: 0,
        voucher_code: null,
        total: 56000,
        notes: 'Kuah bakso pisah plastik',
        auto_cancel_enabled: true,
        driver_timeout_minutes: 15,
        restaurant_responded_at: hoursAgoIso(0.1),
        accepted_at: null,
        delivered_at: null,
        courier_payout_status: 'unpaid',
        courier_paid_at: null,
        created_at: hoursAgoIso(0.15),
        updated_at: hoursAgoIso(0.1)
      }
    ];

    const order_items = [
      {
        id: 'oi-1',
        order_id: 'ord-sample-101',
        menu_item_id: 'menu-101',
        menu_name: 'Paket Nasi Ayam Geprek Sambal Bawang',
        quantity: 1,
        price: 25000,
        restaurant_price: 23000,
        markup_amount: 2000,
        notes: 'Pedas Level 3'
      },
      {
        id: 'oi-2',
        order_id: 'ord-sample-101',
        menu_item_id: 'menu-102',
        menu_name: 'Paket Ayam Geprek Mozzarella Lumer',
        quantity: 1,
        price: 32000,
        restaurant_price: 30000,
        markup_amount: 2000,
        notes: 'Pedas Level 2'
      },
      {
        id: 'oi-3',
        order_id: 'ord-sample-102',
        menu_item_id: 'menu-101',
        menu_name: 'Paket Nasi Ayam Geprek Sambal Bawang',
        quantity: 2,
        price: 25000,
        restaurant_price: 23000,
        markup_amount: 2000,
        notes: 'Pedas Level 2'
      },
      {
        id: 'oi-4',
        order_id: 'ord-sample-103',
        menu_item_id: 'menu-201',
        menu_name: 'Bakso Lava Mercon Spesial',
        quantity: 1,
        price: 24000,
        restaurant_price: 22000,
        markup_amount: 2000,
        notes: null
      },
      {
        id: 'oi-5',
        order_id: 'ord-sample-103',
        menu_item_id: 'menu-202',
        menu_name: 'Mie Ayam Bakso Urat Komplit',
        quantity: 1,
        price: 22000,
        restaurant_price: 20000,
        markup_amount: 2000,
        notes: null
      }
    ];

    const app_settings = [
      { key: 'delivery_fee', value: { enabled: false, baseFee: 5000, baseKm: 2, perKm: 2000 }, updated_at: nowIso() },
      {
        key: 'delivery_tiers',
        value: {
          enabled: true,
          tiers: {
            saver: { key: 'saver', label: 'Hemat', adjustType: 'percent', adjustValue: -20, eta: '40-60 menit' },
            standard: { key: 'standard', label: 'Standar', adjustType: 'percent', adjustValue: 0, eta: '25-40 menit' },
            priority: { key: 'priority', label: 'Prioritas', adjustType: 'percent', adjustValue: 50, eta: '15-25 menit' }
          }
        },
        updated_at: nowIso()
      },
      { key: 'service_fee', value: { enabled: true, amount: 2000 }, updated_at: nowIso() },
      {
        key: 'menu_markup',
        value: {
          mode: 'tiered',
          flatAmount: 3000,
          percentage: 10,
          tiers: [
            { min: 1000, max: 10000, amount: 2000, percent: 0 },
            { min: 10001, max: 20000, amount: 3000, percent: 0 },
            { min: 20001, max: 35000, amount: 4000, percent: 0 },
            { min: 35001, max: 50000, amount: 5000, percent: 0 },
            { min: 50001, max: null, amount: 0, percent: 10 }
          ]
        },
        updated_at: nowIso()
      },
      {
        key: 'partner_registration_fee',
        value: { enabled: false, amount: 0, bank: '', account: '', recipient: '', qris_path: '' },
        updated_at: nowIso()
      },
      { key: 'order_flow_mode', value: 'restaurant_first', updated_at: nowIso() },
      { key: 'driver_timeout', value: { enabled: true, minutes: 15 }, updated_at: nowIso() },
      {
        key: 'service_tariffs',
        value: {
          appFee: 2000,
          tiers: {
            ride_reg: { key: 'ride_reg', service: 'ride', label: 'Go Riding Reg', baseFee: 10000, baseMaxKm: 4.2, perKm: 1500, enabled: true },
            ride_comfort: { key: 'ride_comfort', service: 'ride', label: 'Go Riding Comfort', baseFee: 12000, baseMaxKm: 4.2, perKm: 1500, enabled: true },
            mobil_reg: { key: 'mobil_reg', service: 'car', label: 'Go Mobil Reg', baseFee: 21000, baseMaxKm: 4.2, perKm: 4000, enabled: true },
            mobil_xl: { key: 'mobil_xl', service: 'car', label: 'Go Mobil XL', baseFee: 24000, baseMaxKm: 4.2, perKm: 4000, enabled: true },
            mobil_premium: { key: 'mobil_premium', service: 'car', label: 'Go Mobil Premium', baseFee: 30000, baseMaxKm: 4.2, perKm: 4000, enabled: true },
            cargo_std: { key: 'cargo_std', service: 'cargo', label: 'Go Cargo', baseFee: 60000, baseMaxKm: 4.2, perKm: 4000, enabled: true },
            suruh_hourly: { key: 'suruh_hourly', service: 'suruh', label: 'Go Suruh', baseHourFee: 55000, baseMinutes: 60, perMinute: 1000, enabled: true },
            express_base: { key: 'express_base', service: 'express', label: 'Go Express', baseFee: 8000, baseMaxKm: 2.0, perKm: 3000, enabled: true }
          }
        },
        updated_at: nowIso()
      },
      { key: 'restaurant_response_timeout_minutes', value: 15, updated_at: nowIso() },
      { key: 'maintenance_mode', value: { enabled: false, message: '' }, updated_at: nowIso() },
      { key: 'promo_menu', value: ['menu-101', 'menu-201', 'menu-301', 'mart-501'], updated_at: nowIso() },
      { key: 'recommended_menu', value: ['menu-101', 'menu-102', 'menu-201', 'menu-301', 'menu-401', 'mart-501'], updated_at: nowIso() },
      {
        key: 'invoice_payment',
        value: {
          bank_name: 'BRI',
          account_number: '4821-01-029384-53-9',
          account_holder: 'GoGoGo Official Abepura',
          due_days: 7,
          notes: 'Mohon konfirmasi bukti transfer melalui WhatsApp Customer Service 08215006669.'
        },
        updated_at: nowIso()
      }
    ];

    const saved_addresses = [
      {
        id: 'addr-1',
        user_id: uid,
        label: 'Kantor / Rumah Utama',
        recipient_name: uName,
        phone: '08215006669',
        address: 'BTN Bawah Abepura',
        notes: 'Patokan jalan utama BTN Bawah Abepura',
        latitude: -2.6068,
        longitude: 140.6692,
        is_default: true,
        created_at: daysAgoIso(20)
      }
    ];

    const restaurant_reviews = [
      {
        id: 'rev-1',
        restaurant_id: 'rest-food-1',
        order_id: 'ord-sample-101',
        customer_id: uid,
        customer_name: uName,
        rating: 5,
        comment: 'Ayam gepreknya masih panas dan renyah banget saat sampai! Sambal bawangnya juara.',
        tags: ['Rasa Enak', 'Porsi Pas', 'Kemasan Rapi'],
        merchant_reply: 'Terima kasih banyak kak! Ditunggu pesanan berikutnya di Go Makan ya.',
        merchant_replied_at: hoursAgoIso(2),
        created_at: hoursAgoIso(3)
      }
    ];

    const driver_ratings = [
      {
        id: 'drat-1',
        order_id: 'ord-sample-101',
        driver_id: uid,
        customer_id: uid,
        rating: 5,
        tags: ['Ramah & Sopan', 'Tepat Waktu', 'Hati-hati'],
        review: 'Kurir GoGoGo sangat ramah dan cepat sampai tujuan.',
        created_at: hoursAgoIso(3)
      }
    ];

    const courier_locations = [
      {
        order_id: 'ord-sample-101',
        courier_id: uid,
        latitude: -2.6067,
        longitude: 140.6693,
        heading: 90,
        recorded_at: nowIso(),
        updated_at: nowIso()
      }
    ];

    return {
      regions,
      region_delivery_settings,
      region_courier_groups: [{ region_id: 'abepura', group_id: '120363049281726@g.us', updated_at: nowIso() }],
      categories,
      restaurants,
      restaurant_contacts,
      merchant_operating_hours,
      merchant_holidays: [],
      merchant_status_logs: [],
      menu_items,
      profiles,
      user_roles,
      vouchers,
      voucher_redemptions: [],
      loyalty_settings,
      user_points,
      point_redemptions: [],
      orders,
      order_items,
      app_settings,
      saved_addresses,
      favorites: [{ id: 'fav-1', user_id: uid, restaurant_id: 'rest-food-1', created_at: daysAgoIso(5) }],
      restaurant_reviews,
      review_reports: [],
      driver_ratings,
      courier_locations,
      customer_hidden_orders: [],
      partner_applications: [],
      service_fee_invoices: [],
      ai_chat_messages: [],
      phone_change_audit: [],
      push_subscriptions: [],
      wallet_transactions: [
        {
          id: 'wtx-1',
          user_id: uid,
          type: 'topup',
          amount: 250000,
          description: 'Top-Up Saldo GoGoGo Pay via QRIS',
          created_at: daysAgoIso(3)
        },
        {
          id: 'wtx-2',
          user_id: uid,
          type: 'cashback',
          amount: 100000,
          description: 'Bonus Saldo Awal Owner GoGoGo',
          created_at: daysAgoIso(10)
        }
      ],
      wa_gateway_config: {
        enabled: true,
        delay_minutes: 0,
        token: 'FONNTE_DEMO_TOKEN_GOGOGO',
        courier_group_enabled: true,
        courier_group_id: '120363049281726@g.us',
        wa_verification_enabled: false
      }
    };
  }

  function loadDB() {
    const user = getDefaultUser();
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw);
        ensureUserInDB(parsed, user);
        return parsed;
      }
    } catch (e) {
      console.warn('Rebuilding local DB:', e);
    }
    const fresh = buildInitialDatabase(user);
    saveDB(fresh);
    return fresh;
  }

  function saveDB(db) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
    } catch (e) {
      console.error('Failed saving DB:', e);
    }
  }

  function getActiveRolesConfig() {
    try {
      const raw = localStorage.getItem(ROLE_CONFIG_KEY);
      if (raw) return JSON.parse(raw);
    } catch (e) {}
    return { admin: true, owner: true, courier: true };
  }

  function setActiveRolesConfig(cfg) {
    localStorage.setItem(ROLE_CONFIG_KEY, JSON.stringify(cfg));
  }

  function ensureUserInDB(db, user) {
    if (!user || !user.id) return;
    db.profiles = db.profiles || [];
    let prof = db.profiles.find((p) => p.id === user.id);
    if (!prof) {
      prof = {
        id: user.id,
        email: user.email || 'user@gogogo.app',
        full_name: user.user_metadata?.full_name || (user.email ? user.email.split('@')[0] : 'Pengguna GoGoGo'),
        phone: user.user_metadata?.phone || user.phone || '08215006669',
        phone_verified: true,
        phone_verified_at: nowIso(),
        address: 'BTN Bawah Abepura',
        latitude: -2.6068,
        longitude: 140.6692,
        region_id: 'abepura',
        avatar_url: null,
        driver_online: true,
        driver_online_changed_at: nowIso(),
        driver_code: 'KRR-001',
        vehicle_plate: 'PA 4521 GG',
        wallet_balance: 350000,
        created_at: nowIso(),
        updated_at: nowIso()
      };
      db.profiles.unshift(prof);
    } else {
      prof.email = user.email || prof.email;
      prof.phone_verified = true;
      if (typeof prof.wallet_balance !== 'number') prof.wallet_balance = 350000;
    }

    const roleCfg = getActiveRolesConfig();
    const isMaster = user.id === 'user-owner-main-001';
    if (isMaster) {
      db.user_roles = (db.user_roles || []).filter((r) => r.user_id !== user.id);
      if (roleCfg.admin) db.user_roles.push({ id: 'r-adm-' + user.id, user_id: user.id, role: 'admin' });
      if (roleCfg.owner) db.user_roles.push({ id: 'r-own-' + user.id, user_id: user.id, role: 'owner' });
      if (roleCfg.courier) db.user_roles.push({ id: 'r-cur-' + user.id, user_id: user.id, role: 'courier' });
    }

    for (const r of db.restaurants || []) {
      if (r.id === 'rest-food-1' || r.id === 'rest-food-2' || r.id === 'rest-mart-1') {
        r.owner_id = user.id;
      }
    }

    db.user_points = db.user_points || [];
    if (!db.user_points.find((up) => up.user_id === user.id)) {
      db.user_points.push({ user_id: user.id, points: 185, lifetime_points: 350, updated_at: nowIso() });
    }
  }

  function attachRelations(tableName, row, selectStr, db) {
    if (!row || typeof row !== 'object') return row;
    const copy = { ...row };
    const sel = String(selectStr || '*');

    if (tableName === 'menu_items' && sel.includes('restaurants')) {
      const rest = (db.restaurants || []).find((r) => r.id === copy.restaurant_id) || null;
      copy.restaurants = rest ? { ...rest } : null;
    }

    if (tableName === 'restaurants' && sel.includes('restaurant_contacts')) {
      const contacts = (db.restaurant_contacts || []).filter((c) => c.restaurant_id === copy.id);
      copy.restaurant_contacts = contacts[0] || null;
    }

    if (tableName === 'orders') {
      if (sel.includes('restaurants')) {
        const rest = (db.restaurants || []).find((r) => r.id === copy.restaurant_id) || null;
        if (rest) {
          const contacts = (db.restaurant_contacts || []).filter((c) => c.restaurant_id === rest.id);
          copy.restaurants = { ...rest, restaurant_contacts: contacts[0] || null };
        } else {
          copy.restaurants = null;
        }
      }
      if (sel.includes('order_items')) {
        copy.order_items = (db.order_items || []).filter((oi) => oi.order_id === copy.id);
      }
    }

    if (tableName === 'favorites' && sel.includes('restaurants')) {
      copy.restaurants = (db.restaurants || []).find((r) => r.id === copy.restaurant_id) || null;
    }

    if (tableName === 'voucher_redemptions' && sel.includes('orders')) {
      copy.orders = (db.orders || []).find((o) => o.id === copy.order_id) || null;
    }

    return copy;
  }

  function getNestedVal(obj, path) {
    if (!obj) return undefined;
    if (path in obj) return obj[path];
    const parts = path.split('.');
    let cur = obj;
    for (const p of parts) {
      if (cur == null) return undefined;
      cur = cur[p];
    }
    return cur;
  }

  class LocalQueryBuilder {
    constructor(tableName, getDb, saveDbFn) {
      this.tableName = tableName;
      this.getDb = getDb;
      this.saveDbFn = saveDbFn;
      this.op = 'select';
      this.selectColumns = '*';
      this.selectOpts = {};
      this.payload = null;
      this.upsertOpts = {};
      this.filters = [];
      this.sorts = [];
      this.limitCount = null;
      this.rangeBounds = null;
      this.expectSingle = false;
      this.expectMaybeSingle = false;
    }

    select(cols = '*', opts = {}) {
      if (this.op === 'select') {
        this.selectColumns = cols;
        this.selectOpts = opts || {};
      } else {
        this.returnSelect = cols;
      }
      return this;
    }

    insert(data) {
      this.op = 'insert';
      this.payload = data;
      return this;
    }

    update(data) {
      this.op = 'update';
      this.payload = data;
      return this;
    }

    upsert(data, opts = {}) {
      this.op = 'upsert';
      this.payload = data;
      this.upsertOpts = opts || {};
      return this;
    }

    delete() {
      this.op = 'delete';
      return this;
    }

    eq(col, val) {
      this.filters.push((row) => getNestedVal(row, col) === val);
      return this;
    }

    neq(col, val) {
      this.filters.push((row) => getNestedVal(row, col) !== val);
      return this;
    }

    gt(col, val) {
      this.filters.push((row) => getNestedVal(row, col) > val);
      return this;
    }

    gte(col, val) {
      this.filters.push((row) => getNestedVal(row, col) >= val);
      return this;
    }

    lt(col, val) {
      this.filters.push((row) => getNestedVal(row, col) < val);
      return this;
    }

    lte(col, val) {
      this.filters.push((row) => getNestedVal(row, col) <= val);
      return this;
    }

    ilike(col, pattern) {
      const clean = String(pattern || '').replace(/%/g, '').toLowerCase();
      this.filters.push((row) => String(getNestedVal(row, col) || '').toLowerCase().includes(clean));
      return this;
    }

    like(col, pattern) {
      return this.ilike(col, pattern);
    }

    is(col, val) {
      this.filters.push((row) => getNestedVal(row, col) === val);
      return this;
    }

    in(col, arr) {
      const set = new Set(Array.isArray(arr) ? arr : []);
      this.filters.push((row) => set.has(getNestedVal(row, col)));
      return this;
    }

    not(col, op, val) {
      if (op === 'in') {
        const list = String(val || '')
          .replace(/^\(|\)$/g, '')
          .split(',')
          .map((s) => s.trim());
        const set = new Set(list);
        this.filters.push((row) => !set.has(String(getNestedVal(row, col))));
      } else {
        this.filters.push((row) => getNestedVal(row, col) !== val);
      }
      return this;
    }

    or(expr) {
      const str = String(expr || '');
      if (this.tableName === 'orders' && str.includes('courier_id')) {
        this.filters.push((row) => {
          const isUnclaimed =
            !row.courier_id &&
            ['searching_driver', 'pending', 'waiting_restaurant', 'Accepted', 'accepted', 'preparing', 'ready_for_pickup'].includes(row.status);
          const isMine = row.courier_id != null;
          return isUnclaimed || isMine;
        });
      } else if (str.includes('phone.is.null')) {
        this.filters.push((row) => !row.phone || String(row.phone).trim() === '');
      }
      return this;
    }

    order(col, opts = { ascending: true }) {
      const asc = opts?.ascending !== false;
      this.sorts.push((a, b) => {
        const va = getNestedVal(a, col);
        const vb = getNestedVal(b, col);
        if (va === vb) return 0;
        if (va == null) return 1;
        if (vb == null) return -1;
        return (va > vb ? 1 : -1) * (asc ? 1 : -1);
      });
      return this;
    }

    limit(n) {
      this.limitCount = Number(n);
      return this;
    }

    range(from, to) {
      this.rangeBounds = [Number(from), Number(to)];
      return this;
    }

    single() {
      this.expectSingle = true;
      return this;
    }

    maybeSingle() {
      this.expectMaybeSingle = true;
      return this;
    }

    async _execute() {
      const db = this.getDb();
      if (!db[this.tableName]) db[this.tableName] = [];
      let table = db[this.tableName];

      const applyFilters = (rows) => {
        return rows.filter((r) => {
          const enriched = attachRelations(this.tableName, r, this.selectColumns, db);
          return this.filters.every((fn) => fn(enriched));
        });
      };

      if (this.op === 'select') {
        let rows = table.map((r) => attachRelations(this.tableName, r, this.selectColumns, db));
        rows = rows.filter((r) => this.filters.every((fn) => fn(r)));

        for (let i = this.sorts.length - 1; i >= 0; i--) {
          rows.sort(this.sorts[i]);
        }

        const totalCount = rows.length;
        if (this.rangeBounds) {
          rows = rows.slice(this.rangeBounds[0], this.rangeBounds[1] + 1);
        }
        if (this.limitCount != null) {
          rows = rows.slice(0, this.limitCount);
        }

        if (this.selectOpts?.head) {
          return { data: null, count: totalCount, error: null };
        }
        if (this.expectSingle || this.expectMaybeSingle) {
          return { data: rows[0] ?? null, error: null };
        }
        return { data: rows, count: totalCount, error: null };
      }

      if (this.op === 'insert') {
        const items = Array.isArray(this.payload) ? this.payload : [this.payload];
        const inserted = items.map((item) => {
          const row = { ...item };
          if (!row.id && this.tableName !== 'app_settings' && this.tableName !== 'restaurant_contacts' && this.tableName !== 'merchant_operating_hours') {
            row.id = uuid();
          }
          if (!row.created_at) row.created_at = nowIso();
          table.unshift(row);
          return attachRelations(this.tableName, row, this.returnSelect || '*', db);
        });
        this.saveDbFn(db);
        if (this.expectSingle || this.expectMaybeSingle) {
          return { data: inserted[0] ?? null, error: null };
        }
        return { data: inserted, error: null };
      }

      if (this.op === 'update') {
        const matched = applyFilters(table);
        const updated = [];
        for (const row of matched) {
          Object.assign(row, this.payload, { updated_at: nowIso() });
          updated.push(attachRelations(this.tableName, row, this.returnSelect || '*', db));
        }
        this.saveDbFn(db);
        if (this.expectSingle || this.expectMaybeSingle) {
          return { data: updated[0] ?? null, error: null };
        }
        return { data: updated, error: null };
      }

      if (this.op === 'upsert') {
        const items = Array.isArray(this.payload) ? this.payload : [this.payload];
        const conflictCols = String(this.upsertOpts?.onConflict || 'id')
          .split(',')
          .map((s) => s.trim())
          .filter(Boolean);
        if (this.tableName === 'app_settings' && !this.upsertOpts?.onConflict) {
          conflictCols[0] = 'key';
        }
        const results = [];
        for (const item of items) {
          const existing = table.find((r) => conflictCols.every((c) => r[c] !== undefined && r[c] === item[c]));
          if (existing) {
            if (!this.upsertOpts?.ignoreDuplicates) {
              Object.assign(existing, item, { updated_at: nowIso() });
            }
            results.push(existing);
          } else {
            const newRow = {
              ...(item.id || conflictCols[0] === 'key' ? {} : { id: uuid() }),
              ...item,
              created_at: item.created_at || nowIso()
            };
            table.push(newRow);
            results.push(newRow);
          }
        }
        this.saveDbFn(db);
        if (this.expectSingle || this.expectMaybeSingle) {
          return { data: results[0] ?? null, error: null };
        }
        return { data: results, error: null };
      }

      if (this.op === 'delete') {
        const matched = new Set(applyFilters(table));
        db[this.tableName] = table.filter((r) => !matched.has(r));
        this.saveDbFn(db);
        return { data: [], error: null };
      }

      return { data: null, error: null };
    }

    then(onFulfilled, onRejected) {
      return this._execute().then(onFulfilled, onRejected);
    }
  }

  async function executeLocalRpc(name, args = {}, getDb, saveDbFn, getUser) {
    const db = getDb();
    const user = getUser();

    switch (name) {
      case 'has_role': {
        const role = args._role;
        const uid = args._user_id || user?.id;
        const has = (db.user_roles || []).some((r) => r.user_id === uid && r.role === role);
        return { data: has, error: null };
      }
      case 'wa_verification_enabled':
        return { data: Boolean(db.wa_gateway_config?.wa_verification_enabled), error: null };
      case 'admin_set_wa_verification':
        db.wa_gateway_config = db.wa_gateway_config || {};
        db.wa_gateway_config.wa_verification_enabled = Boolean(args._enabled);
        saveDbFn(db);
        return { data: true, error: null };
      case 'admin_verify_wa_phone': {
        const prof = (db.profiles || []).find((p) => p.id === args._user);
        if (prof) {
          if (args._phone) prof.phone = args._phone;
          prof.phone_verified = true;
          prof.phone_verified_at = nowIso();
          saveDbFn(db);
        }
        return { data: true, error: null };
      }
      case 'loyalty_enabled': {
        const ls = (db.loyalty_settings || [])[0];
        return { data: ls ? Boolean(ls.enabled) : true, error: null };
      }
      case 'redeem_points': {
        const pts = Number(args._points || 0);
        const up = (db.user_points || []).find((u) => u.user_id === user?.id);
        const ls = (db.loyalty_settings || [])[0];
        const tier = (ls?.tiers || []).find((t) => Number(t.points) === pts) || {
          points: pts,
          discount: Math.round(pts * 200),
          min_order: 25000
        };
        if (!up || up.points < pts) {
          return { data: { success: false, reason: 'insufficient' }, error: null };
        }
        up.points -= pts;
        const code = 'RW-' + Math.random().toString(36).substring(2, 7).toUpperCase();
        const newVoucher = {
          id: uuid(),
          code,
          title: `Voucher Reward Rp ${Number(tier.discount).toLocaleString('id-ID')}`,
          description: `Hasil penukaran ${pts} Poin GoGoGo Rewards`,
          discount_type: 'fixed',
          discount_value: tier.discount,
          max_discount: tier.discount,
          min_total_threshold: tier.min_order || 0,
          max_redemptions: 1,
          per_user_limit: 1,
          used_count: 0,
          is_active: true,
          is_public: true,
          starts_at: nowIso(),
          ends_at: new Date(Date.now() + 30 * 86400 * 1000).toISOString(),
          created_at: nowIso()
        };
        db.vouchers.unshift(newVoucher);
        db.point_redemptions.unshift({
          id: uuid(),
          user_id: user?.id,
          points_spent: pts,
          voucher_code: code,
          created_at: nowIso()
        });
        saveDbFn(db);
        return { data: { success: true, code, discount: tier.discount }, error: null };
      }
      case 'restaurant_effective_status': {
        const rest = (db.restaurants || []).find((r) => r.id === args._restaurant_id);
        if (!rest) return { data: { status: 'open', is_open: true }, error: null };
        if (rest.admin_status_override === 'closed' || rest.is_temporarily_closed) {
          return { data: { status: 'temp_closed', is_open: false }, error: null };
        }
        return { data: { status: 'open', is_open: true }, error: null };
      }
      case 'available_vouchers': {
        const sub = Number(args._subtotal || 0);
        const del = Number(args._delivery_fee || 8000);
        const list = (db.vouchers || [])
          .filter((v) => v.is_active)
          .map((v) => {
            const eligible = sub >= Number(v.min_total_threshold || 0);
            let discount = 0;
            if (v.discount_type === 'free_shipping') {
              discount = Math.min(del, Number(v.max_discount || v.discount_value || del));
            } else if (v.discount_type === 'percentage') {
              discount = Math.round((sub * Number(v.discount_value || 0)) / 100);
              if (v.max_discount > 0) discount = Math.min(discount, Number(v.max_discount));
            } else {
              discount = Number(v.discount_value || 0);
            }
            return { ...v, valid: true, eligible, discount: eligible ? discount : 0, reason: eligible ? null : 'min_total' };
          });
        return { data: list, error: null };
      }
      case 'my_vouchers':
        return {
          data: { available: (db.vouchers || []).filter((v) => v.is_active), history: db.voucher_redemptions || [] },
          error: null
        };
      case 'admin_voucher_list':
        return { data: db.vouchers || [], error: null };
      case 'voucher_status':
      case 'claim_voucher': {
        const code = String(args._code || '').trim().toUpperCase();
        const sub = Number(args._subtotal || 0);
        const del = Number(args._delivery_fee || 8000);
        const v = (db.vouchers || []).find((x) => String(x.code).toUpperCase() === code && x.is_active);
        if (!v) return { data: { valid: false, eligible: false, success: false, reason: 'not_found' }, error: null };
        const eligible = sub >= Number(v.min_total_threshold || 0);
        let discount = 0;
        if (v.discount_type === 'free_shipping') {
          discount = Math.min(del, Number(v.max_discount || v.discount_value || del));
        } else if (v.discount_type === 'percentage') {
          discount = Math.round((sub * Number(v.discount_value || 0)) / 100);
          if (v.max_discount > 0) discount = Math.min(discount, Number(v.max_discount));
        } else {
          discount = Number(v.discount_value || 0);
        }
        return {
          data: { ...v, valid: true, eligible, success: eligible, discount: eligible ? discount : 0, reason: eligible ? null : 'min_total' },
          error: null
        };
      }
      case 'link_voucher_redemption': {
        const code = args._code;
        const v = (db.vouchers || []).find((x) => x.code === code);
        if (v) v.used_count = Number(v.used_count || 0) + 1;
        db.voucher_redemptions.unshift({
          id: uuid(),
          code,
          user_id: user?.id,
          order_id: args._order_id,
          discount_amount: args._discount || 0,
          created_at: nowIso()
        });
        saveDbFn(db);
        return { data: { success: true }, error: null };
      }
      case 'set_driver_online': {
        const prof = (db.profiles || []).find((p) => p.id === user?.id);
        if (prof) {
          prof.driver_online = Boolean(args._online);
          prof.driver_online_changed_at = nowIso();
          saveDbFn(db);
        }
        return { data: { success: true, driver_online: Boolean(args._online) }, error: null };
      }
      case 'claim_order': {
        const ord = (db.orders || []).find((o) => o.id === args._order_id);
        if (ord) {
          ord.courier_id = user?.id;
          ord.status = 'accepted';
          ord.accepted_at = nowIso();
          ord.updated_at = nowIso();
          const prof = (db.profiles || []).find((p) => p.id === user?.id);
          const rest = (db.restaurants || []).find((r) => r.id === ord.restaurant_id);
          const lat = Number(prof?.latitude ?? rest?.latitude ?? ord.pickup_latitude ?? -2.6068);
          const lng = Number(prof?.longitude ?? rest?.longitude ?? ord.pickup_longitude ?? 140.6692);
          db.courier_locations = db.courier_locations || [];
          const existingLoc = db.courier_locations.find((l) => l.order_id === ord.id);
          if (existingLoc) {
            Object.assign(existingLoc, { courier_id: user?.id, latitude: lat, longitude: lng, recorded_at: nowIso(), updated_at: nowIso() });
          } else {
            db.courier_locations.push({ order_id: ord.id, courier_id: user?.id, latitude: lat, longitude: lng, heading: 0, recorded_at: nowIso(), updated_at: nowIso() });
          }
          saveDbFn(db);
        }
        return { data: { success: true, status: 'accepted' }, error: null };
      }
      case 'courier_update_order_status': {
        const ord = (db.orders || []).find((o) => o.id === args._order_id);
        if (ord) {
          ord.status = args._status;
          ord.updated_at = nowIso();
          const rest = (db.restaurants || []).find((r) => r.id === ord.restaurant_id);
          const rLat = Number(rest?.latitude ?? ord.pickup_latitude ?? -2.6068);
          const rLng = Number(rest?.longitude ?? ord.pickup_longitude ?? 140.6692);
          const cLat = Number(ord.latitude ?? rLat);
          const cLng = Number(ord.longitude ?? rLng);
          db.courier_locations = db.courier_locations || [];
          let loc = db.courier_locations.find((l) => l.order_id === ord.id);
          let nextLat = loc?.latitude ?? rLat;
          let nextLng = loc?.longitude ?? rLng;
          if (args._status === 'driver_arrived' || args._status === 'picked_up') {
            nextLat = rLat;
            nextLng = rLng;
          } else if (args._status === 'on_delivery' || args._status === 'delivering') {
            nextLat = (rLat + cLat) / 2;
            nextLng = (rLng + cLng) / 2;
          } else if (args._status === 'completed' || args._status === 'delivered') {
            nextLat = cLat;
            nextLng = cLng;
          }
          if (loc) {
            Object.assign(loc, { latitude: nextLat, longitude: nextLng, recorded_at: nowIso(), updated_at: nowIso() });
          } else {
            db.courier_locations.push({ order_id: ord.id, courier_id: ord.courier_id || user?.id, latitude: nextLat, longitude: nextLng, heading: 0, recorded_at: nowIso(), updated_at: nowIso() });
          }
          if (args._status === 'completed' || args._status === 'delivered') {
            ord.delivered_at = nowIso();
            if (!ord.points_earned && ord.customer_id && Number(ord.total || 0) > 0) {
              const ls = (db.loyalty_settings || [])[0];
              if (ls?.enabled !== false) {
                const pts = Math.max(1, Math.floor(Number(ord.total) / Math.max(100, Number(ls?.spend_per_point || 10000))));
                let up = (db.user_points || []).find((u) => u.user_id === ord.customer_id);
                if (!up) {
                  up = { user_id: ord.customer_id, points: 0, lifetime_points: 0, updated_at: nowIso() };
                  db.user_points = db.user_points || [];
                  db.user_points.push(up);
                }
                up.points = Number(up.points || 0) + pts;
                up.lifetime_points = Number(up.lifetime_points || 0) + pts;
                up.updated_at = nowIso();
                ord.points_earned = pts;
              }
            }
          }
          saveDbFn(db);
        }
        return { data: { success: true, status: args._status }, error: null };
      }
      case 'courier_cancel_order': {
        const ord = (db.orders || []).find((o) => o.id === args._order_id);
        if (ord) {
          ord.courier_id = null;
          ord.status = 'pending';
          ord.cancel_reason = args._reason || null;
          ord.updated_at = nowIso();
          saveDbFn(db);
        }
        return { data: { success: true }, error: null };
      }
      case 'courier_partition_enabled':
        return { data: false, error: null };
      case 'driver_public_info': {
        const prof = (db.profiles || []).find((p) => p.id === args._driver_id) || (db.profiles || [])[0];
        return {
          data: {
            id: prof?.id,
            full_name: prof?.full_name || 'Kurir GoGoGo',
            name: prof?.full_name || 'Kurir GoGoGo',
            phone: prof?.phone || '08215006669',
            avatar_url: prof?.avatar_url || null,
            vehicle_plate: prof?.vehicle_plate || 'PA 4521 GG',
            driver_code: prof?.driver_code || 'KRR-001',
            avg_rating: 4.9,
            rating: 4.9,
            review_count: 24,
            rating_count: 24
          },
          error: null
        };
      }
      case 'update_courier_location': {
        const lat = Number(args._lat);
        const lng = Number(args._lng);
        if (!Number.isFinite(lat) || !Number.isFinite(lng)) return { data: { success: false }, error: null };
        const prof = (db.profiles || []).find((p) => p.id === user?.id);
        if (prof) {
          prof.latitude = lat;
          prof.longitude = lng;
          prof.updated_at = nowIso();
        }
        db.courier_locations = db.courier_locations || [];
        const targets = args._order_id
          ? [{ id: args._order_id }]
          : (db.orders || []).filter((o) => o.courier_id === user?.id && !['completed', 'delivered', 'cancelled', 'restaurant_rejected'].includes(o.status));
        for (const t of targets) {
          const ex = db.courier_locations.find((l) => l.order_id === t.id);
          if (ex) {
            Object.assign(ex, { courier_id: user?.id, latitude: lat, longitude: lng, heading: Number(args._heading || 0), recorded_at: nowIso(), updated_at: nowIso() });
          } else {
            db.courier_locations.push({ order_id: t.id, courier_id: user?.id, latitude: lat, longitude: lng, heading: Number(args._heading || 0), recorded_at: nowIso(), updated_at: nowIso() });
          }
        }
        saveDbFn(db);
        return { data: { success: true }, error: null };
      }
      case 'driver_rating_summary': {
        const ratings = (db.driver_ratings || []).filter((r) => !args._driver_id || r.driver_id === args._driver_id);
        const total = ratings.length || 12;
        const avg = ratings.length ? ratings.reduce((s, r) => s + Number(r.rating || 5), 0) / ratings.length : 4.95;
        return {
          data: {
            total,
            average: Number(avg.toFixed(2)),
            avg_rating: Number(avg.toFixed(2)),
            total_ratings: total,
            five_star: ratings.filter((r) => r.rating === 5).length || 11,
            distribution: { '5': total, '4': 0, '3': 0, '2': 0, '1': 0 },
            tags: { 'Ramah & Sopan': 9, 'Tepat Waktu': 8, 'Hati-hati': 6 }
          },
          error: null
        };
      }
      case 'driver_performance': {
        const completed = (db.orders || []).filter((o) => o.status === 'completed');
        const totalFee = completed.reduce((s, o) => s + Number(o.delivery_fee || 8000), 0);
        const prof = (db.profiles || []).find((p) => p.id === (args._driver_id || user?.id)) || (db.profiles || [])[0];
        const count = Math.max(12, completed.length);
        return {
          data: {
            driver_id: prof?.id || user?.id,
            name: prof?.full_name || 'Kurir GoGoGo',
            driver_code: prof?.driver_code || 'KRR-001',
            avatar_url: prof?.avatar_url || null,
            online: Boolean(prof?.driver_online ?? true),
            member_since: prof?.created_at || daysAgoIso(30),
            rank_completed: 1,
            completed_orders: count,
            accepted_orders: count,
            cancelled_by_driver: 0,
            orders_today: 3,
            orders_week: count,
            orders_month: count,
            avg_response_seconds: 18,
            completed_count: count,
            cancelled_count: 0,
            acceptance_rate: 98.5,
            completion_rate: 100,
            avg_delivery_minutes: 15,
            avg_rating: 4.95,
            review_count: 12,
            rating_count: 12,
            total_earnings: totalFee || 96000,
            today_completed: 3,
            today_earnings: 24000,
            week_completed: count,
            week_earnings: totalFee || 96000,
            achievements: ['first_delivery', 'completed_10', 'high_rating']
          },
          error: null
        };
      }
      case 'leaderboard_top_completed':
      case 'leaderboard_top_rated':
      case 'leaderboard_fast_response':
      case 'leaderboard_monthly': {
        const list = (db.profiles || [])
          .filter((p) => (db.user_roles || []).some((r) => r.user_id === p.id && r.role === 'courier'))
          .map((p, idx) => ({
            driver_id: p.id,
            name: p.full_name,
            driver_code: p.driver_code || `KRR-00${idx + 1}`,
            avatar_url: p.avatar_url || null,
            completed_orders: 25 - idx * 7,
            accepted_orders: 25 - idx * 7,
            avg_rating: 4.95 - idx * 0.05,
            review_count: 18 - idx * 5,
            avg_response_seconds: 16 + idx * 4
          }));
        return { data: list, error: null };
      }
      case 'restaurant_respond_order': {
        const ord = (db.orders || []).find((o) => o.id === args._order_id);
        if (!ord) return { data: { success: false, reason: 'not_found' }, error: null };
        ord.restaurant_responded_at = nowIso();
        if (args._accept) {
          ord.status = ord.fulfillment_type === 'pickup' ? 'preparing' : 'pending';
          ord.ready_minutes = args._ready_minutes || 15;
        } else {
          ord.status = 'restaurant_rejected';
          ord.restaurant_reject_reason = args._reason || 'Menu habis';
        }
        ord.updated_at = nowIso();
        saveDbFn(db);
        return { data: { success: true, status: ord.status }, error: null };
      }
      case 'restaurant_self_deliver': {
        const ord = (db.orders || []).find((o) => o.id === args._order_id);
        if (ord) {
          ord.self_delivery = true;
          ord.status = 'preparing';
          ord.updated_at = nowIso();
          saveDbFn(db);
        }
        return { data: { success: true }, error: null };
      }
      case 'restaurant_self_delivery_update': {
        const ord = (db.orders || []).find((o) => o.id === args._order_id);
        if (ord) {
          ord.status = args._status;
          if (args._status === 'completed') ord.delivered_at = nowIso();
          ord.updated_at = nowIso();
          saveDbFn(db);
        }
        return { data: { success: true, status: args._status }, error: null };
      }
      case 'owner_online_couriers': {
        const online = (db.profiles || [])
          .filter((p) => p.driver_online)
          .map((p) => ({
            id: p.id,
            full_name: p.full_name,
            phone: p.phone,
            vehicle_plate: p.vehicle_plate || 'PA 4521 GG',
            region_id: p.region_id || 'abepura',
            driver_online_changed_at: p.driver_online_changed_at || nowIso()
          }));
        return { data: online, error: null };
      }
      case 'restaurant_review_summary': {
        const revs = (db.restaurant_reviews || []).filter((r) => r.restaurant_id === args._restaurant_id);
        const count = revs.length;
        const avg = count ? revs.reduce((s, r) => s + Number(r.rating || 5), 0) / count : 4.9;
        return {
          data: {
            average_rating: Number(avg.toFixed(1)),
            total_reviews: count,
            counts: { 5: count || 1, 4: 0, 3: 0, 2: 0, 1: 0 }
          },
          error: null
        };
      }
      case 'restaurant_reviews_public':
      case 'admin_restaurant_reviews': {
        let revs = [...(db.restaurant_reviews || [])];
        if (args._restaurant_id) revs = revs.filter((r) => r.restaurant_id === args._restaurant_id);
        if (args._rating) revs = revs.filter((r) => Number(r.rating) === Number(args._rating));
        return { data: revs, error: null };
      }
      case 'admin_review_reports':
        return { data: db.review_reports || [], error: null };
      case 'admin_report_summary':
      case 'admin_report_summary_region': {
        const ords = db.orders || [];
        const completed = ords.filter((o) => o.status === 'completed');
        const gross = completed.reduce((s, o) => s + Number(o.subtotal || o.total || 0), 0);
        const delFee = completed.reduce((s, o) => s + Number(o.delivery_fee || 0), 0);
        const disc = completed.reduce((s, o) => s + Number(o.discount || 0), 0);
        const appFee = completed.length * 2000;
        const markupRev = completed.length * 4000;
        return {
          data: {
            completed_orders: completed.length,
            items_sold: completed.length * 2,
            menu_lines: completed.length * 2,
            gross_sales: gross,
            delivery_fee: delFee,
            discount: disc,
            fee_revenue: appFee + markupRev,
            app_fee_revenue: appFee,
            markup_revenue: markupRev,
            restaurant_revenue: Math.max(0, gross - markupRev)
          },
          error: null
        };
      }
      case 'admin_report_breakdown':
      case 'admin_report_breakdown_region':
      case 'admin_report_restaurants':
      case 'admin_report_restaurants_region': {
        const list = (db.restaurants || []).map((r) => {
          const rOrders = (db.orders || []).filter((o) => o.restaurant_id === r.id);
          const sales = rOrders.reduce((s, o) => s + Number(o.subtotal || o.total || 0), 0);
          return {
            restaurant_id: r.id,
            restaurant_name: r.name,
            merchant_type: r.merchant_type,
            completed_orders: rOrders.length,
            items_sold: rOrders.length * 2,
            gross_sales: sales,
            delivery_fee: rOrders.length * 8000,
            fee_revenue: rOrders.length * 4000,
            app_fee_revenue: rOrders.length * 2000,
            markup_revenue: rOrders.length * 2000,
            restaurant_revenue: Math.max(0, sales - rOrders.length * 2000)
          };
        });
        return { data: list, error: null };
      }
      case 'admin_report_daily':
      case 'admin_report_daily_region': {
        const today = new Date().toISOString().slice(0, 10);
        return {
          data: [
            {
              day: today,
              date: today,
              completed_orders: (db.orders || []).length,
              gross_sales: (db.orders || []).reduce((s, o) => s + Number(o.total || 0), 0),
              fee_revenue: (db.orders || []).length * 4000
            }
          ],
          error: null
        };
      }
      case 'admin_driver_performance_list': {
        const list = (db.profiles || [])
          .filter((p) => (db.user_roles || []).some((r) => r.user_id === p.id && r.role === 'courier'))
          .map((p) => ({
            driver_id: p.id,
            name: p.full_name,
            driver_code: p.driver_code || 'KRR-001',
            phone: p.phone,
            driver_online: Boolean(p.driver_online),
            completed_orders: 12,
            cancelled_orders: 0,
            completion_rate: 100,
            avg_delivery_minutes: 15,
            avg_rating: 4.95,
            total_earnings: 144000
          }));
        return { data: list, error: null };
      }
      case 'admin_courier_map': {
        const list = (db.profiles || [])
          .filter((p) => (db.user_roles || []).some((r) => r.user_id === p.id && r.role === 'courier'))
          .map((p) => ({
            driver_id: p.id,
            full_name: p.full_name,
            phone: p.phone,
            driver_online: Boolean(p.driver_online),
            latitude: p.latitude || -2.6068,
            longitude: p.longitude || 140.6692,
            updated_at: nowIso()
          }));
        return { data: list, error: null };
      }
      case 'admin_set_profile_region': {
        const prof = (db.profiles || []).find((p) => p.id === args._user_id);
        if (prof) {
          prof.region_id = args._region_id;
          saveDbFn(db);
        }
        return { data: true, error: null };
      }
      case 'admin_get_wa_gateway':
        return {
          data: db.wa_gateway_config || {
            enabled: true,
            delay_minutes: 0,
            token: 'FONNTE_DEMO_TOKEN',
            courier_group_enabled: true,
            courier_group_id: '120363049281726@g.us'
          },
          error: null
        };
      case 'admin_set_wa_gateway':
        db.wa_gateway_config = {
          ...(db.wa_gateway_config || {}),
          enabled: Boolean(args._enabled),
          delay_minutes: Number(args._delay_minutes || 0),
          token: args._token || db.wa_gateway_config?.token || 'FONNTE_DEMO_TOKEN'
        };
        saveDbFn(db);
        return { data: { success: true }, error: null };
      case 'admin_set_courier_group':
        db.wa_gateway_config = {
          ...(db.wa_gateway_config || {}),
          courier_group_enabled: Boolean(args._enabled),
          courier_group_id: args._group_id || ''
        };
        saveDbFn(db);
        return { data: { success: true }, error: null };
      case 'admin_test_wa_gateway':
      case 'admin_test_courier_group':
        return { data: { success: true, message: 'Pesan tes WhatsApp berhasil dikirim (Mode Simulasi Lokal).' }, error: null };
      case 'service_fee_invoice_lines_v2': {
        const ords = (db.orders || []).filter((o) => !args._restaurant_id || o.restaurant_id === args._restaurant_id);
        const lines = [];
        for (const o of ords) {
          const items = (db.order_items || []).filter((oi) => oi.order_id === o.id);
          for (const it of items) {
            lines.push({
              order_id: o.id,
              order_number: o.order_number,
              created_at: o.created_at,
              customer_name: o.customer_name,
              menu_name: it.menu_name,
              quantity: it.quantity,
              restaurant_price: it.restaurant_price || it.price - 2000,
              service_fee: it.markup_amount || 2000,
              customer_price: it.price,
              order_app_fee: o.app_fee || 2000,
              status: o.status
            });
          }
        }
        return { data: lines, error: null };
      }
      case 'generate_service_fee_invoice': {
        const rest = (db.restaurants || []).find((r) => r.id === args._restaurant_id) || (db.restaurants || [])[0];
        const inv = {
          id: uuid(),
          invoice_number: 'INV-' + Date.now().toString().slice(-6),
          restaurant_id: rest?.id,
          restaurant_name: rest?.name || 'Restoran Mitra',
          period_label: args._period_label || 'Periode Ini',
          period_start: args._from || daysAgoIso(7),
          period_end: args._to || nowIso(),
          due_date: new Date(Date.now() + (Number(args._due_days) || 7) * 86400 * 1000).toISOString(),
          total_orders: 5,
          total_items: 10,
          total_fee: 20000,
          status: 'unpaid',
          paid_at: null,
          created_at: nowIso()
        };
        db.service_fee_invoices = db.service_fee_invoices || [];
        db.service_fee_invoices.unshift(inv);
        saveDbFn(db);
        return { data: inv, error: null };
      }
      case 'admin_send_invoice_wa':
        return { data: 'sent', error: null };
      case 'admin_push_health':
        return {
          data: { active_subscriptions: 18, totals_24h: { sent: 42, delivered: 42, failed: 0 } },
          error: null
        };
      case 'wallet_topup': {
        const amt = Number(args._amount || 0);
        if (!user?.id) return { data: { success: false, message: 'Silakan masuk akun terlebih dahulu.' }, error: null };
        if (amt < 10000 || amt > 10000000) return { data: { success: false, message: 'Nominal Top-Up harus Rp 10.000 - Rp 10.000.000.' }, error: null };
        const prof = (db.profiles || []).find((p) => p.id === user.id);
        if (!prof) return { data: { success: false, message: 'Profil tidak ditemukan.' }, error: null };
        prof.wallet_balance = Number(prof.wallet_balance || 0) + amt;
        prof.updated_at = nowIso();
        db.wallet_transactions = db.wallet_transactions || [];
        db.wallet_transactions.unshift({
          id: uuid(),
          user_id: user.id,
          type: 'topup',
          amount: amt,
          description: `Top-Up GoGoGo Pay (${args._method || 'Instan'})`,
          created_at: nowIso()
        });
        saveDbFn(db);
        return { data: { success: true, wallet_balance: prof.wallet_balance }, error: null };
      }
      case 'wallet_transfer': {
        const amt = Number(args._amount || 0);
        const target = String(args._recipient || '').trim().toLowerCase();
        const note = String(args._note || '').trim();
        if (!user?.id) return { data: { success: false, message: 'Silakan masuk akun terlebih dahulu.' }, error: null };
        if (!target) return { data: { success: false, message: 'Masukkan email atau nomor WA tujuan.' }, error: null };
        if (amt < 5000) return { data: { success: false, message: 'Minimal transfer Rp 5.000.' }, error: null };
        const sender = (db.profiles || []).find((p) => p.id === user.id);
        if (!sender || Number(sender.wallet_balance || 0) < amt) {
          return { data: { success: false, message: 'Saldo GoGoGo Pay tidak mencukupi.' }, error: null };
        }
        const digits = target.replace(/\D/g, '');
        const rec = (db.profiles || []).find((p) => {
          if (p.id === user.id) return false;
          if (String(p.email || '').toLowerCase() === target) return true;
          if (digits && String(p.phone || '').replace(/\D/g, '').endsWith(digits.replace(/^0|^62/, ''))) return true;
          return false;
        });
        if (!rec) return { data: { success: false, message: 'Akun penerima tidak ditemukan di GoGoGo.' }, error: null };
        sender.wallet_balance = Number(sender.wallet_balance || 0) - amt;
        rec.wallet_balance = Number(rec.wallet_balance || 0) + amt;
        db.wallet_transactions = db.wallet_transactions || [];
        db.wallet_transactions.unshift(
          {
            id: uuid(),
            user_id: sender.id,
            type: 'transfer_out',
            amount: -amt,
            description: `Transfer ke ${rec.full_name || target}${note ? ' (' + note + ')' : ''}`,
            created_at: nowIso()
          },
          {
            id: uuid(),
            user_id: rec.id,
            type: 'transfer_in',
            amount: amt,
            description: `Terima transfer dari ${sender.full_name || sender.email}${note ? ' (' + note + ')' : ''}`,
            created_at: nowIso()
          }
        );
        saveDbFn(db);
        return { data: { success: true, wallet_balance: sender.wallet_balance, recipient_name: rec.full_name || target }, error: null };
      }
      case 'wallet_pay_order': {
        const amt = Number(args._amount || 0);
        if (!user?.id) return { data: { success: false, message: 'Silakan masuk akun terlebih dahulu.' }, error: null };
        const prof = (db.profiles || []).find((p) => p.id === user.id);
        if (!prof || Number(prof.wallet_balance || 0) < amt) {
          return { data: { success: false, message: 'Saldo GoGoGo Pay tidak mencukupi.' }, error: null };
        }
        prof.wallet_balance = Number(prof.wallet_balance || 0) - amt;
        const ord = (db.orders || []).find((o) => o.id === args._order_id);
        if (ord) {
          ord.payment_method = 'wallet';
          ord.payment_status = 'paid';
          ord.updated_at = nowIso();
        }
        if (amt > 0) {
          db.wallet_transactions = db.wallet_transactions || [];
          db.wallet_transactions.unshift({
            id: uuid(),
            user_id: user.id,
            type: 'payment',
            amount: -amt,
            description: args._description || 'Pembayaran Pesanan GoGoGo',
            created_at: nowIso()
          });
        }
        saveDbFn(db);
        return { data: { success: true, wallet_balance: prof.wallet_balance }, error: null };
      }
      case 'wallet_pay_merchant': {
        const amt = Number(args._amount || 0);
        const note = String(args._note || '').trim();
        if (!user?.id) return { data: { success: false, message: 'Silakan masuk akun terlebih dahulu.' }, error: null };
        if (amt < 1000) return { data: { success: false, message: 'Minimal pembayaran Rp 1.000.' }, error: null };
        const prof = (db.profiles || []).find((p) => p.id === user.id);
        if (!prof || Number(prof.wallet_balance || 0) < amt) {
          return { data: { success: false, message: 'Saldo GoGoGo Pay tidak mencukupi.' }, error: null };
        }
        const rest = (db.restaurants || []).find((r) => r.id === args._restaurant_id);
        if (!rest) return { data: { success: false, message: 'Merchant tidak ditemukan.' }, error: null };
        prof.wallet_balance = Number(prof.wallet_balance || 0) - amt;
        db.wallet_transactions = db.wallet_transactions || [];
        db.wallet_transactions.unshift({
          id: uuid(),
          user_id: user.id,
          type: 'merchant_pay',
          amount: -amt,
          description: `Bayar QR/Merchant ${rest.name}${note ? ' (' + note + ')' : ''}`,
          created_at: nowIso()
        });
        saveDbFn(db);
        return { data: { success: true, wallet_balance: prof.wallet_balance, restaurant_name: rest.name }, error: null };
      }
      default:
        return { data: { success: true }, error: null };
    }
  }

  function createLocalSupabaseClient() {
    let currentUser = getDefaultUser();
    const authListeners = new Set();

    function buildSession(user) {
      if (!user) return null;
      return {
        access_token: 'local-jwt-token-' + user.id,
        refresh_token: 'local-refresh-token-' + user.id,
        expires_in: 3600 * 24 * 30,
        expires_at: Math.floor(Date.now() / 1000) + 3600 * 24 * 30,
        token_type: 'bearer',
        user
      };
    }

    if (!localStorage.getItem(SESSION_KEY)) {
      localStorage.setItem(SESSION_KEY, JSON.stringify({ user: currentUser, session: buildSession(currentUser) }));
    }

    function notifyAuth(event, session) {
      for (const cb of authListeners) {
        try {
          cb(event, session);
        } catch (e) {
          console.error(e);
        }
      }
    }

    function loginWithEmail(emailInput, fullNameInput, phoneInput) {
      const cleanEmail = String(emailInput || 'owner@gogogo.app').trim().toLowerCase();
      const db = loadDB();
      let existingProf = (db.profiles || []).find((p) => String(p.email || '').toLowerCase() === cleanEmail);
      const isPrimaryOwner = cleanEmail === 'owner@gogogo.app' || cleanEmail === 'exceedexpress.id@gmail.com';
      const uid = existingProf ? existingProf.id : (isPrimaryOwner ? 'user-owner-main-001' : 'user-' + cleanEmail.replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, ''));
      const fullName =
        fullNameInput ||
        existingProf?.full_name ||
        cleanEmail
          .split('@')[0]
          .replace(/[._-]/g, ' ')
          .replace(/\b\w/g, (c) => c.toUpperCase());

      currentUser = {
        id: uid,
        aud: 'authenticated',
        role: 'authenticated',
        email: cleanEmail,
        email_confirmed_at: nowIso(),
        phone: phoneInput || existingProf?.phone || '08215006669',
        created_at: existingProf?.created_at || nowIso(),
        updated_at: nowIso(),
        user_metadata: {
          full_name: fullName,
          phone: phoneInput || existingProf?.phone || '08215006669'
        },
        app_metadata: { provider: 'email', providers: ['email'] }
      };

      const session = buildSession(currentUser);
      localStorage.setItem(SESSION_KEY, JSON.stringify({ user: currentUser, session }));
      ensureUserInDB(db, currentUser);
      saveDB(db);
      notifyAuth('SIGNED_IN', session);
      return { user: currentUser, session };
    }

    const client = {
      __isLocalEngine: true,
      __loginWithEmail: loginWithEmail,
      __getDB: loadDB,
      __saveDB: saveDB,
      __resetDB: () => {
        localStorage.removeItem(STORAGE_KEY);
        const fresh = loadDB();
        window.location.reload();
        return fresh;
      },

      auth: {
        async getSession() {
          try {
            const raw = localStorage.getItem(SESSION_KEY);
            if (!raw) return { data: { session: null }, error: null };
            const parsed = JSON.parse(raw);
            currentUser = parsed.user;
            return { data: { session: parsed.session }, error: null };
          } catch (e) {
            return { data: { session: buildSession(currentUser) }, error: null };
          }
        },
        async getUser() {
          const { data } = await this.getSession();
          return { data: { user: data.session?.user ?? null }, error: null };
        },
        async signInWithPassword({ email }) {
          const { user, session } = loginWithEmail(email);
          return { data: { user, session }, error: null };
        },
        async signUp({ email, options }) {
          const meta = options?.data || {};
          const { user, session } = loginWithEmail(email, meta.full_name, meta.phone);
          return { data: { user, session }, error: null };
        },
        async signInWithOAuth(params = {}) {
          const provider = params?.provider || 'google';
          const qEmail = params?.options?.queryParams?.email;
          const targetEmail = qEmail || currentUser?.email || 'google.user@gogogo.app';
          const { user, session } = loginWithEmail(targetEmail);
          user.app_metadata = { provider, providers: [provider] };
          localStorage.setItem(SESSION_KEY, JSON.stringify({ user, session }));
          return { data: { provider, url: null, user, session }, error: null };
        },
        async resetPasswordForEmail() {
          return { data: {}, error: null };
        },
        async updateUser(updates) {
          if (currentUser) {
            if (updates.email) currentUser.email = updates.email;
            if (updates.data) currentUser.user_metadata = { ...currentUser.user_metadata, ...updates.data };
            const session = buildSession(currentUser);
            localStorage.setItem(SESSION_KEY, JSON.stringify({ user: currentUser, session }));
            notifyAuth('USER_UPDATED', session);
          }
          return { data: { user: currentUser }, error: null };
        },
        async signOut() {
          currentUser = null;
          localStorage.removeItem(SESSION_KEY);
          notifyAuth('SIGNED_OUT', null);
          return { error: null };
        },
        onAuthStateChange(callback) {
          authListeners.add(callback);
          setTimeout(async () => {
            const { data } = await client.auth.getSession();
            callback('INITIAL_SESSION', data.session);
          }, 0);
          return {
            data: {
              subscription: {
                unsubscribe: () => authListeners.delete(callback)
              }
            }
          };
        }
      },

      from(tableName) {
        return new LocalQueryBuilder(tableName, loadDB, saveDB);
      },

      rpc(fnName, args = {}) {
        const p = executeLocalRpc(fnName, args, loadDB, saveDB, () => currentUser);
        return {
          then: (onF, onR) => p.then(onF, onR),
          catch: (onR) => p.catch(onR),
          finally: (onFin) => p.finally(onFin),
          single: () => p,
          maybeSingle: () => p
        };
      },

      storage: {
        from(bucketName) {
          return {
            async upload(path, file) {
              try {
                const dataUrl = await new Promise((resolve) => {
                  if (typeof FileReader !== 'undefined' && file instanceof Blob) {
                    const reader = new FileReader();
                    reader.onloadend = () => resolve(reader.result);
                    reader.onerror = () => resolve('');
                    reader.readAsDataURL(file);
                  } else {
                    resolve('');
                  }
                });
                const key = `gogogo_storage_${bucketName}_${path}`;
                if (dataUrl) {
                  try {
                    localStorage.setItem(key, dataUrl);
                  } catch (e) {}
                }
                return { data: { path, fullPath: `${bucketName}/${path}` }, error: null };
              } catch (e) {
                return { data: { path }, error: null };
              }
            },
            async remove() {
              return { data: [], error: null };
            },
            async createSignedUrl(path) {
              const key = `gogogo_storage_${bucketName}_${path}`;
              const stored = localStorage.getItem(key);
              return {
                data: {
                  signedUrl:
                    stored ||
                    'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?auto=format&fit=crop&w=600&q=80'
                },
                error: null
              };
            },
            getPublicUrl(path) {
              const key = `gogogo_storage_${bucketName}_${path}`;
              const stored = localStorage.getItem(key);
              return {
                data: {
                  publicUrl:
                    stored ||
                    'https://images.unsplash.com/photo-1556742049-0cfed4f6a45d?auto=format&fit=crop&w=600&q=80'
                }
              };
            }
          };
        }
      },

      functions: {
        async invoke(fnName, opts = {}) {
          return { data: { ok: true, function: fnName, body: opts?.body }, error: null };
        }
      },

      channel(name) {
        const ch = {
          name,
          on() {
            return ch;
          },
          subscribe(cb) {
            if (typeof cb === 'function') setTimeout(() => cb('SUBSCRIBED'), 0);
            return ch;
          },
          unsubscribe() {
            return Promise.resolve('ok');
          }
        };
        return ch;
      },

      removeChannel() {
        return Promise.resolve('ok');
      }
    };

    return client;
  }

  window.__gogogoAiGenerate = async function (payload) {
    const name = payload?.name || payload?.prompt || 'Menu Spesial';
    const category = payload?.category || 'Kuliner';
    return `${name} (${category}) dibuat dengan bahan segar pilihan berkualitas tinggi, porsi mengenyangkan, dan cita rasa khas yang lezat di Go Makan.`;
  };

  function normalizeWaPhone(raw) {
    let digits = String(raw || '').replace(/\D/g, '');
    if (!digits) return '';
    if (digits.startsWith('0')) digits = '62' + digits.slice(1);
    else if (digits.startsWith('8')) digits = '62' + digits;
    return digits;
  }

  window.__gogogoServerFn = async function (fnId, args) {
    const firstArg = Array.isArray(args) ? args[0] : args;
    const input =
      firstArg && typeof firstArg === 'object' && 'data' in firstArg
        ? firstArg.data ?? {}
        : firstArg ?? {};
    const sb = window.__gogogoClientInstance;
    const ts = nowIso();

    const getAuthUser = async () => {
      if (!sb?.auth) return null;
      try {
        const { data: sData } = await sb.auth.getSession();
        if (sData?.session?.user) return sData.session.user;
        const { data: uData } = await sb.auth.getUser();
        return uData?.user || null;
      } catch (e) {
        return null;
      }
    };

    // 1. _ne: GET WA verification status
    if (fnId === '7a46aeb3f1a87471634259653aed13bfb4036a9c64b3d5204c51f9b922be5669') {
      try {
        let enabled = false;
        let verified = true;
        let phone = '';
        if (sb) {
          const { data: enData } = await sb.rpc('wa_verification_enabled');
          enabled = enData === true;
          const user = await getAuthUser();
          if (user) {
            const { data: prof } = await sb
              .from('profiles')
              .select('phone, phone_verified')
              .eq('id', user.id)
              .maybeSingle();
            if (prof) {
              phone = prof.phone || '';
              verified = enabled ? Boolean(prof.phone_verified) : true;
            }
          }
        }
        return {
          enabled,
          verified,
          required: Boolean(enabled && !verified),
          promptOnLogin: false,
          phone
        };
      } catch (e) {
        return { enabled: false, verified: true, required: false, phone: '', success: true };
      }
    }

    // 2. vne: POST send WA OTP
    if (fnId === '53efee3bb6471cc1199e89847818198aa6ef3afc5b7e78461a5e1c020ae3a8a6') {
      return { ok: true, phone: normalizeWaPhone(input.phone) || '628215006669' };
    }

    // 3. yne: POST verify WA OTP
    if (fnId === '45c06d33e74bc170bf080688ab7372eb89da7321232d05e1353688233683dcb5') {
      if (sb) {
        const user = await getAuthUser();
        if (user) {
          await sb
            .from('profiles')
            .update({ phone_verified: true, phone_verified_at: ts })
            .eq('id', user.id);
        }
      }
      return { ok: true };
    }

    // 4. dre (PartnerPortal submit): POST { kind, region, identity, details }
    if (fnId === '2d2b3743c278c644cf1fded185a4ae8f06198aae027670440e89d7809a270e8f') {
      if (!sb) throw new Error('Koneksi database belum siap.');
      const user = await getAuthUser();
      if (!user) throw new Error('Silakan masuk akun terlebih dahulu.');

      const kind = input.kind === 'courier' ? 'courier' : 'owner';
      const regionId = String(input.region || 'abepura').trim() || 'abepura';
      const details = input.details && typeof input.details === 'object' ? input.details : {};

      let regFee = {
        enabled: false,
        amount: 0,
        bank: '',
        account: '',
        recipient: '',
        qris_path: ''
      };
      try {
        const { data: feeRow } = await sb
          .from('app_settings')
          .select('value')
          .eq('key', 'partner_registration_fee')
          .maybeSingle();
        if (feeRow?.value && typeof feeRow.value === 'object') {
          regFee = {
            enabled: Boolean(feeRow.value.enabled),
            amount: Number(feeRow.value.amount || 0),
            bank: String(feeRow.value.bank || ''),
            account: String(feeRow.value.account || ''),
            recipient: String(feeRow.value.recipient || ''),
            qris_path: String(feeRow.value.qris_path || '')
          };
        }
      } catch (e) {}

      const { data: existingApps, error: checkErr } = await sb
        .from('partner_applications')
        .select('id, status')
        .eq('user_id', user.id)
        .eq('kind', kind);
      if (checkErr) throw new Error(checkErr.message);

      if (Array.isArray(existingApps) && existingApps.some((a) => a.status === 'pending')) {
        throw new Error('Pendaftaran kamu masih menunggu persetujuan Admin.');
      }

      const payload = {
        user_id: user.id,
        kind,
        status: 'pending',
        region_id: regionId,
        full_name: String(details.owner || details.name || user.user_metadata?.full_name || ''),
        business_name: String(details.name || ''),
        phone: String(details.phone || ''),
        identity_path: input.identity || null,
        payment_proof_path: details.payment_proof || null,
        details,
        registration_fee: regFee,
        payment_received: false,
        payment_confirmed_at: null,
        review_note: null,
        reviewed_at: null,
        reviewed_by: null
      };

      if (Array.isArray(existingApps) && existingApps.length > 0) {
        const targetId = existingApps[0].id;
        for (let k = 1; k < existingApps.length; k++) {
          await sb.from('partner_applications').delete().eq('id', existingApps[k].id);
        }
        const { error: updErr } = await sb
          .from('partner_applications')
          .update(payload)
          .eq('id', targetId);
        if (updErr) throw new Error(updErr.message);
      } else {
        const { error: insErr } = await sb.from('partner_applications').insert(payload);
        if (insErr) throw new Error(insErr.message);
      }
      return { ok: true, success: true };
    }

    // 5. fre ($Qe Admin change user WA phone): POST { userId, phone, reason }
    if (fnId === 'd424da528cb5e7d6dfe2e2d820a357d1f994ed1f1017e1b74c373636120e4f25') {
      if (!sb) throw new Error('Koneksi database belum siap.');
      const normalized = normalizeWaPhone(input.phone);
      if (!normalized) throw new Error('Nomor WhatsApp tidak valid.');
      const { data: prof } = await sb.from('profiles').select('phone').eq('id', input.userId).maybeSingle();
      const { error: updErr } = await sb
        .from('profiles')
        .update({ phone: normalized, phone_verified: false, phone_verified_at: null, updated_at: ts })
        .eq('id', input.userId);
      if (updErr) throw new Error(updErr.message);
      await sb.from('phone_change_audit').insert({
        user_id: input.userId,
        old_phone: prof?.phone || '',
        new_phone: normalized,
        reason: String(input.reason || 'Diubah oleh Admin').trim()
      });
      return { ok: true };
    }

    // 6. pre (Admin approve/reject partner_applications): POST { id, approve, note, paymentReceived }
    if (fnId === '362004c132d59e3307265158063d923b91bf40dcfbdd356559d9f9d45744923e') {
      if (!sb) throw new Error('Koneksi database belum siap.');
      const adminUser = await getAuthUser();
      const { id, approve, note, paymentReceived } = input;
      if (!id) throw new Error('ID pendaftaran tidak valid.');

      const { data: app, error: fetchErr } = await sb
        .from('partner_applications')
        .select('*')
        .eq('id', id)
        .single();
      if (fetchErr || !app) throw new Error(fetchErr?.message || 'Data pendaftaran tidak ditemukan.');

      const cleanNote = String(note || '').trim();
      if (!approve) {
        if (cleanNote.length < 5) throw new Error('Isi alasan penolakan minimal 5 karakter.');
        const { error: rejErr } = await sb
          .from('partner_applications')
          .update({
            status: 'rejected',
            review_note: cleanNote,
            reviewed_at: ts,
            reviewed_by: adminUser?.id || null
          })
          .eq('id', id);
        if (rejErr) throw new Error(rejErr.message);
        return { ok: true, status: 'rejected' };
      }

      const updateApp = {
        status: 'approved',
        review_note: cleanNote || 'Disetujui oleh Admin',
        reviewed_at: ts,
        reviewed_by: adminUser?.id || null
      };
      if (paymentReceived) {
        updateApp.payment_received = true;
        updateApp.payment_confirmed_at = ts;
      }
      const { error: appErr } = await sb.from('partner_applications').update(updateApp).eq('id', id);
      if (appErr) throw new Error(appErr.message);

      const roleToGrant = app.kind === 'courier' ? 'courier' : 'owner';
      const targetUserId = app.user_id;
      const details = app.details && typeof app.details === 'object' ? app.details : {};

      if (targetUserId) {
        const { data: existingProf } = await sb
          .from('profiles')
          .select('id')
          .eq('id', targetUserId)
          .maybeSingle();

        const profPatch = {
          region_id: app.region_id || 'abepura',
          updated_at: ts
        };
        if (details.phone || app.phone) profPatch.phone = details.phone || app.phone;
        if (app.kind === 'courier') {
          if (details.name || app.full_name) profPatch.full_name = details.name || app.full_name;
          if (details.plate) profPatch.vehicle_plate = details.plate;
          if (details.driver_photo) profPatch.avatar_url = details.driver_photo;
          profPatch.driver_code = 'KRR-' + String(targetUserId).slice(0, 4).toUpperCase();
        } else if (details.owner || app.full_name) {
          profPatch.full_name = details.owner || app.full_name;
        }

        if (existingProf) {
          await sb.from('profiles').update(profPatch).eq('id', targetUserId);
        } else {
          await sb.from('profiles').insert({ id: targetUserId, ...profPatch });
        }

        const { error: roleErr } = await sb
          .from('user_roles')
          .upsert({ user_id: targetUserId, role: roleToGrant }, { onConflict: 'user_id,role', ignoreDuplicates: true });
        if (roleErr) throw new Error(roleErr.message);
      }

      if (app.kind === 'owner') {
        const restName = String(details.name || app.business_name || 'Mitra GoGoGo').trim();
        const openH =
          details.open && details.close ? `${details.open} - ${details.close}` : '08:00 - 22:00';
        const { data: dupRest } = await sb
          .from('restaurants')
          .select('id')
          .eq('owner_id', targetUserId)
          .eq('name', restName)
          .maybeSingle();

        let restId = dupRest?.id || null;
        if (!restId) {
          const { data: newRest, error: restErr } = await sb
            .from('restaurants')
            .insert({
              owner_id: targetUserId || null,
              name: restName,
              description: `Mitra resmi Go Makan di ${details.address || app.region_id || 'Abepura'}`,
              address: details.address || '',
              category: 'Masakan Nusantara',
              merchant_type: 'food',
              region_id: app.region_id || 'abepura',
              latitude: details.lat != null ? Number(details.lat) : -2.6068,
              longitude: details.lng != null ? Number(details.lng) : 140.6692,
              opening_hours: openH,
              delivery_base_fee: 5000,
              delivery_base_km: 2,
              delivery_per_km: 2000,
              is_popular: false,
              is_active: true,
              is_temporarily_closed: false
            })
            .select('id')
            .single();
          if (restErr) throw new Error(restErr.message);
          restId = newRest?.id || null;
        }

        if (restId) {
          const waPhone = normalizeWaPhone(details.phone || app.phone);
          if (waPhone) {
            await sb
              .from('restaurant_contacts')
              .upsert({ restaurant_id: restId, whatsapp_number: waPhone }, { onConflict: 'restaurant_id' });
          }
          const openTime = details.open ? `${details.open}:00` : '08:00:00';
          const closeTime = details.close ? `${details.close}:00` : '22:00:00';
          const hoursRows = [0, 1, 2, 3, 4, 5, 6].map((day) => ({
            restaurant_id: restId,
            day_of_week: day,
            open_time: openTime,
            close_time: closeTime,
            is_closed: false
          }));
          await sb
            .from('merchant_operating_hours')
            .upsert(hoursRows, { onConflict: 'restaurant_id,day_of_week' });
        }
      }

      return { ok: true, status: 'approved' };
    }

    // 7. IZe (Moderation users list): GET
    if (fnId === '755f965700f562d3c79d01c915e104b8cbc1961f2d87df9f8ce584b9201629b1') {
      if (!sb) return [];
      const [profRes, roleRes, ordRes] = await Promise.all([
        sb.from('profiles').select('*').order('created_at', { ascending: false }),
        sb.from('user_roles').select('user_id, role'),
        sb.from('orders').select('customer_id, status')
      ]);
      const rolesMap = new Map();
      for (const r of roleRes.data || []) {
        if (!rolesMap.has(r.user_id)) rolesMap.set(r.user_id, []);
        rolesMap.get(r.user_id).push(r.role);
      }
      const statsMap = new Map();
      for (const o of ordRes.data || []) {
        if (!o.customer_id) continue;
        if (!statsMap.has(o.customer_id)) statsMap.set(o.customer_id, { comp: 0, canc: 0 });
        const st = statsMap.get(o.customer_id);
        if (o.status === 'completed' || o.status === 'delivered') st.comp++;
        else if (o.status === 'cancelled' || o.status === 'restaurant_rejected') st.canc++;
      }
      return (profRes.data || []).map((p) => {
        const st = statsMap.get(p.id) || { comp: 0, canc: 0 };
        return {
          id: p.id,
          full_name: p.full_name,
          email: p.email,
          phone: p.phone,
          address: p.address,
          status: p.moderation_status || 'active',
          reason: p.moderation_reason || null,
          roles: rolesMap.get(p.id) || [],
          created_at: p.created_at,
          last_sign_in_at: p.last_sign_in_at || p.updated_at || p.created_at,
          completed_orders: st.comp,
          cancelled_orders: st.canc
        };
      });
    }

    // 8. LZe (Moderation action): POST { userId, action, reason }
    if (fnId === 'bf9943f77123b6d690ded09cbe431189e17c5d54b912ae54aa586b5bf6f84d9e') {
      if (!sb) throw new Error('Koneksi database belum siap.');
      const map = { warn: 'warned', suspend: 'suspended', unsuspend: 'active', block: 'blocked', unblock: 'active' };
      const status = map[input.action] || 'active';
      const { error: updErr } = await sb
        .from('profiles')
        .update({ moderation_status: status, moderation_reason: input.reason || null, updated_at: ts })
        .eq('id', input.userId);
      if (updErr) throw new Error(updErr.message);
      await sb.from('moderation_audit_logs').insert({
        user_id: input.userId,
        action: input.action,
        reason: input.reason || null
      });
      return { ok: true };
    }

    // 9. RZe (Moderation user detail): GET { userId }
    if (fnId === '087625aac6bd6ae8d6f7c11dc379e01b03e93444e0ecba319718a86e426b9b68') {
      if (!sb || !input.userId) return { orders: [], audit: [] };
      const [ordRes, audRes] = await Promise.all([
        sb.from('orders').select('id, order_number, status, total, created_at').eq('customer_id', input.userId).order('created_at', { ascending: false }).limit(30),
        sb.from('moderation_audit_logs').select('*').eq('user_id', input.userId).order('created_at', { ascending: false }).limit(30)
      ]);
      return { orders: ordRes.data || [], audit: audRes.data || [] };
    }

    // 10. a$e (Profile self-delete account): POST { confirmation }
    if (fnId === '2b4b2a5c8048d82c68061484a7b2647f6e7fd2b72191f95c4da6d4cbe29c21f6') {
      if (!sb) return { ok: true };
      const user = await getAuthUser();
      if (!user) return { ok: false, message: 'Tidak ada sesi login.' };
      const { data: activeOrds } = await sb
        .from('orders')
        .select('id, status')
        .eq('customer_id', user.id)
        .not('status', 'in', '(completed,delivered,cancelled,restaurant_rejected)');
      if (Array.isArray(activeOrds) && activeOrds.length > 0) {
        return { ok: false, message: 'Selesaikan atau batalkan pesanan berjalan terlebih dahulu.' };
      }
      await Promise.all([
        sb.from('favorites').delete().eq('user_id', user.id),
        sb.from('saved_addresses').delete().eq('user_id', user.id),
        sb.from('user_roles').delete().eq('user_id', user.id),
        sb.from('profiles').update({
          full_name: 'Pengguna Terhapus',
          phone: null,
          address: null,
          avatar_url: null,
          moderation_status: 'blocked',
          updated_at: ts
        }).eq('id', user.id)
      ]);
      return { ok: true };
    }

    // 11. o$e (Public account deletion request): POST { name, phone, reason }
    if (fnId === 'f98ba26fc13f172655830dda504ec1cac7a056b81d5a42c99c2d672bd70d28c1') {
      if (!sb) return { ok: true };
      const { error } = await sb.from('account_deletion_requests').insert({
        name: String(input.name || '').trim(),
        phone: String(input.phone || '').trim(),
        reason: input.reason ? String(input.reason).trim() : null,
        status: 'menunggu'
      });
      if (error) throw new Error(error.message);
      return { ok: true };
    }

    // 12. s$e (Admin list account deletion requests): GET
    if (fnId === '0278dc569641e1ffef0cec8811f844c84791efbfeaed9f80bbb82f011dc5928e') {
      if (!sb) return [];
      const { data } = await sb
        .from('account_deletion_requests')
        .select('*')
        .order('created_at', { ascending: false });
      return data || [];
    }

    // 13. c$e (Admin mark deletion request done): POST { id }
    if (fnId === 'e1335f734e09d514820ace7b76cc8d5fb97c536258f246089e4b5586f4560382') {
      if (!sb) return { ok: true };
      const { error } = await sb
        .from('account_deletion_requests')
        .update({ status: 'selesai', updated_at: ts })
        .eq('id', input.id);
      if (error) throw new Error(error.message);
      return { ok: true };
    }

    return {
      enabled: false,
      verified: true,
      required: false,
      firstOrder: false,
      phone: '628215006669',
      success: true
    };
  };

  window.__createGoGoGoDatabaseClient = function (createRealSupabaseClient) {
    try {
      const cfgRaw = localStorage.getItem(CONFIG_KEY);
      if (cfgRaw) {
        const cfg = JSON.parse(cfgRaw);
        if (cfg && cfg.mode === 'local') {
          const localClient = createLocalSupabaseClient();
          window.__gogogoClientInstance = localClient;
          return localClient;
        }
        if (cfg && cfg.mode === 'supabase' && cfg.url && cfg.anonKey && typeof createRealSupabaseClient === 'function') {
          const realClient = createRealSupabaseClient(cfg.url, cfg.anonKey, {
            auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
          });
          window.__gogogoClientInstance = realClient;
          return realClient;
        }
      }
      if (LAUNCH_CONFIG.SUPABASE_URL && LAUNCH_CONFIG.SUPABASE_ANON_KEY && typeof createRealSupabaseClient === 'function') {
        const prodClient = createRealSupabaseClient(LAUNCH_CONFIG.SUPABASE_URL.trim(), LAUNCH_CONFIG.SUPABASE_ANON_KEY.trim(), {
          auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
        });
        window.__gogogoClientInstance = prodClient;
        return prodClient;
      }
    } catch (e) {}

    const localClient = createLocalSupabaseClient();
    window.__gogogoClientInstance = localClient;
    return localClient;
  };

  function mountSuperAppControlPanel() {
    if (document.getElementById('gogogo-control-panel')) return;

    const container = document.createElement('div');
    container.id = 'gogogo-control-panel';
    container.innerHTML = `
      <style>
        #gogogo-fab-btn {
          position: fixed;
          bottom: 78px;
          left: 14px;
          z-index: 99998;
          background: linear-gradient(135deg, #092D84 0%, #124BC2 60%, #277AE8 100%);
          color: #fff;
          border: 2px solid rgba(255,255,255,0.9);
          border-radius: 999px;
          padding: 8px 14px;
          font-family: 'Plus Jakarta Sans', sans-serif;
          font-size: 12px;
          font-weight: 700;
          box-shadow: 0 8px 24px rgba(18, 75, 194, 0.38);
          cursor: pointer;
          display: flex;
          align-items: center;
          gap: 6px;
          transition: transform 0.15s ease;
        }
        #gogogo-fab-btn:hover { transform: scale(1.04); }
        #gogogo-modal-backdrop {
          position: fixed;
          inset: 0;
          background: rgba(11, 23, 54, 0.55);
          backdrop-filter: blur(3px);
          z-index: 99999;
          display: none;
          align-items: center;
          justify-content: center;
          padding: 14px;
          font-family: 'Plus Jakarta Sans', sans-serif;
        }
        #gogogo-modal-backdrop.open { display: flex; }
        #gogogo-modal-card {
          background: #ffffff;
          color: #0b1736;
          width: 100%;
          max-width: 480px;
          max-height: 88vh;
          overflow-y: auto;
          border-radius: 20px;
          padding: 18px;
          box-shadow: 0 20px 50px rgba(0,0,0,0.3);
        }
        .sb-sec {
          background: #f4f7fe;
          border: 1px solid #dce5f5;
          border-radius: 14px;
          padding: 12px;
          margin-top: 12px;
        }
        .sb-sec h4 {
          margin: 0 0 8px 0;
          font-size: 13px;
          font-weight: 800;
          color: #124BC2;
        }
        .sb-input {
          width: 100%;
          box-sizing: border-box;
          padding: 8px 10px;
          border: 1px solid #cbd5e1;
          border-radius: 10px;
          font-size: 12px;
          margin-bottom: 8px;
        }
        .sb-btn {
          background: #124BC2;
          color: #fff;
          border: none;
          border-radius: 10px;
          padding: 8px 12px;
          font-size: 12px;
          font-weight: 700;
          cursor: pointer;
          width: 100%;
        }
        .sb-btn-outline {
          background: #fff;
          color: #124BC2;
          border: 1px solid #124BC2;
          border-radius: 9px;
          padding: 6px 10px;
          font-size: 11px;
          font-weight: 700;
          cursor: pointer;
          text-decoration: none;
          display: inline-block;
          text-align: center;
        }
        .sb-grid {
          display: grid;
          grid-template-columns: repeat(2, 1fr);
          gap: 6px;
        }
      </style>
      <button id="gogogo-fab-btn" title="Panel Kontrol GoGoGo, Login Email & Database Sendiri">
        <span>&#9881;</span>
        <span>Panel GoGoGo</span>
      </button>
      <div id="gogogo-modal-backdrop">
        <div id="gogogo-modal-card">
          <div style="display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #e5e7eb;padding-bottom:10px;">
            <div>
              <div style="font-size:15px;font-weight:800;color:#124BC2;">Panel Kontrol GoGoGo SuperApp</div>
              <div style="font-size:11px;color:#52638a;">Melaju Untuk Kebutuhanmu &bull; CS: 08215006669 &bull; Database Mandiri</div>
            </div>
            <button id="gogogo-close-btn" style="background:#f1f5f9;border:none;border-radius:8px;padding:6px 10px;font-weight:800;cursor:pointer;">&#10005;</button>
          </div>

          <div class="sb-sec">
            <h4>1. Login Instan dengan Email Anda Sendiri</h4>
            <div style="font-size:11px;color:#475569;margin-bottom:8px;">
              Masukkan email Anda di bawah ini untuk langsung aktif sebagai Pemilik Akun (Pelanggan + Merchant + Kurir + Super Admin):
            </div>
            <input id="sb-email-input" class="sb-input" type="email" placeholder="Masukkan email Anda (misal: nama@gmail.com)" />
            <input id="sb-name-input" class="sb-input" type="text" placeholder="Nama tampilan (opsional)" />
            <button id="sb-login-btn" class="sb-btn">Login &amp; Aktifkan Semua Fitur Sekarang</button>
          </div>

          <div class="sb-sec">
            <h4>2. Pintasan Semua 25 Halaman &amp; Fitur GoGoGo</h4>
            <div style="font-size:11px;color:#475569;margin-bottom:8px;">
              Klik salah satu modul di bawah untuk langsung membuka dan menjalankan prosesnya:
            </div>
            <div class="sb-grid">
              <a class="sb-btn-outline" href="/">Beranda Utama</a>
              <a class="sb-btn-outline" href="/food">Go Makan</a>
              <a class="sb-btn-outline" href="/mart">Go Mart</a>
              <a class="sb-btn-outline" href="/express">Go Express</a>
              <a class="sb-btn-outline" href="/riding">Go Riding</a>
              <a class="sb-btn-outline" href="/mobil">Go Mobil</a>
              <a class="sb-btn-outline" href="/cargo">Go Cargo</a>
              <a class="sb-btn-outline" href="/suruh">Go Suruh</a>
              <a class="sb-btn-outline" href="/pay">GoGoGo Pay (Dompet)</a>
              <a class="sb-btn-outline" href="/rewards">GoGoGo Rewards</a>
              <a class="sb-btn-outline" href="/asisten">Asisten AI</a>
              <a class="sb-btn-outline" href="/orders">Aktivitas &amp; Lacak</a>
              <a class="sb-btn-outline" href="/cart">Keranjang</a>
              <a class="sb-btn-outline" href="/checkout">Checkout &amp; Peta</a>
              <a class="sb-btn-outline" href="/restoran-saya">Dashboard Restoran Saya</a>
              <a class="sb-btn-outline" href="/kurir">Dashboard Kurir</a>
              <a class="sb-btn-outline" href="/kurir-penghasilan">Penghasilan Kurir</a>
              <a class="sb-btn-outline" href="/kurir-performa">Performa Kurir</a>
              <a class="sb-btn-outline" href="/mitra">Portal Daftar Mitra</a>
              <a class="sb-btn-outline" href="/admin" style="background:#F29D18;color:#fff;border-color:#F29D18;">SUPER ADMIN PANEL</a>
            </div>
          </div>

          <div class="sb-sec">
            <h4>3. Hak Akses Role Akun Anda Saat Ini</h4>
            <div style="display:flex;gap:12px;font-size:12px;margin-bottom:8px;">
              <label><input type="checkbox" id="sb-role-admin" checked /> Super Admin</label>
              <label><input type="checkbox" id="sb-role-owner" checked /> Restoran/Mart</label>
              <label><input type="checkbox" id="sb-role-courier" checked /> Kurir</label>
            </div>
            <button id="sb-save-roles-btn" class="sb-btn" style="background:#0b1736;">Simpan Hak Akses Role</button>
          </div>

          <div class="sb-sec">
            <h4>4. Konfigurasi Database Sendiri (Lokal vs Supabase Cloud)</h4>
            <select id="sb-db-mode" class="sb-input">
              <option value="local">Mode Mandiri (LocalDB Browser — Langsung Jalan Tanpa Setup)</option>
              <option value="supabase">Supabase Cloud Milik Sendiri (PostgreSQL Online)</option>
            </select>
            <div id="sb-supabase-fields" style="display:none;">
              <input id="sb-supa-url" class="sb-input" type="text" placeholder="https://xxxx.supabase.co" />
              <input id="sb-supa-key" class="sb-input" type="text" placeholder="Supabase Anon Public Key (eyJ...)" />
            </div>
            <div style="display:flex;gap:6px;">
              <button id="sb-save-db-btn" class="sb-btn">Simpan Pengaturan Database</button>
              <button id="sb-reset-db-btn" class="sb-btn" style="background:#dc2626;width:auto;white-space:nowrap;">Reset Data</button>
            </div>
          </div>
        </div>
      </div>
    `;
    document.body.appendChild(container);

    const fab = document.getElementById('gogogo-fab-btn');
    const modal = document.getElementById('gogogo-modal-backdrop');
    if (LAUNCH_CONFIG.PRODUCTION_PUBLIC_MODE && window.location.search.indexOf('panel=1') < 0) {
      fab.style.display = 'none';
    }
    window.addEventListener('keydown', (e) => {
      if (e.ctrlKey && e.shiftKey && (e.key === 'G' || e.key === 'g')) {
        fab.style.display = 'flex';
        syncFormState();
        modal.classList.add('open');
      }
    });
    const closeBtn = document.getElementById('gogogo-close-btn');
    const emailInput = document.getElementById('sb-email-input');
    const nameInput = document.getElementById('sb-name-input');
    const loginBtn = document.getElementById('sb-login-btn');
    const dbModeSelect = document.getElementById('sb-db-mode');
    const supaFields = document.getElementById('sb-supabase-fields');
    const supaUrl = document.getElementById('sb-supa-url');
    const supaKey = document.getElementById('sb-supa-key');

    function syncFormState() {
      const user = getDefaultUser();
      emailInput.value = user?.email || '';
      nameInput.value = user?.user_metadata?.full_name || '';

      const roles = getActiveRolesConfig();
      document.getElementById('sb-role-admin').checked = Boolean(roles.admin);
      document.getElementById('sb-role-owner').checked = Boolean(roles.owner);
      document.getElementById('sb-role-courier').checked = Boolean(roles.courier);

      try {
        const cfg = JSON.parse(localStorage.getItem(CONFIG_KEY) || '{}');
        dbModeSelect.value = cfg.mode === 'supabase' ? 'supabase' : 'local';
        supaUrl.value = cfg.url || '';
        supaKey.value = cfg.anonKey || '';
        supaFields.style.display = dbModeSelect.value === 'supabase' ? 'block' : 'none';
      } catch (e) {}
    }

    fab.addEventListener('click', () => {
      syncFormState();
      modal.classList.add('open');
    });
    closeBtn.addEventListener('click', () => modal.classList.remove('open'));
    modal.addEventListener('click', (e) => {
      if (e.target === modal) modal.classList.remove('open');
    });

    dbModeSelect.addEventListener('change', () => {
      supaFields.style.display = dbModeSelect.value === 'supabase' ? 'block' : 'none';
    });

    loginBtn.addEventListener('click', () => {
      const em = emailInput.value.trim() || 'owner@gogogo.app';
      const nm = nameInput.value.trim();
      if (window.__gogogoClientInstance && window.__gogogoClientInstance.__loginWithEmail) {
        window.__gogogoClientInstance.__loginWithEmail(em, nm);
      }
      modal.classList.remove('open');
      window.location.reload();
    });

    document.getElementById('sb-save-roles-btn').addEventListener('click', () => {
      const cfg = {
        admin: document.getElementById('sb-role-admin').checked,
        owner: document.getElementById('sb-role-owner').checked,
        courier: document.getElementById('sb-role-courier').checked
      };
      setActiveRolesConfig(cfg);
      const db = loadDB();
      ensureUserInDB(db, getDefaultUser());
      saveDB(db);
      modal.classList.remove('open');
      window.location.reload();
    });

    document.getElementById('sb-save-db-btn').addEventListener('click', () => {
      const cfg = {
        mode: dbModeSelect.value,
        url: supaUrl.value.trim(),
        anonKey: supaKey.value.trim()
      };
      localStorage.setItem(CONFIG_KEY, JSON.stringify(cfg));
      modal.classList.remove('open');
      window.location.reload();
    });

    document.getElementById('sb-reset-db-btn').addEventListener('click', () => {
      if (confirm('Reset seluruh data simulasi lokal ke kondisi awal?')) {
        localStorage.removeItem(STORAGE_KEY);
        window.location.reload();
      }
    });
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', mountSuperAppControlPanel);
  } else {
    mountSuperAppControlPanel();
  }
})();
