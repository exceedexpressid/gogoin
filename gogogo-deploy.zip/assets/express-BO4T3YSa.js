import{a as e}from"./chunk-Cyuzqnbw.js";import{n as t,t as n}from"./jsx-runtime-dIob5GyK.js";import{t as Link}from"./link-BjDnxAYt.js";import{ds as useNavigate,$o as toast}from"./index-CWsrv0HS.js";import{t as SuperAppShell}from"./SuperAppShell-CEcI2waY.js";import{t as LocationPicker}from"./LocationPicker-wtR_rEKX.js";import{t as OrderMiniMap}from"./OrderMiniMap-CiWQhAKt.js";import{n as supabase}from"./client-DVq7Iik5.js";
import{calcDistanceTariff,useServiceTariffs}from"./service-tariffs.js";

var React = e(t(), 1);
var jsx = n();

function formatRp(val) {
  return "Rp " + Number(val || 0).toLocaleString("id-ID");
}

function calcHaversineKm(a, b) {
  if (!a || !b) return null;
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const sinLat = Math.sin(dLat / 2);
  const sinLng = Math.sin(dLng / 2);
  const h =
    sinLat * sinLat +
    Math.cos((a.lat * Math.PI) / 180) *
      Math.cos((b.lat * Math.PI) / 180) *
      sinLng *
      sinLng;
  return R * (2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h)));
}

const SPEED_TIERS = [
  { key: "saver", label: "Ekonomis", eta: "Estimasi 2–4 jam", mult: 1.0, badge: "Paling Hemat" },
  { key: "standard", label: "Express Same Day", eta: "Estimasi 45–90 mnt", mult: 1.25, badge: "Populer" },
  { key: "priority", label: "Instant Kilat", eta: "Estimasi 15–35 mnt", mult: 1.6, badge: "Prioritas" }
];

const WEIGHT_TIERS = [
  { key: "light", label: "< 2 kg", desc: "Kecil", extra: 0 },
  { key: "medium", label: "2–5 kg", desc: "Sedang", extra: 4000 },
  { key: "heavy", label: "> 5 kg (maks 15 kg)", desc: "Besar", extra: 10000 }
];

const PACKAGE_TYPES = [
  "Dokumen / Surat Penting",
  "Makanan / Oleh-oleh",
  "Barang Belanja / Mart",
  "Elektronik / Pecah Belah"
];

const STATUS_LABEL = {
  searching_driver: "Mencari Kurir",
  accepted: "Kurir Ditemukan",
  driver_assigned: "Kurir Menuju Titik Jemput",
  driver_arrived: "Kurir di Titik Jemput",
  picked_up: "Paket Dijemput",
  on_delivery: "Dalam Pengantaran",
  delivering: "Dalam Pengantaran",
  completed: "Selesai Diterima",
  cancelled: "Dibatalkan"
};

function ExpressPage() {
  const navigate = useNavigate();
  const { tariffs } = useServiceTariffs();
  const expCfg = tariffs.tiers.express_base;
  const [tab, setTab] = React.useState("book");
  const [user, setUser] = React.useState(null);
  const [authLoaded, setAuthLoaded] = React.useState(false);
  const [walletBalance, setWalletBalance] = React.useState(0);

  const [pickupAddress, setPickupAddress] = React.useState("");
  const [pickupPoint, setPickupPoint] = React.useState(null);
  const [showPickupMap, setShowPickupMap] = React.useState(false);

  const [dropoffAddress, setDropoffAddress] = React.useState("");
  const [dropoffPoint, setDropoffPoint] = React.useState(null);
  const [showDropoffMap, setShowDropoffMap] = React.useState(false);

  const [senderName, setSenderName] = React.useState("");
  const [senderPhone, setSenderPhone] = React.useState("");
  const [recipientName, setRecipientName] = React.useState("");
  const [recipientPhone, setRecipientPhone] = React.useState("");
  const [packageType, setPackageType] = React.useState(PACKAGE_TYPES[0]);
  const [weightKey, setWeightKey] = React.useState("light");
  const [speedKey, setSpeedKey] = React.useState("standard");
  const [isFragile, setIsFragile] = React.useState(false);
  const [distanceKm, setDistanceKm] = React.useState(2);
  const [manualDistance, setManualDistance] = React.useState(false);
  const [notes, setNotes] = React.useState("");
  const [payMethod, setPayMethod] = React.useState("cash");
  const [submitting, setSubmitting] = React.useState(false);
  const [createdOrder, setCreatedOrder] = React.useState(null);
  const [redirectSec, setRedirectSec] = React.useState(null);
  const [myShipments, setMyShipments] = React.useState([]);
  const [shipmentLocs, setShipmentLocs] = React.useState({});

  const loadAccountAndShipments = React.useCallback(async () => {
    try {
      const { data: s } = await supabase.auth.getSession();
      const u = s?.session?.user || null;
      setUser(u);
      setAuthLoaded(true);
      if (!u) return;

      const [{ data: prof }, { data: list }] = await Promise.all([
        supabase.from("profiles").select("*").eq("id", u.id).maybeSingle(),
        supabase
          .from("orders")
          .select("*, order_items(*)")
          .eq("customer_id", u.id)
          .eq("fulfillment_type", "express")
          .order("created_at", { ascending: false })
          .limit(30)
      ]);

      if (prof) {
        setWalletBalance(Number(prof.wallet_balance || 0));
        setSenderName((prev) => prev || prof.full_name || "");
        setSenderPhone((prev) => prev || prof.phone || "");
        setPickupAddress((prev) => prev || prof.address || "");
        if (prof.latitude != null && prof.longitude != null) {
          setPickupPoint((prev) =>
            prev || { lat: Number(prof.latitude), lng: Number(prof.longitude) }
          );
        }
      }
      const shipments = list || [];
      setMyShipments(shipments);
      const activeIds = shipments.filter((o) => !["completed", "cancelled"].includes(o.status)).map((o) => o.id);
      if (activeIds.length > 0) {
        const { data: locs } = await supabase
          .from("courier_locations")
          .select("order_id, latitude, longitude")
          .in("order_id", activeIds);
        const mapLoc = {};
        for (const l of locs || []) {
          mapLoc[l.order_id] = { lat: Number(l.latitude), lng: Number(l.longitude) };
        }
        setShipmentLocs(mapLoc);
      }
    } catch (err) {
      console.error(err);
      setAuthLoaded(true);
    }
  }, []);

  React.useEffect(() => {
    loadAccountAndShipments();
  }, [loadAccountAndShipments]);

  React.useEffect(() => {
    if (tab !== "history" || !user) return;
    const tmr = setInterval(() => {
      loadAccountAndShipments();
    }, 5000);
    return () => clearInterval(tmr);
  }, [tab, user, loadAccountAndShipments]);

  React.useEffect(() => {
    if (!pickupPoint || !dropoffPoint) return;
    let active = true;
    const straightKm = calcHaversineKm(pickupPoint, dropoffPoint);
    if (straightKm != null) {
      const roadKm = Math.max(0.5, Number((straightKm * 1.25).toFixed(1)));
      setDistanceKm(roadKm);
      setManualDistance(false);
    }
    const coords = `${pickupPoint.lng},${pickupPoint.lat};${dropoffPoint.lng},${dropoffPoint.lat}?overview=false`;
    (async () => {
      for (const base of [
        "https://router.project-osrm.org/route/v1/driving",
        "https://routing.openstreetmap.de/routed-car/route/v1/driving"
      ]) {
        try {
          const res = await fetch(`${base}/${coords}`);
          if (!res.ok) continue;
          const json = await res.json();
          const dist = Number(json?.routes?.[0]?.distance);
          if (active && Number.isFinite(dist) && dist > 0) {
            setDistanceKm(Math.max(0.5, Number((dist / 1000).toFixed(1))));
            setManualDistance(false);
            break;
          }
        } catch {}
      }
    })();
    return () => {
      active = false;
    };
  }, [pickupPoint, dropoffPoint]);

  React.useEffect(() => {
    if (redirectSec == null) return;
    if (redirectSec <= 0) {
      navigate({ to: "/orders" });
      return;
    }
    const tmr = setTimeout(() => setRedirectSec((s) => (s == null ? null : s - 1)), 1000);
    return () => clearTimeout(tmr);
  }, [redirectSec, navigate]);

  const activeWeight = WEIGHT_TIERS.find((w) => w.key === weightKey) || WEIGHT_TIERS[0];
  const activeSpeed = SPEED_TIERS.find((s) => s.key === speedKey) || SPEED_TIERS[1];

  const baseDistanceFee = React.useMemo(() => {
    return calcDistanceTariff(expCfg, distanceKm);
  }, [expCfg, distanceKm]);

  const deliveryFee = React.useMemo(() => {
    const raw = baseDistanceFee * activeSpeed.mult + activeWeight.extra;
    return Math.round(raw / 500) * 500;
  }, [baseDistanceFee, activeSpeed, activeWeight]);

  const appFee = Number(tariffs.appFee ?? 2000);
  const grandTotal = deliveryFee + appFee;

  const handleCreateExpressOrder = async () => {
    if (!user) {
      toast.error("Silakan masuk ke akun GoGoGo untuk mengirim paket.");
      navigate({ to: "/auth" });
      return;
    }
    if (!pickupAddress.trim() || !dropoffAddress.trim() || !recipientName.trim() || !recipientPhone.trim()) {
      toast.error("Lengkapi alamat jemput, alamat tujuan, nama & no. WA penerima.");
      return;
    }
    if (payMethod === "wallet" && walletBalance < grandTotal) {
      toast.error("Saldo GoGoGo Pay tidak mencukupi. Top up dulu di menu Pay.");
      return;
    }

    setSubmitting(true);
    try {
      const orderNum = "EXP-" + Date.now().toString().slice(-6);
      const itemSummary = `${packageType} (${activeWeight.label})${isFragile ? " · Mudah Pecah" : ""} · ${distanceKm} km`;
      const combinedNotes = [
        senderName.trim() ? `Pengirim: ${senderName.trim()} (${senderPhone.trim() || "-"})` : "",
        `Layanan: ${activeSpeed.label}`,
        notes.trim() ? `Catatan: ${notes.trim()}` : ""
      ]
        .filter(Boolean)
        .join(" | ");

      const pLat = pickupPoint?.lat ?? -2.6068;
      const pLng = pickupPoint?.lng ?? 140.6692;
      const dLat = dropoffPoint?.lat ?? (pLat + 0.008);
      const dLng = dropoffPoint?.lng ?? (pLng + 0.008);

      const { data: ord, error: ordErr } = await supabase
        .from("orders")
        .insert({
          order_number: orderNum,
          customer_id: user.id,
          restaurant_id: null,
          customer_name: recipientName.trim(),
          customer_phone: recipientPhone.trim(),
          customer_address: dropoffAddress.trim(),
          pickup_address: pickupAddress.trim(),
          pickup_latitude: pLat,
          pickup_longitude: pLng,
          latitude: dLat,
          longitude: dLng,
          status: "searching_driver",
          fulfillment_type: "express",
          payment_method: payMethod,
          payment_status: payMethod === "wallet" ? "paid" : "unpaid",
          delivery_tier: speedKey,
          delivery_tier_label: activeSpeed.label,
          subtotal: 0,
          admin_fee: 0,
          app_fee: appFee,
          delivery_fee: deliveryFee,
          discount: 0,
          total: grandTotal,
          notes: combinedNotes || null
        })
        .select()
        .single();

      if (ordErr) throw ordErr;

      if (payMethod === "wallet") {
        const { data: wp, error: we } = await supabase.rpc("wallet_pay_order", {
          _order_id: ord.id,
          _amount: grandTotal,
          _description: `Go Express #${orderNum}`
        });
        if (we || wp?.success === false) {
          await supabase.from("orders").delete().eq("id", ord.id);
          throw new Error(wp?.message || we?.message || "Pembayaran GoGoGo Pay gagal.");
        }
        setWalletBalance(Number(wp?.wallet_balance ?? walletBalance - grandTotal));
      }

      const { error: itemErr } = await supabase.from("order_items").insert({
        order_id: ord.id,
        menu_item_id: null,
        menu_name: `[Express] ${itemSummary}`,
        quantity: 1,
        price: deliveryFee,
        subtotal: deliveryFee,
        restaurant_price: deliveryFee,
        markup_amount: 0,
        notes: isFragile ? "Hati-hati barang pecah belah" : null
      });
      if (itemErr) throw itemErr;

      toast.success("Kurir Go Express segera menuju titik jemput!");
      setCreatedOrder({
        id: ord.id,
        order_number: orderNum,
        total: grandTotal,
        pickup: pickupAddress.trim(),
        dropoff: dropoffAddress.trim(),
        pickupPoint: { lat: pLat, lng: pLng },
        dropoffPoint: { lat: dLat, lng: dLng },
        payment_method: payMethod,
        speed: activeSpeed.label
      });
      setRedirectSec(3);
      if (typeof window !== "undefined") {
        window.scrollTo({ top: 0, behavior: "smooth" });
      }
      await loadAccountAndShipments();
    } catch (err) {
      toast.error(err?.message || "Gagal membuat kiriman Express.");
    } finally {
      setSubmitting(false);
    }
  };

  if (createdOrder) {
    return (0, jsx.jsx)(SuperAppShell, {
      title: "Kiriman Express Dibuat",
      subtitle: `#${createdOrder.order_number} · Mencari kurir terdekat`,
      accent: "bg-accent",
      children: (0, jsx.jsxs)("div", {
        className: "space-y-4 px-4 py-6 pb-20",
        children: [
          (0, jsx.jsxs)("div", {
            className: "rounded-3xl border border-emerald-500/30 bg-card p-6 text-center shadow-card",
            children: [
              (0, jsx.jsx)("div", {
                className: "mx-auto grid size-16 place-items-center rounded-full bg-emerald-500/15 text-3xl",
                children: "📦"
              }),
              (0, jsx.jsxs)("h2", {
                className: "mt-3 font-display text-xl font-extrabold text-foreground",
                children: ["Kiriman #", createdOrder.order_number, " Berhasil!"]
              }),
              (0, jsx.jsxs)("p", {
                className: "mt-1 text-xs text-muted-foreground",
                children: [
                  "Layanan ",
                  createdOrder.speed,
                  " · Total ",
                  formatRp(createdOrder.total),
                  " (",
                  createdOrder.payment_method === "wallet" ? "Lunas GoGoGo Pay" : "Tunai COD",
                  ")"
                ]
              }),
              (0, jsx.jsxs)("div", {
                className: "mt-4 rounded-2xl bg-secondary/70 p-3 text-left text-xs space-y-1",
                children: [
                  (0, jsx.jsxs)("p", { children: ["📍 ", (0, jsx.jsx)("span", { className: "font-semibold", children: createdOrder.pickup })] }),
                  (0, jsx.jsxs)("p", { children: ["🏁 ", (0, jsx.jsx)("span", { className: "font-semibold", children: createdOrder.dropoff })] })
                ]
              }),
              createdOrder.pickupPoint && createdOrder.dropoffPoint && (0, jsx.jsx)(OrderMiniMap, {
                className: "mt-4 h-44",
                restaurant: createdOrder.pickupPoint,
                customer: createdOrder.dropoffPoint,
                fallbackLabel: "Lihat Rute di Google Maps",
                fallbackLink: `https://www.google.com/maps/dir/?api=1&origin=${createdOrder.pickupPoint.lat},${createdOrder.pickupPoint.lng}&destination=${createdOrder.dropoffPoint.lat},${createdOrder.dropoffPoint.lng}`
              }),
              redirectSec != null && (0, jsx.jsxs)("p", {
                className: "mt-3 text-xs font-semibold text-primary",
                children: ["Membuka pelacakan perjalanan driver dalam ", redirectSec, " detik…"]
              }),
              (0, jsx.jsxs)("div", {
                className: "mt-4 space-y-2",
                children: [
                  (0, jsx.jsx)("button", {
                    type: "button",
                    onClick: () => {
                      setRedirectSec(null);
                      navigate({ to: "/orders" });
                    },
                    className: "w-full rounded-xl bg-primary py-3 text-xs font-extrabold text-primary-foreground shadow-md",
                    children: "🗺️ Lacak Perjalanan Driver Sekarang"
                  }),
                  (0, jsx.jsxs)("div", {
                    className: "grid grid-cols-2 gap-2",
                    children: [
                      (0, jsx.jsx)("button", {
                        type: "button",
                        onClick: () => {
                          setRedirectSec(null);
                          navigate({ to: "/" });
                        },
                        className: "rounded-xl border border-border bg-background py-2.5 text-xs font-bold",
                        children: "🏠 Kembali ke Menu"
                      }),
                      (0, jsx.jsx)("button", {
                        type: "button",
                        onClick: () => {
                          setRedirectSec(null);
                          setCreatedOrder(null);
                          setDropoffAddress("");
                          setRecipientName("");
                          setRecipientPhone("");
                          setNotes("");
                        },
                        className: "rounded-xl border border-border bg-background py-2.5 text-xs font-bold",
                        children: "📦 Kirim Paket Lagi"
                      })
                    ]
                  })
                ]
              })
            ]
          })
        ]
      })
    });
  }

  return (0, jsx.jsx)(SuperAppShell, {
    title: "Go Express",
    subtitle: "Kirim paket instan, aman, & lacak real-time",
    accent: "bg-accent",
    children: (0, jsx.jsxs)("div", {
      className: "space-y-4 px-4 py-4 pb-24",
      children: [
        (0, jsx.jsxs)("div", {
          className: "rounded-2xl gradient-brand p-4 text-white shadow-soft",
          children: [
            (0, jsx.jsx)("p", { className: "text-xs font-bold uppercase tracking-wider opacity-90", children: "Layanan Kurir Lokal" }),
            (0, jsx.jsx)("h2", { className: "mt-1 font-display text-lg font-extrabold", children: "Antar Barang & Dokumen Cepat 📦" }),
            (0, jsx.jsx)("p", { className: "mt-0.5 text-xs text-white/90", children: "Tentukan titik jemput & tujuan di peta, pilih kecepatan kurir, lalu bayar via GoGoGo Pay atau Tunai." })
          ]
        }),

        (0, jsx.jsxs)("div", {
          className: "grid grid-cols-2 gap-1 rounded-2xl bg-secondary p-1",
          children: [
            { id: "book", label: "📦 Kirim Paket" },
            { id: "history", label: `🗺️ Lacak (${myShipments.length})` }
          ].map((t) =>
            (0, jsx.jsx)(
              "button",
              {
                type: "button",
                onClick: () => setTab(t.id),
                className: `rounded-xl py-2 text-xs font-bold transition-colors ${
                  tab === t.id ? "bg-card text-primary shadow-sm" : "text-muted-foreground"
                }`,
                children: t.label
              },
              t.id
            )
          )
        }),

        authLoaded && !user && (0, jsx.jsxs)("div", {
          className: "flex items-center justify-between gap-3 rounded-2xl border border-primary/30 bg-primary/5 p-3.5",
          children: [
            (0, jsx.jsxs)("div", {
              className: "min-w-0",
              children: [
                (0, jsx.jsx)("p", { className: "text-xs font-bold text-primary", children: "Masuk untuk mulai mengirim paket" }),
                (0, jsx.jsx)("p", { className: "text-[11px] text-muted-foreground", children: "Alamat tersimpan & saldo GoGoGo Pay langsung sinkron." })
              ]
            }),
            (0, jsx.jsx)(Link, {
              to: "/auth",
              className: "shrink-0 rounded-xl bg-primary px-3 py-2 text-xs font-bold text-primary-foreground",
              children: "Masuk"
            })
          ]
        }),

        tab === "history"
          ? (0, jsx.jsx)("div", {
              className: "space-y-3",
              children: myShipments.length === 0
                ? (0, jsx.jsxs)("div", {
                    className: "rounded-2xl bg-card p-6 text-center shadow-soft",
                    children: [
                      (0, jsx.jsx)("p", { className: "text-sm font-bold", children: "Belum ada riwayat Go Express" }),
                      (0, jsx.jsx)("p", { className: "mt-1 text-xs text-muted-foreground", children: "Paket yang kamu kirim akan tampil lengkap beserta peta rute & status kurir di sini." }),
                      (0, jsx.jsx)("button", {
                        type: "button",
                        onClick: () => setTab("book"),
                        className: "mt-3 rounded-xl bg-primary px-4 py-2 text-xs font-bold text-primary-foreground",
                        children: "Buat Pengiriman Pertama"
                      })
                    ]
                  })
                : myShipments.map((sh) => {
                    const hasPts = sh.pickup_latitude != null && sh.pickup_longitude != null && sh.latitude != null && sh.longitude != null;
                    return (0, jsx.jsxs)(
                      "div",
                      {
                        className: "rounded-2xl bg-card p-4 shadow-soft space-y-2.5",
                        children: [
                          (0, jsx.jsxs)("div", {
                            className: "flex items-center justify-between gap-2",
                            children: [
                              (0, jsx.jsxs)("span", { className: "font-mono text-xs font-bold text-foreground", children: ["#", sh.order_number] }),
                              (0, jsx.jsx)("span", {
                                className: "rounded-full bg-primary/10 px-2.5 py-0.5 text-[11px] font-bold text-primary",
                                children: STATUS_LABEL[sh.status] || sh.status
                              })
                            ]
                          }),
                          (0, jsx.jsxs)("div", {
                            className: "space-y-1 text-xs text-muted-foreground",
                            children: [
                              (0, jsx.jsxs)("p", { children: ["📍 ", (0, jsx.jsx)("span", { className: "font-semibold text-foreground", children: sh.pickup_address || "Titik Jemput" })] }),
                              (0, jsx.jsxs)("p", { children: ["🏁 ", (0, jsx.jsx)("span", { className: "font-semibold text-foreground", children: sh.customer_address }), " (", sh.customer_name, ")"] })
                            ]
                          }),
                          hasPts && (0, jsx.jsx)(OrderMiniMap, {
                            className: "h-36",
                            restaurant: { lat: Number(sh.pickup_latitude), lng: Number(sh.pickup_longitude) },
                            customer: { lat: Number(sh.latitude), lng: Number(sh.longitude) },
                            driver: shipmentLocs[sh.id] || null
                          }),
                          (0, jsx.jsxs)("div", {
                            className: "flex items-center justify-between border-t border-border pt-2 text-xs",
                            children: [
                              (0, jsx.jsxs)("span", {
                                className: "font-extrabold text-primary",
                                children: [formatRp(sh.total), " · ", sh.payment_method === "wallet" ? "💳 GoGoGo Pay" : "💵 COD"]
                              }),
                              (0, jsx.jsx)(Link, {
                                to: "/orders",
                                className: "font-bold text-primary underline",
                                children: "Buka Peta Perjalanan Live →"
                              })
                            ]
                          })
                        ]
                      },
                      sh.id
                    );
                  })
            })
          : (0, jsx.jsxs)("div", {
              className: "space-y-4",
              children: [
                (0, jsx.jsxs)("section", {
                  className: "space-y-3 rounded-2xl bg-card p-4 shadow-soft",
                  children: [
                    (0, jsx.jsxs)("div", {
                      className: "flex items-center justify-between",
                      children: [
                        (0, jsx.jsx)("h3", { className: "text-sm font-bold", children: "1. Titik Jemput & Pengirim" }),
                        (0, jsx.jsx)("button", {
                          type: "button",
                          onClick: () => setShowPickupMap((v) => !v),
                          className: "rounded-lg bg-primary/10 px-2.5 py-1 text-[11px] font-bold text-primary",
                          children: showPickupMap ? "Tutup Peta" : pickupPoint ? "✓ Titik Dipilih" : "📍 Pilih di Peta"
                        })
                      ]
                    }),
                    (0, jsx.jsx)("input", {
                      type: "text",
                      value: pickupAddress,
                      onChange: (ev) => setPickupAddress(ev.target.value),
                      placeholder: "Alamat lengkap penjemputan paket...",
                      className: "w-full rounded-xl border border-border bg-background px-3 py-2.5 text-sm"
                    }),
                    showPickupMap && (0, jsx.jsx)("div", {
                      className: "rounded-xl border border-border p-2.5",
                      children: (0, jsx.jsx)(LocationPicker, {
                        value: pickupPoint,
                        onChange: (pt) => {
                          setPickupPoint(pt);
                          if (!pickupAddress.trim()) {
                            setPickupAddress(`Titik Peta (${pt.lat.toFixed(5)}, ${pt.lng.toFixed(5)})`);
                          }
                        }
                      })
                    }),
                    (0, jsx.jsxs)("div", {
                      className: "grid grid-cols-2 gap-2",
                      children: [
                        (0, jsx.jsx)("input", {
                          type: "text",
                          value: senderName,
                          onChange: (ev) => setSenderName(ev.target.value),
                          placeholder: "Nama pengirim",
                          className: "rounded-xl border border-border bg-background px-3 py-2 text-xs"
                        }),
                        (0, jsx.jsx)("input", {
                          type: "tel",
                          value: senderPhone,
                          onChange: (ev) => setSenderPhone(ev.target.value),
                          placeholder: "No. WA pengirim",
                          className: "rounded-xl border border-border bg-background px-3 py-2 text-xs"
                        })
                      ]
                    })
                  ]
                }),

                (0, jsx.jsxs)("section", {
                  className: "space-y-3 rounded-2xl bg-card p-4 shadow-soft",
                  children: [
                    (0, jsx.jsxs)("div", {
                      className: "flex items-center justify-between",
                      children: [
                        (0, jsx.jsx)("h3", { className: "text-sm font-bold", children: "2. Tujuan & Data Penerima" }),
                        (0, jsx.jsx)("button", {
                          type: "button",
                          onClick: () => setShowDropoffMap((v) => !v),
                          className: "rounded-lg bg-primary/10 px-2.5 py-1 text-[11px] font-bold text-primary",
                          children: showDropoffMap ? "Tutup Peta" : dropoffPoint ? "✓ Titik Dipilih" : "🏁 Pilih di Peta"
                        })
                      ]
                    }),
                    (0, jsx.jsx)("input", {
                      type: "text",
                      value: dropoffAddress,
                      onChange: (ev) => setDropoffAddress(ev.target.value),
                      placeholder: "Alamat lengkap tujuan penerima...",
                      className: "w-full rounded-xl border border-border bg-background px-3 py-2.5 text-sm"
                    }),
                    showDropoffMap && (0, jsx.jsx)("div", {
                      className: "rounded-xl border border-border p-2.5",
                      children: (0, jsx.jsx)(LocationPicker, {
                        value: dropoffPoint,
                        onChange: (pt) => {
                          setDropoffPoint(pt);
                          if (!dropoffAddress.trim()) {
                            setDropoffAddress(`Titik Tujuan (${pt.lat.toFixed(5)}, ${pt.lng.toFixed(5)})`);
                          }
                        }
                      })
                    }),
                    (0, jsx.jsxs)("div", {
                      className: "grid grid-cols-2 gap-2",
                      children: [
                        (0, jsx.jsx)("input", {
                          type: "text",
                          value: recipientName,
                          onChange: (ev) => setRecipientName(ev.target.value),
                          placeholder: "Nama penerima *",
                          className: "rounded-xl border border-border bg-background px-3 py-2.5 text-sm"
                        }),
                        (0, jsx.jsx)("input", {
                          type: "tel",
                          value: recipientPhone,
                          onChange: (ev) => setRecipientPhone(ev.target.value),
                          placeholder: "No. WA (628...) *",
                          className: "rounded-xl border border-border bg-background px-3 py-2.5 text-sm"
                        })
                      ]
                    })
                  ]
                }),

                (0, jsx.jsxs)("section", {
                  className: "space-y-3 rounded-2xl bg-card p-4 shadow-soft",
                  children: [
                    (0, jsx.jsx)("h3", { className: "text-sm font-bold", children: "3. Detail Paket & Layanan" }),
                    (0, jsx.jsx)("div", {
                      className: "flex flex-wrap gap-1.5",
                      children: PACKAGE_TYPES.map((type) =>
                        (0, jsx.jsx)(
                          "button",
                          {
                            type: "button",
                            onClick: () => setPackageType(type),
                            className: `rounded-full px-3 py-1.5 text-xs font-semibold transition-colors ${
                              packageType === type ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground"
                            }`,
                            children: type
                          },
                          type
                        )
                      )
                    }),
                    (0, jsx.jsxs)("div", {
                      children: [
                        (0, jsx.jsx)("label", { className: "block text-xs font-semibold text-muted-foreground mb-1.5", children: "Perkiraan Berat Paket" }),
                        (0, jsx.jsx)("div", {
                          className: "grid grid-cols-3 gap-2",
                          children: WEIGHT_TIERS.map((w) =>
                            (0, jsx.jsxs)(
                              "button",
                              {
                                type: "button",
                                onClick: () => setWeightKey(w.key),
                                className: `rounded-xl border p-2 text-left transition-colors ${
                                  weightKey === w.key ? "border-primary bg-primary/10 text-primary" : "border-border bg-background"
                                }`,
                                children: [
                                  (0, jsx.jsx)("p", { className: "text-xs font-bold", children: w.label }),
                                  (0, jsx.jsx)("p", { className: "text-[10px] text-muted-foreground", children: w.extra === 0 ? "Tarif dasar" : `+${formatRp(w.extra)}` })
                                ]
                              },
                              w.key
                            )
                          )
                        })
                      ]
                    }),
                    (0, jsx.jsxs)("div", {
                      children: [
                        (0, jsx.jsx)("label", { className: "block text-xs font-semibold text-muted-foreground mb-1.5", children: "Pilih Kecepatan Layanan" }),
                        (0, jsx.jsx)("div", {
                          className: "space-y-1.5",
                          children: SPEED_TIERS.map((s) =>
                            (0, jsx.jsxs)(
                              "button",
                              {
                                type: "button",
                                onClick: () => setSpeedKey(s.key),
                                className: `flex w-full items-center justify-between rounded-xl border px-3 py-2.5 text-left transition-colors ${
                                  speedKey === s.key ? "border-primary bg-primary/10" : "border-border bg-background"
                                }`,
                                children: [
                                  (0, jsx.jsxs)("div", {
                                    children: [
                                      (0, jsx.jsxs)("p", {
                                        className: "text-xs font-bold",
                                        children: [s.label, " ", (0, jsx.jsx)("span", { className: "ml-1 rounded-full bg-secondary px-1.5 py-0.5 text-[10px]", children: s.badge })]
                                      }),
                                      (0, jsx.jsx)("p", { className: "text-[11px] text-muted-foreground", children: s.eta })
                                    ]
                                  }),
                                  (0, jsx.jsx)("span", {
                                    className: "text-xs font-extrabold text-primary",
                                    children: formatRp(Math.round((baseDistanceFee * s.mult + activeWeight.extra) / 500) * 500)
                                  })
                                ]
                              },
                              s.key
                            )
                          )
                        })
                      ]
                    }),
                    (0, jsx.jsxs)("div", {
                      className: "flex items-center justify-between gap-3 rounded-xl bg-secondary/50 px-3 py-2.5",
                      children: [
                        (0, jsx.jsxs)("div", {
                          children: [
                            (0, jsx.jsx)("p", { className: "text-xs font-bold", children: "Estimasi Jarak Tempuh" }),
                            (0, jsx.jsx)("p", { className: "text-[11px] text-muted-foreground", children: pickupPoint && dropoffPoint && !manualDistance ? "Dihitung otomatis dari pin peta" : "Geser atau pilih titik jemput & tujuan di peta" })
                          ]
                        }),
                        (0, jsx.jsxs)("div", {
                          className: "flex items-center gap-1.5",
                          children: [
                            (0, jsx.jsx)("input", {
                              type: "number",
                              min: "0.5",
                              max: "50",
                              step: "0.5",
                              value: distanceKm,
                              onChange: (ev) => {
                                setManualDistance(true);
                                setDistanceKm(Number(ev.target.value || 1));
                              },
                              className: "w-16 rounded-lg border border-border bg-background px-2 py-1 text-center text-xs font-bold"
                            }),
                            (0, jsx.jsx)("span", { className: "text-xs font-bold", children: "km" })
                          ]
                        })
                      ]
                    }),
                    (0, jsx.jsxs)("label", {
                      className: "flex items-center gap-2 text-xs font-semibold",
                      children: [
                        (0, jsx.jsx)("input", {
                          type: "checkbox",
                          checked: isFragile,
                          onChange: (ev) => setIsFragile(ev.target.checked),
                          className: "size-4 accent-primary"
                        }),
                        "Tandai sebagai barang mudah pecah / perlu perhatian khusus"
                      ]
                    }),
                    (0, jsx.jsx)("input", {
                      type: "text",
                      value: notes,
                      onChange: (ev) => setNotes(ev.target.value),
                      placeholder: "Catatan patokan/pesan ke kurir (opsional)...",
                      className: "w-full rounded-xl border border-border bg-background px-3 py-2 text-xs"
                    })
                  ]
                }),

                (0, jsx.jsxs)("section", {
                  className: "space-y-2 rounded-2xl bg-card p-4 shadow-soft",
                  children: [
                    (0, jsx.jsx)("h3", { className: "text-sm font-bold", children: "4. Metode Pembayaran" }),
                    (0, jsx.jsxs)("div", {
                      className: "grid grid-cols-2 gap-2",
                      children: [
                        (0, jsx.jsxs)("button", {
                          type: "button",
                          onClick: () => setPayMethod("cash"),
                          className: `rounded-xl border p-2.5 text-left ${
                            payMethod === "cash" ? "border-primary bg-primary/10" : "border-border bg-background"
                          }`,
                          children: [
                            (0, jsx.jsx)("p", { className: "text-xs font-bold", children: "💵 Tunai (COD)" }),
                            (0, jsx.jsx)("p", { className: "text-[11px] text-muted-foreground", children: "Bayar ke kurir" })
                          ]
                        }),
                        (0, jsx.jsxs)("button", {
                          type: "button",
                          onClick: () => setPayMethod("wallet"),
                          className: `rounded-xl border p-2.5 text-left ${
                            payMethod === "wallet" ? "border-primary bg-primary/10" : "border-border bg-background"
                          }`,
                          children: [
                            (0, jsx.jsx)("p", { className: "text-xs font-bold", children: "💳 GoGoGo Pay" }),
                            (0, jsx.jsxs)("p", {
                              className: `text-[11px] ${walletBalance < grandTotal ? "text-destructive font-semibold" : "text-muted-foreground"}`,
                              children: ["Saldo: ", formatRp(walletBalance)]
                            })
                          ]
                        })
                      ]
                    }),
                    payMethod === "wallet" && walletBalance < grandTotal && (0, jsx.jsx)(Link, {
                      to: "/pay",
                      className: "inline-block text-xs font-bold text-primary underline",
                      children: "+ Isi Saldo GoGoGo Pay dulu →"
                    })
                  ]
                }),

                (0, jsx.jsxs)("div", {
                  className: "rounded-2xl bg-primary/5 border border-primary/20 p-4 space-y-2",
                  children: [
                    (0, jsx.jsxs)("div", {
                      className: "flex justify-between text-xs",
                      children: [
                        (0, jsx.jsxs)("span", { children: ["Ongkir ", activeSpeed.label, " (", distanceKm, " km, ", activeWeight.label, ")"] }),
                        (0, jsx.jsx)("span", { className: "font-bold", children: formatRp(deliveryFee) })
                      ]
                    }),
                    (0, jsx.jsxs)("div", {
                      className: "flex justify-between text-xs",
                      children: [
                        (0, jsx.jsx)("span", { children: "Biaya Layanan" }),
                        (0, jsx.jsx)("span", { className: "font-bold", children: formatRp(appFee) })
                      ]
                    }),
                    (0, jsx.jsxs)("div", {
                      className: "flex justify-between border-t border-primary/20 pt-2 text-sm font-extrabold text-primary",
                      children: [
                        (0, jsx.jsx)("span", { children: "Total Bayar" }),
                        (0, jsx.jsx)("span", { children: formatRp(grandTotal) })
                      ]
                    }),
                    (0, jsx.jsx)("button", {
                      type: "button",
                      disabled: submitting || !user || (payMethod === "wallet" && walletBalance < grandTotal),
                      onClick: handleCreateExpressOrder,
                      className: "mt-3 w-full rounded-xl bg-primary py-3 text-xs font-extrabold text-primary-foreground shadow-md disabled:opacity-50",
                      children: submitting ? "Memproses Pengiriman..." : `Pesan Kurir Express · ${formatRp(grandTotal)}`
                    })
                  ]
                })
              ]
            })
      ]
    })
  });
}

export { ExpressPage as component };
