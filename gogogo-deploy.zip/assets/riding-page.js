export { goRidingComponent as component } from "./go-transport-pages.js";
