import{a as e}from"./chunk-Cyuzqnbw.js";
import{n as t,t as n}from"./jsx-runtime-dIob5GyK.js";
import{t as r}from"./link-BjDnxAYt.js";
import{t as i}from"./AppShell-27FoYrsa.js";
import{n as a}from"./client-DVq7Iik5.js";
import{i as o,n as s}from"./queryOptions-kMMPsoVQ.js";
import{t as c}from"./proxy-B_fmw6RR.js";
import{n as gpIconFn,t as l}from"./utils-DAyKpcyH.js";
import{t as u}from"./arrow-left-BWg3Vj7m.js";
import{t as gpArrowR}from"./arrow-right-CJYOz4EP.js";
import{t as d,t as pmCheckIcon}from"./check-Dx-hryfF.js";
import{t as gpInfoIco}from"./info-CI3SDlDE.js";
import{a as gpDrDesc,c as ee,i as gpDrContent,n as gpDr,o as gpDrHead,s as gpDrTitle,t as f}from"./ShareSheet-DXb8HUYl.js";
import{s as p,t as m}from"./button-CnX5Xdlm.js";
import{t as h}from"./RequireAuth-BnY7Briz.js";
import{t as g}from"./shopping-bag-DEOYmxrQ.js";
import{s as te}from"./es2015-CKMQ0r7T.js";
import{n as ne,t as _}from"./phone-validation-Bo2P7p8X.js";
import{$i as re,$o as v,Bi as ie,Bo as ae,C as oe,Ca as se,Ea as ce,Eo as y,Fi as le,Ga as b,Hi as ue,Ii as de,La as x,Li as fe,Lo as pe,Oo as me,Ri as he,Sa as ge,T as _e,Ta as ve,Ui as ye,Vi as be,Wo as S,Yo as xe,Za as C,Zo as Se,aa as Ce,as as w,co as T,ds as we,ea as Te,es as Ee,fi as De,fn as Oe,go as ke,ia as Ae,io as je,is as E,jo as Me,ko as D,n as Ne,no as Pe,oa as O,oo as Fe,pi as k,qo as Ie,ro as A,sa as Le,ta as Re,to as ze,w as Be,x as Ve,xa as He,F as gpToday,M as gpShopSt,gn as gpSafeImg,gpJoin,gpLmFind,gpLmList,gpLmSave,gpLmVal,pn as gpUseRest}from"./index-CWsrv0HS.js";
import{n as Ue,r as We,t as Ge}from"./use-route-distance-BYUFxvy7.js";
import{t as Ke}from"./VoucherPicker-CY-noktE.js";
import{t as gpMiniMap}from"./OrderMiniMap-CiWQhAKt.js";

var gpIcoBrief=gpIconFn(`briefcase`,[[`path`,{d:`M16 20V4a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16`,key:`jecpp`}],[`rect`,{width:`20`,height:`14`,x:`2`,y:`6`,rx:`2`,key:`i6l2r4`}]]),
gpIcoHome=gpIconFn(`house`,[[`path`,{d:`M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8`,key:`5wwlr5`}],[`path`,{d:`M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z`,key:`1d0kgt`}]]),
gpIcoPhone=gpIconFn(`phone`,[[`path`,{d:`M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z`,key:`foiqr`}]]),
gpIcoClock=gpIconFn(`clock`,[[`circle`,{cx:`12`,cy:`12`,r:`10`,key:`1mglay`}],[`path`,{d:`M12 6v6l4 2`,key:`mmk7yg`}]]),
gpIcoMsgSq=gpIconFn(`message-square`,[[`path`,{d:`M22 17a2 2 0 0 1-2 2H6.828a2 2 0 0 0-1.414.586l-2.202 2.202A.71.71 0 0 1 2 21.286V5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2z`,key:`18887p`}]]),
gpIcoPencil=gpIconFn(`pencil`,[[`path`,{d:`M21.174 6.812a1 1 0 0 0-3.986-3.987L3.842 16.174a2 2 0 0 0-.5.83l-1.321 4.352a.5.5 0 0 0 .623.622l4.353-1.32a2 2 0 0 0 .83-.497z`,key:`1a8usu`}],[`path`,{d:`m15 5 4 4`,key:`1mk7zo`}]]),
gpIcoChevR=gpIconFn(`chevron-right`,[[`path`,{d:`m9 18 6-6-6-6`,key:`mthhwq`}]]),
gpIcoFlame=gpIconFn(`flame`,[[`path`,{d:`M12 3q1 4 4 6.5t3 5.5a1 1 0 0 1-14 0 5 5 0 0 1 1-3 1 1 0 0 0 5 0c0-2-1.5-3-1.5-5q0-2 2.5-4`,key:`1slcih`}]]),
gpIcoCourier=ae,
gpTierKeys=be,
j=e(t(),1),M=n(),N=[`Mengamankan pesananmu…`,`Menghitung total pembayaran…`,`Meneruskan ke restoran…`];

function qe({show:e,isPickup:t}){
  let[n,r]=(0,j.useState)(0);
  (0,j.useEffect)(()=>{
    if(!e){r(0);return}
    let t=setInterval(()=>r(e=>Math.min(e+1,N.length-1)),1100);
    return()=>clearInterval(t)
  },[e]);
  let i=t?g:ae;
  return(0,M.jsx)(S,{children:e&&(0,M.jsx)(c.div,{initial:{opacity:0},animate:{opacity:1},exit:{opacity:0},className:`fixed inset-0 z-[100] grid place-items-center bg-background/80 backdrop-blur-md`,role:`status`,"aria-live":`polite`,children:(0,M.jsxs)(`div`,{className:`flex flex-col items-center px-6 text-center`,children:[(0,M.jsxs)(`div`,{className:`relative grid size-28 place-items-center`,children:[[0,1,2].map(e=>(0,M.jsx)(c.span,{className:`absolute inset-0 rounded-full border-2 border-primary`,initial:{scale:.5,opacity:.7},animate:{scale:1.6,opacity:0},transition:{duration:2,repeat:1/0,delay:e*.66,ease:`easeOut`}},e)),(0,M.jsx)(c.div,{className:`grid size-20 place-items-center rounded-full bg-primary text-primary-foreground shadow-lg`,animate:{y:[0,-6,0],rotate:[0,-4,4,0]},transition:{duration:1.2,repeat:1/0},children:(0,M.jsx)(i,{className:`size-10`})})]}),(0,M.jsx)(S,{mode:`wait`,children:(0,M.jsx)(c.p,{initial:{opacity:0,y:8},animate:{opacity:1,y:0},exit:{opacity:0,y:-8},className:`mt-8 font-display text-lg font-bold`,children:N[n]},n)}),(0,M.jsx)(`p`,{className:`mt-1 text-sm text-muted-foreground`,children:`Mohon tunggu sebentar, jangan tutup halaman ini.`}),(0,M.jsx)(`div`,{className:`mt-5 flex gap-1.5`,children:[0,1,2].map(e=>(0,M.jsx)(c.span,{className:`size-2 rounded-full bg-primary`,animate:{opacity:[.3,1,.3],scale:[.8,1.2,.8]},transition:{duration:.9,repeat:1/0,delay:e*.15}},e))})]})})})
}

var P=[`var(--primary)`,`var(--accent)`,`oklch(0.75 0.17 60)`,`oklch(0.8 0.15 90)`,`oklch(0.65 0.2 150)`];
function Je(){
  return(0,M.jsx)(`div`,{className:`pointer-events-none absolute left-1/2 top-1/2`,"aria-hidden":!0,children:(0,j.useMemo)(()=>Array.from({length:40},(e,t)=>({id:t,x:(Math.random()-.5)*340,y:-(120+Math.random()*180),r:Math.random()*720-360,color:P[t%P.length],size:6+Math.random()*6,delay:Math.random()*.15,round:Math.random()>.5})),[]).map(e=>(0,M.jsx)(c.span,{className:`absolute block`,style:{width:e.size,height:e.round?e.size:e.size*.5,background:e.color,borderRadius:e.round?`9999px`:`2px`},initial:{x:0,y:0,opacity:1,rotate:0},animate:{x:e.x,y:[0,e.y,e.y+260],opacity:[1,1,0],rotate:e.r},transition:{duration:1.8,delay:e.delay,ease:`easeOut`,times:[0,.4,1]}},e.id))})
}

function Ye({info:e,isPickup:t}){
  return(0,j.useEffect)(()=>{try{navigator.vibrate?.([60,40,120])}catch{}},[]),(0,M.jsxs)(`div`,{className:`flex flex-col items-center`,children:[(0,M.jsxs)(`div`,{className:`relative grid size-28 place-items-center`,children:[(0,M.jsx)(Je,{}),[0,1].map(e=>(0,M.jsx)(c.span,{className:`absolute inset-0 rounded-full bg-primary/20`,initial:{scale:.4,opacity:.8},animate:{scale:1.5,opacity:0},transition:{duration:1.6,delay:.2+e*.4,repeat:2}},e)),(0,M.jsx)(c.div,{className:`grid size-20 place-items-center rounded-full bg-primary text-primary-foreground shadow-lg`,initial:{scale:0,rotate:-90},animate:{scale:1,rotate:0},transition:{type:`spring`,stiffness:260,damping:14},children:(0,M.jsx)(c.svg,{viewBox:`0 0 24 24`,className:`size-10`,fill:`none`,stroke:`currentColor`,strokeWidth:3,children:(0,M.jsx)(c.path,{d:`M5 12.5l4.5 4.5L19 7.5`,strokeLinecap:`round`,strokeLinejoin:`round`,initial:{pathLength:0},animate:{pathLength:1},transition:{duration:.5,delay:.35}})})})]}),e&&(0,M.jsxs)(c.div,{initial:{opacity:0,y:16},animate:{opacity:1,y:0},transition:{delay:.6},className:`mt-5 w-full rounded-2xl border border-dashed border-primary/40 bg-card p-4 text-left shadow-soft`,children:[(0,M.jsxs)(`div`,{className:`flex items-center justify-between text-xs text-muted-foreground`,children:[(0,M.jsx)(`span`,{children:`No. pesanan`}),(0,M.jsxs)(`span`,{className:`font-mono font-semibold text-foreground`,children:[`#`,e.number]})]}),e.store&&(0,M.jsxs)(`div`,{className:`mt-1.5 flex items-center justify-between text-xs text-muted-foreground`,children:[(0,M.jsx)(`span`,{children:t?`Ambil di`:`Dari`}),(0,M.jsx)(`span`,{className:`font-semibold text-foreground`,children:e.store})]}),(0,M.jsxs)(`div`,{className:`mt-1.5 flex items-center justify-between text-xs text-muted-foreground`,children:[(0,M.jsx)(`span`,{children:`Total bayar`}),(0,M.jsx)(`span`,{className:`font-display text-base font-bold text-primary`,children:A(e.total)})]}),(0,M.jsxs)(`div`,{className:`mt-3 flex items-center gap-2 rounded-xl bg-primary/10 px-3 py-2 text-xs font-medium text-primary`,children:[(0,M.jsxs)(`span`,{className:`relative flex size-2`,children:[(0,M.jsx)(`span`,{className:`absolute inline-flex size-full animate-ping rounded-full bg-primary opacity-75`}),(0,M.jsx)(`span`,{className:`relative inline-flex size-2 rounded-full bg-primary`})]}),`Pesanan sudah diteruskan ke `,t?`toko`:`restoran`,(0,M.jsx)(d,{className:`ml-auto size-3.5`})]})]})]})
}

function Xe({addresses:e,selected:t,onSelect:n,liveAddress:r,liveReady:i,locating:a,onUseGps:o}){
  let s=e=>e.kind===t.kind&&(e.kind!==`saved`||t.kind===`saved`&&e.id===t.id);
  return(0,M.jsxs)(`div`,{className:`space-y-2`,children:[e.filter(x).map(e=>{
    let t=s({kind:`saved`,id:e.id});
    return(0,M.jsxs)(`button`,{type:`button`,onClick:()=>n({kind:`saved`,id:e.id}),className:`flex w-full items-start gap-2 rounded-xl border p-3 text-left transition-colors ${t?`border-primary bg-primary/5`:`border-border bg-background`}`,children:[(0,M.jsx)(me,{className:`mt-0.5 size-4 shrink-0 text-primary`}),(0,M.jsxs)(`span`,{className:`min-w-0 flex-1`,children:[(0,M.jsxs)(`span`,{className:`flex items-center gap-1.5 text-sm font-semibold`,children:[e.label,e.is_default&&(0,M.jsx)(`span`,{className:`rounded-full bg-primary/10 px-2 py-0.5 text-[10px] font-bold text-primary`,children:`Utama`})]}),(0,M.jsx)(`span`,{className:`mt-0.5 block line-clamp-2 text-xs text-muted-foreground`,children:e.address})]}),t&&(0,M.jsx)(d,{className:`mt-0.5 size-4 shrink-0 text-primary`})]},e.id)
  }),(0,M.jsxs)(`button`,{type:`button`,onClick:()=>i?n({kind:`live`}):o(),className:`flex w-full items-start gap-2 rounded-xl border p-3 text-left transition-colors ${s({kind:`live`})?`border-primary bg-primary/5`:`border-border bg-background`}`,children:[a?(0,M.jsx)(p,{className:`mt-0.5 size-4 shrink-0 animate-spin text-primary`}):(0,M.jsx)(y,{className:`mt-0.5 size-4 shrink-0 text-primary`}),(0,M.jsxs)(`span`,{className:`min-w-0 flex-1`,children:[(0,M.jsx)(`span`,{className:`block text-sm font-semibold`,children:`Lokasi saya sekarang`}),(0,M.jsx)(`span`,{className:`mt-0.5 block line-clamp-2 text-xs text-muted-foreground`,children:a?`Mengambil lokasi…`:i?r??`Titik GPS siap dipakai`:`Ketuk untuk mengambil titik GPS`})]}),s({kind:`live`})&&(0,M.jsx)(d,{className:`mt-0.5 size-4 shrink-0 text-primary`})]}),(0,M.jsxs)(m,{type:`button`,variant:`ghost`,size:`sm`,className:`w-full`,onClick:o,disabled:a,children:[(0,M.jsx)(y,{className:`size-4`}),` Perbarui titik GPS`]})]})
}

var gpSpiceMap={"Tidak pedas":`Tidak pedas`,Sedang:`Pedas sedang`,Pedas:`Pedas`},
gpSizeMap={small:`Small`,medium:`Medium`,large:`Large`},
gpTierIcoMap={saver:D,standard:ae,priority:T},
gpTabs=[{key:`delivery`,label:`Diantar kurir`,hint:`Ke alamatmu`,icon:ae},{key:`pickup`,label:`Ambil sendiri`,hint:`Gratis ongkir`,icon:g}],
gpInputCls=`h-11 w-full rounded-xl border-[1.5px] border-primary/25 bg-secondary/40 px-3 text-[13px] font-semibold text-foreground outline-none transition-colors placeholder:font-normal placeholder:text-muted-foreground focus:border-primary`;

function ot(e,t){let n=typeof e==`number`?e:Number(e),r=typeof t==`number`?t:Number(t);return!Number.isFinite(n)||!Number.isFinite(r)||Math.abs(n)>90||Math.abs(r)>180?null:{lat:n,lng:r}}
function st({lat:e,lng:t}){return`https://www.google.com/maps/search/?api=1&query=${e},${t}`}
function gpInitials(e){let t=e.trim().split(/\s+/).filter(Boolean);return t.length===0?`?`:(t[0].charAt(0)+(t.length>1?t[t.length-1].charAt(0):``)).toUpperCase()}
function gpAddrIcon(e,t){if(e===`live`)return y;if(e===`saved`){if(/kantor|kerja|toko|usaha/i.test(t))return gpIcoBrief;if(/rumah|kos|home/i.test(t))return gpIcoHome}return me}

function I(){
  let e=we(),
  {items:t,restaurant:n,subtotal:i,totalItems:totItems,clear:c}=xe(),
  {user:lUser,isAdmin:isAdm}=Ee(),
  {data:p}=Oe(lUser?.id),
  h=o(),
  gWa=Ce(),
  [ae,y]=(0,j.useState)(!1),
  [x,be]=(0,j.useState)(``),
  [S,C]=(0,j.useState)(``),
  [w,T]=(0,j.useState)(``),
  E=(0,j.useRef)(null),
  [D,N]=(0,j.useState)(``),
  P=(0,j.useRef)(!1),
  Je=(0,j.useRef)(null),
  [Ze,tt]=(0,j.useState)(``),
  [F,it]=(0,j.useState)(!1),
  [editCust,setEditCust]=(0,j.useState)(!1),
  custInitRef=(0,j.useRef)(!1),
  [editNote,setEditNote]=(0,j.useState)(!1),
  [addrSheet,setAddrSheet]=(0,j.useState)(!1),
  [editPoint,setEditPoint]=(0,j.useState)(!1),
  [editAddrTxt,setEditAddrTxt]=(0,j.useState)(!1),
  I=We(lUser?.id),
  ct=I.addresses,
  R=I.live,
  lt=!!I.point&&!I.loading&&!I.needsChoice&&!I.needsVerify,
  ut=!I.activeChoice||I.activeChoice.kind===`custom`?{kind:`manual`}:I.activeChoice,
  dt={lat:I.point?.latitude??null,lng:I.point?.longitude??null},
  [ft,pt]=(0,j.useState)(!1),
  mt=(0,j.useRef)(!1),
  [ht,gt]=(0,j.useState)(!1),
  [_t,vt]=(0,j.useState)(!1),
  [yt,bt]=(0,j.useState)(null),
  {data:xt=`legacy`}=s(_e),
  {data:St=Ve}=s(oe),
  {data:Ct}=s(le),
  {data:wt=ie}=s(ye),
  {data:Tt,isPending:Et}=s(fe(n?.id)),
  Dt=Tt?.fee??Ct,
  z=Tt?.tiers??wt,
  [B,Ot]=(0,j.useState)(`standard`),
  [V,H]=(0,j.useState)(null),
  [kt,At]=(0,j.useState)(!1),
  [jt,Mt]=(0,j.useState)(!1),
  [pmPayMethod,pmSetPayMethod]=(0,j.useState)(`cash`),
  [pmLoyaltyCfg,pmSetLoyaltyCfg]=(0,j.useState)({enabled:!0,spend_per_point:1e4});

  (0,j.useEffect)(()=>{
    let e=!0;
    return a.from(`loyalty_settings`).select(`enabled,spend_per_point`).eq(`id`,1).maybeSingle().then(({data:t})=>{
      !e||!t||pmSetLoyaltyCfg({enabled:t.enabled!==!1,spend_per_point:Math.max(100,Number(t.spend_per_point||1e4))})
    }),()=>{e=!1}
  },[]);

  (0,j.useEffect)(()=>{
    p&&(be(e=>e||p.full_name||``),C(e=>e||p.phone||``),T(e=>e||(E.current=p.address||``,E.current)))
  },[p]);

  (0,j.useEffect)(()=>{
    custInitRef.current||!p||(custInitRef.current=!0,(!(p.full_name||``).trim()||!(p.phone||``).trim())&&setEditCust(!0))
  },[p]);

  let Nt=I.point?`${I.point.source}:${I.point.source===`saved`?I.point.id:``}`:``,
  U=I.point?.address;
  (0,j.useEffect)(()=>{
    if(!U)return;
    let e=Nt.startsWith(`saved:`);
    T(t=>{let n=!t.trim()||t===E.current;return!e&&!n?t:(E.current=U,U)})
  },[Nt,U]);

  (0,j.useEffect)(()=>{
    P.current||!I.point||N(gpLmFind(gpLmList(lUser?.id),I.point)??``)
  },[I.point?`${I.point.latitude.toFixed(4)},${I.point.longitude.toFixed(4)}`:``,lUser?.id]);

  let W=ot(dt.lat,dt.lng),
  G=ot(n?.latitude,n?.longitude),
  Pt=Ge(n&&G?{id:n.id,latitude:G.lat,longitude:G.lng}:null,W?{latitude:W.lat,longitude:W.lng}:null,!!lUser),
  K=G&&W?Pt.distanceKm:null,
  Ft=Pt.loading,
  gLat=G?.lat??null,
  gLng=G?.lng??null,
  wLat=W?.lat??null,
  wLng=W?.lng??null,
  restPos=(0,j.useMemo)(()=>gLat!=null&&gLng!=null?{lat:gLat,lng:gLng}:null,[gLat,gLng]),
  custPos=(0,j.useMemo)(()=>wLat!=null&&wLng!=null?{lat:wLat,lng:wLng}:null,[wLat,wLng]),
  It=K==null?0:ze({distanceKm:K,...he(Dt,n)}),
  [q,Lt]=(0,j.useState)(`delivery`),
  {data:Rt,isPending:J,isError:Y}=s(re),
  X=Re(Rt??Te,q),
  Z=q===`pickup`,
  zt=Tt?.maxDistanceKm??null,
  Bt=!Z&&de(K,zt),
  Vt=`Titik pengantaran terlalu jauh (${Pe(K??0)}). Batas pengantaran wilayah ini ${zt} km — pilih titik lain atau Ambil Sendiri.`,
  Ht=z.enabled?z.tiers[B]:void 0,
  Q=Z?0:z.enabled?ue(It,Ht):It,
  $=i+0+X+Q,
  Ut=V?Math.min(V.discount,$):0,
  Wt=Math.max(0,$-Ut),
  pmWalletBal=Number(p?.wallet_balance??0),
  pmEstPts=pmLoyaltyCfg.enabled&&Wt>0?Math.floor(Wt/pmLoyaltyCfg.spend_per_point):0,
  Gt=async e=>{
    let t=e.trim().toUpperCase();
    if(t){
      At(!0);
      try{
        let{data:e,error:n}=await a.rpc(`voucher_status`,{_code:t,_subtotal:Math.round(i),_delivery_fee:Math.round(Q)});
        if(n)throw n;
        let r=e;
        if(!r||r.valid===!1){v.error(k(`not_found`));return}
        if(!r.eligible){v.error(k(r.reason,r));return}
        H(r),Mt(!1),v.success(`Voucher ${r.code} diterapkan — hemat ${A(r.discount)}`)
      }catch{v.error(`Gagal memeriksa voucher. Coba lagi.`)}finally{At(!1)}
    }
  },
  Kt=()=>H(null);

  (0,j.useEffect)(()=>{
    if(!V)return;
    let e=!0;
    return a.rpc(`voucher_status`,{_code:V.code,_subtotal:Math.round(i),_delivery_fee:Math.round(Q)}).then(({data:t})=>{
      if(!e)return;
      let n=t;
      if(!n||n.valid===!1||!n.eligible){H(null),v.message(`Voucher dilepas: ${k(n?.reason,n??void 0)}`);return}
      n.discount!==V.discount&&H(n)
    }),()=>{e=!1}
  },[V?.code,i,Q]);

  let qt=async()=>{
    it(!0);
    try{
      if(!await R.request()){v.error(`Gagal mengambil lokasi. Izinkan akses GPS lalu coba lagi.`);return}
      I.setManual({kind:`live`}),v.success(`Lokasi diperbarui 📍`)
    }finally{it(!1)}
  },
  Jt=e=>{e.kind===`saved`?I.setManual(e):e.kind===`live`&&(R.location?I.setManual({kind:`live`}):qt())},
  Yt=async()=>{
    if(!mt.current){
      mt.current=!0,gt(!0);
      try{await Xt()}finally{mt.current=!1,gt(!1)}
    }
  },
  Xt=async()=>{
    if(!lUser||!n||t.length===0)return;
    if(J||Y){v.error(`Biaya layanan belum dapat dimuat. Coba lagi.`);return}
    try{
      if(Re(await h.fetchQuery(re),q)!==X){v.message(`Biaya layanan diperbarui. Periksa total lalu pesan kembali.`);return}
    }catch{v.error(`Biaya layanan belum dapat diperiksa.`);return}
    let{data:r,error:o}=await a.from(`menu_items`).select(`id, name, has_spice_levels`).in(`id`,t.map(e=>e.menuItemId));
    if(o){v.error(`Pilihan menu belum dapat diperiksa. Coba lagi.`);return}
    let s=t.find(e=>r?.some(t=>t.id===e.menuItemId&&t.has_spice_levels)&&!Se(e.spiceLevel));
    if(s){v.error(`Pilih level pedas untuk ${s.name} dengan menambah ulang menu dari restoran.`);return}
    if(!x.trim()||!S.trim()){setEditCust(!0),v.error(`Nama dan nomor WhatsApp wajib diisi.`);return}
    let u=ne(S);
    if(u){setEditCust(!0),v.error(u);return}
    let ee=_(S);
    if(gWa.data?.enabled&&!isAdm){
      let e=await gWa.refetch();
      if(e.error||!e.data){v.error(`Verifikasi nomor belum dapat diperiksa. Coba lagi.`);return}
      if(e.data.enabled&&(e.data.required||e.data.firstOrder)&&(!e.data.verified||_(e.data.phone)!==ee)){y(!0);return}
    }
    if(!Z&&!w.trim()){setEditAddrTxt(!0),v.error(`Alamat pengantaran wajib diisi.`);return}
    let f=Z?null:gpLmVal(D);
    if(f){v.error(f),Je.current?.focus();return}
    if(!Z&&(!lt||!W||K==null)){v.error(Ft?`Jarak sedang dihitung, coba lagi sebentar.`:`Pilih titik pengantaran (alamat tersimpan atau lokasi saya) dulu.`);return}
    if(!Z&&n&&Et){v.error(`Pengaturan ongkir sedang dimuat, coba lagi sebentar.`);return}
    if(Bt){v.error(Vt);return}
    let{data:pData}=await a.rpc(`restaurant_effective_status`,{_restaurant_id:n.id}),mData=pData??{};
    if(mData.status&&mData.status!==`open`){
      let e=mData.status===`holiday`?`sedang libur`:mData.status===`temp_closed`?`tutup sementara`:`di luar jam operasional`;
      v.error(`Restoran ${e} dan belum menerima pesanan saat ini.`);return
    }
    if(pmPayMethod===`wallet`&&pmWalletBal<Wt){
      v.error(`Saldo GoGoGo Pay tidak cukup (${A(pmWalletBal)}). Top up di GoGoGo Pay terlebih dahulu.`);return
    }
    pt(!0);
    try{
      let e=0,r=null;
      if(V){
        let{data:t,error:n}=await a.rpc(`claim_voucher`,{_code:V.code,_subtotal:Math.round(i),_delivery_fee:Math.round(Q)});
        if(n)throw n;
        let o=t??{};
        if(!o.success){v.error(k(o.reason,V)),H(null),pt(!1);return}
        e=Math.min($,o.discount??0),r=V.code
      }
      let o=Math.max(0,$-e),s=je(),
      {data:u,error:d}=await a.from(`orders`).insert({
        customer_id:lUser.id,
        restaurant_id:n.id,
        order_number:s,
        customer_name:x.trim(),
        customer_phone:ee,
        customer_address:Z?`Ambil sendiri di ${n.name}`:gpJoin(w,D),
        latitude:Z?null:W?.lat,
        longitude:Z?null:W?.lng,
        status:Z?`waiting_restaurant`:Be(xt),
        fulfillment_type:q,
        payment_method:pmPayMethod,
        payment_status:pmPayMethod===`wallet`||o===0?`paid`:`unpaid`,
        auto_cancel_enabled:St.enabled,
        driver_timeout_minutes:St.minutes,
        subtotal:i,
        admin_fee:0,
        app_fee:X,
        delivery_fee:Q,
        delivery_tier:Z?`standard`:z.enabled?B:`standard`,
        delivery_tier_label:Z?`Ambil Sendiri`:z.enabled?z.tiers[B].label:z.tiers.standard.label,
        discount:e,
        voucher_code:r,
        total:o,
        notes:Ze.trim()||null
      }).select().single();
      if(d)throw d;
      if(pmPayMethod===`wallet`&&o>0){
        let{data:wp,error:we}=await a.rpc(`wallet_pay_order`,{_order_id:u.id,_amount:Math.round(o),_description:`Pembayaran Pesanan #${s} - ${n.name}`});
        if(we||wp?.success===!1){await a.from(`orders`).delete().eq(`id`,u.id);throw new Error(wp?.message||we?.message||`Saldo GoGoGo Pay tidak cukup.`)}
      }
      r&&(await a.rpc(`link_voucher_redemption`,{_code:r,_order_id:u.id,_discount:e}),h.invalidateQueries({queryKey:[`my-vouchers`]}),h.invalidateQueries({queryKey:[`available-vouchers`]}));
      let f=t.map(e=>{let t=e.basePrice??e.price;return{order_id:u.id,menu_item_id:e.menuItemId,menu_name:Fe(e.name,e.size,e.spiceLevel),quantity:e.quantity,price:e.price,subtotal:e.price*e.quantity,restaurant_price:t,markup_amount:e.price-t,notes:e.notes||null}}),
      {error:pErr}=await a.from(`order_items`).insert(f);
      if(pErr)throw pErr;
      !Z&&W&&gpLmSave(lUser.id,{lat:W.lat,lng:W.lng,text:D.trim()}),
      await a.from(`profiles`).update(Z||!W?{full_name:x.trim()}:{full_name:x.trim(),address:w.trim(),latitude:W.lat,longitude:W.lng}).eq(`id`,lUser.id),
      h.invalidateQueries({queryKey:[`profile`,lUser.id]}),
      h.invalidateQueries({queryKey:[`orders`,lUser.id]}),
      h.invalidateQueries({queryKey:[`wallet-transactions`,lUser.id]}),
      h.invalidateQueries({queryKey:[`user-points`,lUser.id]}),
      Ie(`new_order`,u.id),
      bt({number:s,total:Number(u.total),store:n?.name??``,eta:!Z&&z.enabled?z.tiers[B].eta:null}),
      c(),
      v.success(Z||xt===`restaurant_first`?`Pesanan terkirim! Menunggu konfirmasi restoran 🍽️`:`Pesanan terkirim! Mencari kurir terdekat 🛵`),
      vt(!0)
    }catch(t){
      let n=t instanceof Error?t.message:t?.message??`Gagal membuat pesanan`;
      n.includes(`duplicate_order`)?(c(),v.success(`Pesananmu sudah terkirim. Cek statusnya di halaman Pesanan.`),e({to:`/orders`})):n.includes(`distance_exceeded`)?v.error(`Titik pengantaran melebihi batas jarak wilayah ini. Pilih titik lain atau Ambil Sendiri.`):n.toLowerCase().includes(`row-level security`)||n.toLowerCase().includes(`violates`)?v.error(`Akun kamu sedang ditangguhkan sehingga tidak bisa membuat pesanan. Hubungi dukungan.`):v.error(n)
    }finally{pt(!1)}
  };

  if(_t){
    let steps=Z?[`Pesanan dibuat`,`Diproses toko`,`Siap diambil`,`Selesai`]:xt===`restaurant_first`?[`Pesanan dibuat`,`Dikonfirmasi resto`,`Diantar`,`Tiba`]:[`Pesanan dibuat`,`Mencari kurir`,`Diantar`,`Tiba`];
    return(0,M.jsx)(`div`,{className:`px-6 pb-10 pt-10 text-center`,children:(0,M.jsxs)(`div`,{className:`mx-auto w-full max-w-sm`,children:[(0,M.jsx)(Ye,{info:null,isPickup:Z}),(0,M.jsx)(`h1`,{className:`mt-4 font-display text-[22px] font-bold animate-in fade-in slide-in-from-bottom-2 duration-500`,children:`Pesanan berhasil dibuat!`}),(0,M.jsxs)(`p`,{className:`mx-auto mt-2 max-w-[300px] text-sm leading-relaxed text-muted-foreground`,children:[Z?`Pesananmu dikirim ke toko. Ambil setelah statusnya "Siap Diambil".`:xt===`restaurant_first`?`Pesananmu sudah dikirim ke restoran untuk dikonfirmasi.`:`Kami sedang mencari kurir terdekat untuk pesananmu.`,` `,`Pantau perkembangannya melalui status pesanan.`]}),yt&&(0,M.jsxs)(`section`,{"aria-label":`Detail pesanan`,className:`mt-5 space-y-2.5 rounded-[20px] border-[1.5px] border-dashed border-primary/35 bg-card p-4 text-left`,children:[(0,M.jsxs)(`div`,{className:`flex items-center justify-between gap-3 text-[12.5px]`,children:[(0,M.jsx)(`span`,{className:`text-muted-foreground`,children:`No. pesanan`}),(0,M.jsxs)(`span`,{className:`font-extrabold tracking-wide`,children:[`#`,yt.number]})]}),yt.store&&(0,M.jsxs)(`div`,{className:`flex items-center justify-between gap-3 text-[12.5px]`,children:[(0,M.jsx)(`span`,{className:`text-muted-foreground`,children:Z?`Ambil di`:`Dari`}),(0,M.jsx)(`span`,{className:`truncate font-extrabold`,children:yt.store})]}),yt.eta&&(0,M.jsxs)(`div`,{className:`flex items-center justify-between gap-3 text-[12.5px]`,children:[(0,M.jsx)(`span`,{className:`text-muted-foreground`,children:`Perkiraan tiba`}),(0,M.jsx)(`span`,{className:`font-extrabold`,children:yt.eta})]}),(0,M.jsxs)(`div`,{className:`flex items-baseline justify-between gap-3 border-t-[1.5px] border-dashed border-border pt-2.5`,children:[(0,M.jsx)(`span`,{className:`text-[13.5px] font-extrabold`,children:`Total bayar`}),(0,M.jsx)(`span`,{className:`font-display text-[19px] font-extrabold text-primary`,children:A(yt.total)})]})]}),(0,M.jsx)(`ol`,{"aria-label":`Perjalanan pesanan`,className:`mt-3.5 grid grid-cols-4 rounded-[20px] bg-card px-1.5 pb-3 pt-3.5 shadow-soft`,children:steps.map((e,n)=>{let r=n===0,i=n===1;return(0,M.jsxs)(`li`,{className:`relative flex flex-col items-center gap-1.5`,children:[n<steps.length-1&&(0,M.jsx)(`span`,{"aria-hidden":!0,className:l(`absolute left-1/2 top-[15px] h-[3px] w-full`,r?`bg-primary`:`bg-border`)}),(0,M.jsx)(`span`,{className:l(`relative z-[1] grid size-8 place-items-center rounded-full text-xs font-extrabold`,r?`bg-primary text-primary-foreground`:i?`bg-card text-primary ring-[3px] ring-primary`:`bg-muted text-muted-foreground`),children:r?(0,M.jsx)(d,{className:`size-4`,strokeWidth:3}):n+1}),(0,M.jsx)(`span`,{className:l(`px-0.5 text-[11px] leading-tight`,r||i?`font-extrabold text-foreground`:`font-semibold text-muted-foreground`),children:e})]},e)})}),(0,M.jsx)(m,{variant:`hero`,size:`xl`,className:`mt-5 w-full`,onClick:()=>e({to:`/orders`}),children:`Pantau Status Pesanan`}),(0,M.jsx)(`div`,{className:`mt-2.5`,children:(0,M.jsx)(f,{title:`Bagikan GoGoGo`,content:Ne({kind:`app`}),trigger:(0,M.jsxs)(m,{variant:`outline`,size:`lg`,className:`w-full rounded-2xl border-[1.5px] font-extrabold text-primary`,children:[(0,M.jsx)(ee,{className:`size-4`}),` Bagikan GoGoGo ke teman`]})})})]})})
  }

  if(t.length===0||!n)return(0,M.jsx)(`div`,{className:`grid place-items-center px-6 py-24 text-center`,children:(0,M.jsxs)(`div`,{children:[(0,M.jsx)(`p`,{className:`font-semibold`,children:`Keranjang kosong`}),(0,M.jsx)(m,{asChild:!0,variant:`hero`,className:`mt-4`,children:(0,M.jsx)(r,{to:`/food`,children:`Mulai memesan`})})]})});

  let curPt=I.point,
  ptLabel=curPt?curPt.label:`Belum ada titik antar`,
  isSavedDef=curPt?.source===`saved`?!!ct.find(e=>e.id===curPt.id)?.is_default:!1,
  PtIco=gpAddrIcon(curPt?.source,curPt?.label??``),
  isEditingPt=editPoint||I.needsVerify||I.activeChoice?.kind===`custom`,
  showPreviewMap=!!curPt&&!isEditingPt,
  showPtCard=!curPt||I.needsChoice||isEditingPt,
  showAddrField=editAddrTxt||!w.trim(),
  hasLandmark=!!D.trim(),
  isWaVerified=!!gWa.data?.verified&&_(gWa.data.phone)===_(S),
  totQty=totItems??t.reduce((a,b)=>a+(b.quantity||1),0),
  etaFooter=Z?`Ambil di ${n.name} · Gratis ongkir`:z.enabled&&K!=null?`Tiba ±${z.tiers[B].eta} · ke ${ptLabel}`:null,
  totalStr=J||Y?`—`:A(Wt),
  needPick=!Z&&!lt;

  return(0,M.jsxs)(`div`,{className:`pb-48`,children:[
    (0,M.jsx)(qe,{show:ft,isPickup:Z}),
    (0,M.jsxs)(`div`,{className:`flex items-center gap-3 px-4 py-3`,children:[
      (0,M.jsx)(`button`,{type:`button`,onClick:()=>e({to:`/cart`}),className:`grid size-11 shrink-0 place-items-center rounded-full bg-secondary text-primary transition-transform active:scale-95`,"aria-label":`Kembali ke keranjang`,children:(0,M.jsx)(u,{className:`size-5`})}),
      (0,M.jsxs)(`div`,{className:`min-w-0`,children:[
        (0,M.jsx)(`h1`,{className:`font-display text-xl font-bold leading-tight`,children:`Konfirmasi Pesanan`}),
        (0,M.jsxs)(`p`,{className:`truncate text-xs text-muted-foreground`,children:[totQty,` item dari `,n.name]})
      ]})
    ]}),
    (0,M.jsx)(`div`,{role:`group`,"aria-label":`Cara terima pesanan`,className:`mx-4 mt-0.5 grid grid-cols-2 gap-1 rounded-[18px] bg-card p-[5px] shadow-soft`,children:gpTabs.map(e=>{
      let t=q===e.key,TabIco=e.icon;
      return(0,M.jsxs)(`button`,{type:`button`,"aria-pressed":t,onClick:()=>Lt(e.key),className:l(`flex min-h-[52px] items-center gap-2.5 rounded-[14px] px-3 py-2 text-left transition-colors active:scale-[0.98]`,t?`bg-primary text-primary-foreground`:`text-foreground hover:bg-muted`),children:[
        (0,M.jsx)(TabIco,{className:`size-5 shrink-0`}),
        (0,M.jsxs)(`span`,{className:`min-w-0`,children:[
          (0,M.jsx)(`span`,{className:`block text-[13.5px] font-extrabold`,children:e.label}),
          (0,M.jsx)(`span`,{className:l(`block text-[11.5px] font-semibold`,t?`text-primary-foreground/85`:`text-muted-foreground`),children:e.hint})
        ]})
      ]},e.key)
    })}),
    Z?(0,M.jsx)(gpPickupCard,{restaurant:n,coords:G}):(0,M.jsxs)(`section`,{"aria-label":`Alamat pengantaran`,className:`mx-4 mt-3 overflow-hidden rounded-[22px] bg-card shadow-soft`,children:[
      showPreviewMap&&(0,M.jsxs)(`div`,{className:`relative px-2 pt-2`,children:[
        (0,M.jsx)(gpMiniMap,{restaurant:restPos,customer:custPos,interactive:!1,className:`h-32`}),
        (0,M.jsxs)(`span`,{className:`pointer-events-none absolute left-4 top-4 z-[500] inline-flex h-7 items-center gap-1.5 rounded-full bg-card/95 px-2.5 text-[11.5px] font-extrabold text-foreground shadow-soft`,children:[
          (0,M.jsx)(gpIcoCourier,{className:`size-3.5`}),
          Ft?`Menghitung jarak…`:K==null?`Jarak belum terhitung`:`${Pe(K)} dari resto`
        ]}),
        (0,M.jsxs)(`button`,{type:`button`,onClick:()=>setEditPoint(!0),className:`absolute bottom-5 right-4 z-[500] inline-flex h-8 items-center gap-1.5 rounded-full bg-card px-3 text-xs font-extrabold text-primary shadow-float transition-transform active:scale-95`,children:[
          (0,M.jsx)(me,{className:`size-3.5`}),` Ubah titik`
        ]})
      ]}),
      (0,M.jsxs)(`div`,{className:`space-y-3.5 p-3.5`,children:[
        (0,M.jsxs)(`div`,{className:`flex items-start gap-3`,children:[
          (0,M.jsx)(`span`,{className:`grid size-10 shrink-0 place-items-center rounded-[14px] bg-secondary text-primary`,children:(0,M.jsx)(PtIco,{className:`size-[19px]`})}),
          (0,M.jsxs)(`div`,{className:`min-w-0 flex-1`,children:[
            (0,M.jsx)(`p`,{className:`text-[11px] font-extrabold uppercase tracking-[0.06em] text-muted-foreground`,children:`Antar ke`}),
            (0,M.jsxs)(`p`,{className:`mt-0.5 flex items-center gap-1.5 text-[15px] font-extrabold`,children:[
              (0,M.jsx)(`span`,{className:`truncate`,children:ptLabel}),
              isSavedDef&&(0,M.jsx)(`span`,{className:`shrink-0 rounded-full bg-secondary px-[7px] py-0.5 text-[10.5px] font-extrabold text-primary`,children:`Utama`})
            ]}),
            !showAddrField&&(0,M.jsxs)(M.Fragment,{children:[
              (0,M.jsx)(`p`,{className:`mt-0.5 line-clamp-2 text-[12.5px] leading-snug text-muted-foreground`,children:w}),
              (0,M.jsxs)(`button`,{type:`button`,onClick:()=>setEditAddrTxt(!0),className:`mt-1 inline-flex items-center gap-1 text-xs font-bold text-primary`,children:[(0,M.jsx)(gpIcoPencil,{className:`size-3`}),` Ubah tulisan alamat`]})
            ]})
          ]}),
          (0,M.jsx)(`button`,{type:`button`,onClick:()=>setAddrSheet(!0),className:`h-9 shrink-0 rounded-full border-[1.5px] border-primary/25 bg-card px-3.5 text-[12.5px] font-extrabold text-primary transition-transform active:scale-95`,children:`Ganti`})
        ]}),
        showPtCard&&(0,M.jsx)(Ue,{compact:!0,editing:editPoint,onEditingChange:setEditPoint,state:I,userId:lUser?.id,distanceKm:K,distanceLoading:Ft,restaurant:restPos}),
        editPoint&&!I.needsVerify&&(0,M.jsxs)(m,{type:`button`,variant:`outline`,size:`sm`,className:`w-full rounded-xl`,onClick:()=>setEditPoint(!1),children:[(0,M.jsx)(d,{}),` Selesai mengatur titik`]}),
        showAddrField&&(0,M.jsxs)(`div`,{className:`space-y-1.5`,children:[
          (0,M.jsxs)(`label`,{htmlFor:`checkout-address`,className:`text-[12.5px] font-extrabold`,children:[`Alamat lengkap `,(0,M.jsx)(`span`,{className:`text-destructive`,children:`*`})]}),
          (0,M.jsx)(b,{id:`checkout-address`,value:w,onChange:e=>{setEditAddrTxt(!0),T(e.target.value)},placeholder:`Jalan, desa/blok, nomor rumah…`,rows:2,className:`rounded-xl border-[1.5px] border-primary/25 bg-secondary/40 text-[13px] font-semibold`})
        ]}),
        (0,M.jsxs)(`div`,{className:`space-y-1.5`,children:[
          (0,M.jsxs)(`label`,{htmlFor:`checkout-landmark`,className:`text-[12.5px] font-extrabold`,children:[`Patokan rumah `,(0,M.jsx)(`span`,{className:`text-destructive`,children:`*`})]}),
          (0,M.jsx)(`input`,{id:`checkout-landmark`,ref:Je,value:D,onChange:e=>{P.current=!0,N(e.target.value.slice(0,200))},maxLength:200,placeholder:`Contoh: rumah cat biru, depan SD Abepura`,"aria-describedby":`checkout-landmark-hint`,className:l(gpInputCls,!hasLandmark&&`border-destructive/50`)}),
          (0,M.jsx)(`p`,{id:`checkout-landmark-hint`,className:l(`text-[11.5px] leading-snug`,hasLandmark?`text-muted-foreground`:`text-destructive`),children:hasLandmark?`Membantu kurir kalau titik di peta meleset.`:`Wajib diisi supaya kurir tidak kesasar.`})
        ]})
      ]})
    ]}),
    (0,M.jsxs)(`section`,{"aria-label":`Data pemesan`,className:`mx-4 mt-3 rounded-[22px] bg-card shadow-soft`,children:[
      (0,M.jsxs)(`div`,{className:`flex items-center gap-3 px-3.5 py-3`,children:[
        (0,M.jsx)(`span`,{"aria-hidden":!0,className:`grid size-10 shrink-0 place-items-center rounded-full bg-accent/15 text-[13px] font-extrabold text-[#9A4F00] dark:text-accent`,children:gpInitials(x)}),
        (0,M.jsxs)(`div`,{className:`min-w-0 flex-1`,children:[
          (0,M.jsx)(`p`,{className:`truncate text-sm font-extrabold`,children:x.trim()||`Nama pemesan belum diisi`}),
          (0,M.jsxs)(`p`,{className:`flex items-center gap-1.5 text-[12.5px] text-muted-foreground`,children:[
            (0,M.jsx)(gpIcoPhone,{className:`size-3 shrink-0`}),
            (0,M.jsx)(`span`,{className:`truncate`,children:S.trim()?`${S} · WhatsApp`:`Nomor WhatsApp belum diisi`})
          ]})
        ]}),
        (0,M.jsx)(`button`,{type:`button`,onClick:()=>setEditCust(e=>!e),"aria-label":`Ubah nama dan nomor WhatsApp`,"aria-expanded":editCust,className:`grid size-10 shrink-0 place-items-center rounded-full bg-secondary text-primary transition-transform active:scale-95`,children:(0,M.jsx)(gpIcoPencil,{className:`size-4`})})
      ]}),
      editCust&&(0,M.jsxs)(`div`,{className:`grid gap-2.5 px-3.5 pb-3.5`,children:[
        (0,M.jsxs)(`label`,{className:`grid gap-1.5 text-[12.5px] font-extrabold`,children:[`Nama pemesan`,(0,M.jsx)(`input`,{value:x,onChange:e=>be(e.target.value),placeholder:`Nama lengkap`,autoComplete:`name`,className:gpInputCls})]}),
        (0,M.jsxs)(`label`,{className:`grid gap-1.5 text-[12.5px] font-extrabold`,children:[`Nomor WhatsApp`,(0,M.jsx)(`input`,{value:S,onChange:e=>C(e.target.value),placeholder:`6281234567890`,inputMode:`tel`,autoComplete:`tel`,className:gpInputCls})]})
      ]}),
      gWa.data?.enabled&&(0,M.jsx)(`div`,{className:`px-3.5 pb-3.5`,children:(0,M.jsx)(m,{type:`button`,variant:`outline`,size:`sm`,className:`rounded-full`,onClick:()=>y(!0),children:isWaVerified?(0,M.jsxs)(M.Fragment,{children:[(0,M.jsx)(d,{}),` WhatsApp terverifikasi`]}):`Verifikasi WhatsApp`})})
    ]}),
    !Z&&z.enabled&&K!=null&&(0,M.jsxs)(M.Fragment,{children:[
      (0,M.jsxs)(`div`,{className:`mx-5 mb-3 mt-6 flex items-baseline justify-between gap-2`,children:[
        (0,M.jsx)(`h2`,{className:`font-display text-base font-bold`,children:`Pilih pengantaran`}),
        (0,M.jsx)(`span`,{className:`text-[11.5px] text-muted-foreground`,children:`Waktu tiba perkiraan`})
      ]}),
      (0,M.jsx)(`div`,{role:`radiogroup`,"aria-label":`Pilih pengantaran`,className:`mx-4 grid grid-cols-3 gap-2`,children:gpTierKeys.map(e=>{
        let t=z.tiers[e],feeVal=ue(It,t),sel=B===e,TierIco=gpTierIcoMap[e];
        return(0,M.jsxs)(`button`,{type:`button`,role:`radio`,"aria-checked":sel,onClick:()=>Ot(e),className:l(`relative flex flex-col items-start gap-1 rounded-[18px] border-2 px-2.5 pb-2.5 pt-3 text-left transition-colors active:scale-[0.97]`,sel?`border-primary bg-secondary/60`:`border-border bg-card`),children:[
          e===`standard`&&(0,M.jsx)(`span`,{className:`absolute -top-2.5 left-2 rounded-full bg-accent px-[7px] py-0.5 text-[9.5px] font-extrabold text-[#2B1600]`,children:`Rekomendasi`}),
          sel&&(0,M.jsx)(`span`,{"aria-hidden":!0,className:`absolute right-2 top-2 grid size-[18px] place-items-center rounded-full bg-primary text-primary-foreground`,children:(0,M.jsx)(d,{className:`size-3`,strokeWidth:3.2})}),
          (0,M.jsx)(`span`,{className:l(`grid size-8 place-items-center rounded-full`,sel?`bg-primary text-primary-foreground`:`bg-secondary text-primary`),children:(0,M.jsx)(TierIco,{className:`size-4`})}),
          (0,M.jsx)(`span`,{className:`mt-0.5 text-[13.5px] font-extrabold`,children:t.label}),
          (0,M.jsx)(`span`,{className:`text-[11.5px] leading-tight text-muted-foreground`,children:t.eta}),
          (0,M.jsx)(`span`,{className:`text-[13px] font-extrabold`,children:A(feeVal)})
        ]},e)
      })})
    ]}),
    (0,M.jsxs)(`div`,{className:`mx-5 mb-2.5 mt-6 flex items-center justify-between`,children:[
      (0,M.jsx)(`h2`,{className:`font-display text-base font-bold`,children:`Pesananmu`}),
      (0,M.jsx)(r,{to:`/cart`,className:`flex h-9 items-center px-1.5 text-[12.5px] font-extrabold text-primary`,children:`Ubah pesanan`})
    ]}),
    (0,M.jsxs)(`section`,{"aria-label":`Ringkasan pesanan`,className:`mx-4 rounded-[22px] bg-card px-3.5 py-1 shadow-soft`,children:[
      (0,M.jsxs)(`div`,{className:`flex items-center gap-2.5 border-b-[1.5px] border-dashed border-border py-2.5`,children:[
        n.imageUrl?(0,M.jsx)(gpSafeImg,{src:n.imageUrl,optimize:{width:64},alt:``,width:28,height:28,className:`size-7 shrink-0 rounded-[9px] object-cover`}):(0,M.jsx)(`span`,{className:`grid size-7 shrink-0 place-items-center rounded-[9px] bg-secondary text-primary`,children:(0,M.jsx)(g,{className:`size-3.5`})}),
        (0,M.jsx)(`p`,{className:`min-w-0 truncate text-[13.5px] font-extrabold`,children:n.name}),
        (0,M.jsxs)(`span`,{className:`ml-auto shrink-0 text-xs text-muted-foreground`,children:[totQty,` item`]})
      ]}),
      t.map(e=>{
        let hasDisc=e.originalPrice!=null&&e.originalPrice>e.price,itemNote=e.notes?.trim();
        return(0,M.jsxs)(`div`,{className:`flex gap-3 border-b border-border/70 py-3`,children:[
          (0,M.jsx)(`div`,{className:`size-12 shrink-0 overflow-hidden rounded-[14px] bg-muted`,children:e.imageUrl&&(0,M.jsx)(gpSafeImg,{src:e.imageUrl,optimize:{width:120},alt:e.name,width:48,height:48,className:`size-full object-cover`})}),
          (0,M.jsxs)(`div`,{className:`flex min-w-0 flex-1 flex-col items-start gap-1`,children:[
            (0,M.jsxs)(`p`,{className:`text-[13.5px] font-bold leading-snug`,children:[(0,M.jsxs)(`span`,{className:`font-extrabold text-primary`,children:[e.quantity,`×`]}),` `,e.name]}),
            (e.size||e.spiceLevel||hasDisc)&&(0,M.jsxs)(`div`,{className:`flex flex-wrap gap-1.5`,children:[
              e.size&&(0,M.jsx)(`span`,{className:`rounded-full bg-secondary px-2 py-0.5 text-[11px] font-bold text-primary`,children:gpSizeMap[e.size]??e.size}),
              e.spiceLevel&&(0,M.jsxs)(`span`,{className:`inline-flex items-center gap-1 rounded-full bg-accent/15 px-2 py-0.5 text-[11px] font-bold text-amber-800 dark:text-amber-300`,children:[(0,M.jsx)(gpIcoFlame,{className:`size-3`}),` `,gpSpiceMap[e.spiceLevel]??e.spiceLevel]}),
              hasDisc&&(0,M.jsx)(`span`,{className:`rounded-full gradient-warm px-2 py-0.5 text-[10px] font-bold text-accent-foreground`,children:`Promo`})
            ]}),
            itemNote&&(0,M.jsxs)(`p`,{className:`text-xs italic text-muted-foreground`,children:[`“`,itemNote,`”`]})
          ]}),
          (0,M.jsxs)(`div`,{className:`shrink-0 text-right`,children:[
            (0,M.jsx)(`p`,{className:`text-[13.5px] font-extrabold`,children:A(e.price*e.quantity)}),
            hasDisc&&(0,M.jsx)(`p`,{className:`text-[11px] text-muted-foreground line-through`,children:A(e.originalPrice*e.quantity)})
          ]})
        ]},e.lineId)
      }),
      editNote?(0,M.jsxs)(`div`,{className:`space-y-2 py-3`,children:[
        (0,M.jsx)(`label`,{htmlFor:`checkout-note`,className:`text-[12.5px] font-extrabold`,children:`Catatan untuk restoran`}),
        (0,M.jsx)(b,{id:`checkout-note`,value:Ze,onChange:e=>tt(e.target.value),placeholder:`Contoh: tolong tambah sendok (opsional)`,rows:2,autoFocus:!0,className:`rounded-xl border-[1.5px] border-primary/25 bg-secondary/40 text-[13px] font-semibold`}),
        (0,M.jsx)(`div`,{className:`flex justify-end`,children:(0,M.jsx)(m,{type:`button`,size:`sm`,className:`h-9 rounded-xl px-4`,onClick:()=>setEditNote(!1),children:`Simpan`})})
      ]}):(0,M.jsxs)(`button`,{type:`button`,onClick:()=>setEditNote(!0),className:l(`flex min-h-[50px] w-full items-center gap-2 text-left text-[12.5px] font-bold`,Ze.trim()?`text-foreground`:`text-primary`),children:[
        (0,M.jsx)(gpIcoMsgSq,{className:`size-4 shrink-0`}),
        (0,M.jsx)(`span`,{className:`min-w-0 flex-1 truncate`,children:Ze.trim()?`Catatan: ${Ze.trim()}`:`Tambah catatan untuk restoran`}),
        (0,M.jsx)(gpIcoChevR,{className:`size-4 shrink-0`})
      ]})
    ]}),
    V?(0,M.jsxs)(`div`,{className:`mx-4 mt-3 flex items-center gap-3 rounded-[18px] border-[1.5px] border-primary/30 bg-secondary/70 px-3.5 py-3`,children:[
      (0,M.jsx)(`span`,{className:`grid size-10 shrink-0 place-items-center rounded-xl bg-primary text-primary-foreground`,children:(0,M.jsx)(ke,{className:`size-5`})}),
      (0,M.jsxs)(`span`,{className:`min-w-0 flex-1`,children:[
        (0,M.jsxs)(`span`,{className:`block truncate text-sm font-extrabold`,children:[V.title||V.code,` terpakai`]}),
        (0,M.jsxs)(`span`,{className:`block text-xs text-muted-foreground`,children:[De(V),` · hemat `,A(V.discount)]})
      ]}),
      (0,M.jsx)(`button`,{type:`button`,onClick:Kt,"aria-label":`Lepas voucher ${V.code}`,className:`grid size-10 shrink-0 place-items-center rounded-full bg-card text-muted-foreground transition-transform active:scale-95`,children:(0,M.jsx)(te,{className:`size-4`})})
    ]}):(0,M.jsxs)(`button`,{type:`button`,onClick:()=>Mt(!0),className:`mx-4 mt-3 flex w-[calc(100%-2rem)] items-center gap-3 rounded-[18px] border-[1.5px] border-dashed border-accent/60 bg-accent/10 px-3.5 py-3 text-left transition-transform active:scale-[0.98]`,children:[
      (0,M.jsx)(`span`,{className:`grid size-10 shrink-0 place-items-center rounded-xl bg-accent text-white`,children:(0,M.jsx)(ke,{className:`size-5`})}),
      (0,M.jsxs)(`span`,{className:`min-w-0 flex-1`,children:[
        (0,M.jsx)(`span`,{className:`block text-sm font-extrabold`,children:`Pakai voucher`}),
        (0,M.jsx)(`span`,{className:`block text-xs text-muted-foreground`,children:`Pilih voucher yang tersedia atau masukkan kode`})
      ]}),
      (0,M.jsx)(gpIcoChevR,{className:`size-5 shrink-0 text-muted-foreground`})
    ]}),
    (0,M.jsx)(Ke,{open:jt,onOpenChange:Mt,subtotal:i,deliveryFee:Q,appliedCode:V?.code??null,checking:kt,onPick:e=>void Gt(e.code),onManualCode:e=>void Gt(e)}),
    (0,M.jsxs)(`section`,{"aria-label":`Metode pembayaran`,className:`mx-4 mt-3.5 rounded-[22px] bg-card p-4 shadow-soft`,children:[
      (0,M.jsx)(`h3`,{className:`font-display text-base font-bold`,children:`Metode pembayaran`}),
      (0,M.jsxs)(`div`,{role:`radiogroup`,className:`mt-2.5 space-y-2`,children:[
        (0,M.jsxs)(`button`,{type:`button`,role:`radio`,"aria-checked":pmPayMethod===`cash`,onClick:()=>pmSetPayMethod(`cash`),className:l(`flex w-full items-center gap-3 rounded-2xl border-2 px-3.5 py-3 text-left transition-colors`,pmPayMethod===`cash`?`border-primary bg-primary/5`:`border-border bg-background hover:bg-secondary/60`),children:[
          (0,M.jsx)(`span`,{className:l(`grid size-5 shrink-0 place-items-center rounded-full border-2`,pmPayMethod===`cash`?`border-primary`:`border-muted-foreground/40`),children:pmPayMethod===`cash`&&(0,M.jsx)(`span`,{className:`size-2.5 rounded-full bg-primary`})}),
          (0,M.jsxs)(`span`,{className:`min-w-0 flex-1`,children:[
            (0,M.jsx)(`span`,{className:`block text-sm font-bold`,children:`💵 Tunai / COD`}),
            (0,M.jsx)(`span`,{className:`block text-xs text-muted-foreground`,children:Z?`Bayar di kasir saat ambil pesanan`:`Bayar tunai langsung ke kurir`})
          ]})
        ]}),
        (0,M.jsxs)(`button`,{type:`button`,role:`radio`,"aria-checked":pmPayMethod===`wallet`,onClick:()=>pmSetPayMethod(`wallet`),className:l(`flex w-full items-center gap-3 rounded-2xl border-2 px-3.5 py-3 text-left transition-colors`,pmPayMethod===`wallet`?`border-primary bg-primary/5`:`border-border bg-background hover:bg-secondary/60`),children:[
          (0,M.jsx)(`span`,{className:l(`grid size-5 shrink-0 place-items-center rounded-full border-2`,pmPayMethod===`wallet`?`border-primary`:`border-muted-foreground/40`),children:pmPayMethod===`wallet`&&(0,M.jsx)(`span`,{className:`size-2.5 rounded-full bg-primary`})}),
          (0,M.jsxs)(`span`,{className:`min-w-0 flex-1`,children:[
            (0,M.jsxs)(`span`,{className:`flex flex-wrap items-center gap-2 text-sm font-bold`,children:[
              `💳 GoGoGo Pay`,
              (0,M.jsxs)(`span`,{className:`rounded-full bg-primary/10 px-2 py-0.5 text-[10.5px] font-extrabold text-primary`,children:[`Saldo `,A(pmWalletBal)]})
            ]}),
            (0,M.jsx)(`span`,{className:l(`mt-0.5 block text-xs`,pmWalletBal<Wt?`font-semibold text-destructive`:`text-muted-foreground`),children:pmWalletBal<Wt?`Saldo kurang ${A(Wt-pmWalletBal)} · Top up di menu Pay`:`Bayar instan tanpa uang pas`})
          ]})
        ]})
      ]}),
      pmPayMethod===`wallet`&&pmWalletBal<Wt&&(0,M.jsx)(r,{to:`/pay`,className:`mt-2 inline-block text-xs font-bold text-primary underline`,children:`+ Isi Saldo GoGoGo Pay Sekarang`})
    ]}),
    (0,M.jsxs)(`section`,{"aria-label":`Rincian pembayaran`,className:`relative mx-4 mt-3.5 overflow-hidden rounded-[22px] bg-card shadow-soft`,children:[
      (0,M.jsxs)(`div`,{className:`space-y-2.5 p-4 pb-3`,children:[
        (0,M.jsx)(`h3`,{className:`font-display text-base font-bold`,children:`Rincian pembayaran`}),
        (0,M.jsx)(gpRow,{label:`Subtotal (${totQty} item)`,value:A(i)}),
        J?(0,M.jsx)(`p`,{className:`text-xs text-muted-foreground`,children:`Memuat biaya…`}):Y?(0,M.jsx)(`p`,{role:`alert`,className:`text-sm text-destructive`,children:`Biaya layanan belum dapat dimuat.`}):Rt?.enabled&&!Z?(0,M.jsx)(gpRow,{label:`Biaya layanan`,value:A(X)}):null,
        Z?(0,M.jsx)(gpRow,{label:`Ongkir · Ambil sendiri`,value:`Gratis`,valueClassName:`text-success`}):Ft?(0,M.jsx)(`p`,{className:`text-xs text-muted-foreground`,children:`Menghitung jarak…`}):K==null?(0,M.jsx)(`p`,{className:`text-xs text-muted-foreground`,children:`Aktifkan lokasi untuk menghitung ongkir.`}):(0,M.jsx)(gpRow,{label:(0,M.jsxs)(`span`,{className:`inline-flex flex-wrap items-center gap-1.5`,children:[z.enabled?`Ongkir · ${z.tiers[B].label}`:`Ongkir`,(0,M.jsx)(`span`,{className:`rounded-full bg-secondary px-2 py-0.5 text-[11px] font-bold text-primary`,children:Pe(K)})]}),value:A(Q)}),
        Ut>0&&(0,M.jsxs)(`div`,{className:`flex items-center justify-between gap-3 text-[13.5px] font-bold text-success`,children:[
          (0,M.jsxs)(`span`,{className:`min-w-0`,children:[V?De(V):`Diskon`,V?` (${V.code})`:``]}),
          (0,M.jsxs)(`span`,{className:`shrink-0`,children:[`-`,A(Ut)]})
        ]}),
        (0,M.jsx)(gpRow,{label:`Metode bayar`,value:pmPayMethod===`wallet`?`💳 GoGoGo Pay`:`💵 Tunai (COD)`}),
        pmEstPts>0&&(0,M.jsxs)(`div`,{className:`flex items-center justify-between rounded-xl bg-amber-500/10 px-3 py-2 text-xs font-semibold text-amber-700 dark:text-amber-300`,children:[
          (0,M.jsx)(`span`,{children:`⭐ Estimasi Poin Rewards`}),
          (0,M.jsxs)(`span`,{children:[`+`,pmEstPts,` poin`]})
        ]})
      ]}),
      (0,M.jsxs)(`div`,{"aria-hidden":!0,className:`relative h-[18px]`,children:[
        (0,M.jsx)(`span`,{className:`absolute -left-[9px] top-0 size-[18px] rounded-full bg-background`}),
        (0,M.jsx)(`span`,{className:`absolute -right-[9px] top-0 size-[18px] rounded-full bg-background`}),
        (0,M.jsx)(`span`,{className:`absolute inset-x-4 top-2 border-t-2 border-dashed border-border`})
      ]}),
      (0,M.jsxs)(`div`,{className:`flex items-baseline justify-between gap-3 px-4 pb-4 pt-1`,children:[
        (0,M.jsx)(`span`,{className:`text-[15px] font-extrabold`,children:`Total bayar`}),
        (0,M.jsx)(`span`,{className:`font-display text-[21px] font-extrabold text-primary`,children:totalStr})
      ]})
    ]}),
    gWa.data?.enabled&&(0,M.jsx)(He,{open:ae,onOpenChange:y,children:(0,M.jsxs)(ge,{className:`max-w-sm`,children:[
      (0,M.jsxs)(ve,{children:[
        (0,M.jsx)(ce,{children:`Verifikasi WhatsApp pemesan`}),
        (0,M.jsx)(se,{children:`Pastikan nomor WhatsApp pemesan dapat dihubungi.`})
      ]}),
      (0,M.jsx)(Ae,{initialPhone:S,onVerified:e=>{C(e),y(!1)}})
    ]})}),
    (0,M.jsx)(gpDr,{open:addrSheet,onOpenChange:setAddrSheet,shouldScaleBackground:!1,children:(0,M.jsxs)(gpDrContent,{className:`mx-auto max-w-md rounded-t-[26px] bg-card`,children:[
      (0,M.jsxs)(gpDrHead,{className:`pb-2 text-left`,children:[
        (0,M.jsx)(gpDrTitle,{className:`font-display text-[17px] font-bold`,children:`Antar ke mana?`}),
        (0,M.jsx)(gpDrDesc,{className:`text-xs`,children:`Kelola alamat tersimpan di halaman Akun (maksimal 5 alamat).`})
      ]}),
      (0,M.jsxs)(`div`,{className:`max-h-[60vh] space-y-2 overflow-y-auto px-4 pb-6`,children:[
        (0,M.jsx)(Xe,{addresses:ct,selected:ut,onSelect:e=>{Jt(e),setEditPoint(!1),setAddrSheet(!1)},liveAddress:R.location?.address,liveReady:!!R.location,locating:F||R.status===`loading`,onUseGps:()=>void qt()}),
        (0,M.jsxs)(m,{type:`button`,variant:`outline`,className:`w-full rounded-xl`,onClick:()=>{setAddrSheet(!1),setEditPoint(!0)},children:[(0,M.jsx)(me,{}),` Pilih titik langsung di peta`]})
      ]})
    ]})}),
    (0,M.jsxs)(`div`,{className:`fixed inset-x-0 bottom-0 z-40 mx-auto max-w-md rounded-t-3xl border-t border-border bg-card px-4 pb-[calc(env(safe-area-inset-bottom)+0.875rem)] pt-2.5 shadow-[0_-8px_24px_-12px_rgba(9,45,132,0.22)]`,children:[
      needPick&&(0,M.jsx)(`p`,{className:`mb-2 text-center text-xs text-muted-foreground`,children:F||I.loading?`Mengambil lokasi… tunggu sampai lokasi siap.`:I.needsChoice?`Pilih antar ke lokasi saat ini atau alamat tersimpan dulu.`:I.needsVerify?`Pastikan titik di peta lalu tekan "Titik sudah benar".`:`Pilih titik pengantaran dulu supaya kurir tidak kesasar.`}),
      Bt&&(0,M.jsx)(`p`,{role:`alert`,className:`mb-2 rounded-lg bg-destructive/10 p-2 text-center text-xs font-semibold text-destructive`,children:Vt}),
      pmPayMethod===`wallet`&&pmWalletBal<Wt&&(0,M.jsxs)(`p`,{role:`alert`,className:`mb-2 rounded-lg bg-destructive/10 p-2 text-center text-xs font-semibold text-destructive`,children:[`Saldo GoGoGo Pay tidak cukup. `,(0,M.jsx)(r,{to:`/pay`,className:`underline`,children:`Top Up Sekarang`})]}),
      !needPick&&!Bt&&etaFooter&&(0,M.jsxs)(`p`,{className:`mb-2 flex items-center justify-center gap-1.5 text-xs font-bold text-primary`,children:[
        Z?(0,M.jsx)(g,{className:`size-3.5 shrink-0`}):(0,M.jsx)(gpIcoCourier,{className:`size-3.5 shrink-0`}),
        (0,M.jsx)(`span`,{className:`truncate`,children:etaFooter})
      ]}),
      (0,M.jsxs)(`div`,{className:`flex items-center gap-3.5`,children:[
        (0,M.jsxs)(`div`,{className:`min-w-0`,children:[
          (0,M.jsx)(`p`,{className:`text-xs font-semibold text-muted-foreground`,children:`Total bayar`}),
          (0,M.jsx)(`p`,{className:`whitespace-nowrap font-display text-xl font-extrabold`,children:totalStr}),
          Ut>0&&(0,M.jsxs)(`p`,{className:`text-[11px] font-extrabold text-success`,children:[`Hemat `,A(Ut)]})
        ]}),
        (0,M.jsx)(m,{variant:`hero`,size:`xl`,className:`flex-1 px-4 font-extrabold`,onClick:Yt,loading:ft||ht,disabled:J||Y||!Z&&(!lt||K==null||Bt)||pmPayMethod===`wallet`&&pmWalletBal<Wt,children:ht&&!ft?`Memeriksa pesanan…`:(0,M.jsxs)(M.Fragment,{children:[`Pesan Sekarang `,(0,M.jsx)(gpArrowR,{})]})})
      ]})
    ]})
  ]})
}

function gpPickupCard({restaurant:e,coords:t}){
  let{data:n}=gpUseRest(e.id),
  td=gpToday(),
  r=n?gpShopSt(n,td):null,
  i=r?r.accepting:!0,
  img=n?.logo_url??n?.image_url??e.imageUrl;
  return(0,M.jsxs)(`section`,{"aria-label":`Ambil di restoran`,className:`mx-4 mt-3 space-y-3 rounded-[22px] bg-card p-3.5 shadow-soft`,children:[
    (0,M.jsxs)(`div`,{className:`flex items-center gap-3`,children:[
      (0,M.jsx)(`div`,{className:`size-[52px] shrink-0 overflow-hidden rounded-2xl bg-muted`,children:img&&(0,M.jsx)(gpSafeImg,{src:img,optimize:{width:120},alt:e.name,width:52,height:52,className:`size-full object-cover`})}),
      (0,M.jsxs)(`div`,{className:`min-w-0 flex-1`,children:[
        (0,M.jsx)(`p`,{className:`text-[11px] font-extrabold uppercase tracking-[0.06em] text-muted-foreground`,children:`Ambil di`}),
        (0,M.jsx)(`p`,{className:`truncate font-display text-[15.5px] font-bold`,children:e.name}),
        (0,M.jsxs)(`p`,{className:`mt-0.5 flex items-center gap-1.5 text-xs text-muted-foreground`,children:[
          (0,M.jsx)(gpIcoClock,{className:`size-3 shrink-0`}),
          (0,M.jsx)(`span`,{className:l(`shrink-0 font-bold`,i?`text-primary`:`text-destructive`),children:i?`Buka`:r?.label??`Tutup`}),
          n?.opening_hours&&(0,M.jsxs)(`span`,{className:`truncate`,children:[`· `,n.opening_hours]})
        ]})
      ]})
    ]}),
    t&&(0,M.jsx)(m,{asChild:!0,variant:`outline`,className:`h-11 w-full rounded-[14px] border-[1.5px] font-extrabold text-primary`,children:(0,M.jsxs)(`a`,{href:st(t),target:`_blank`,rel:`noreferrer`,children:[(0,M.jsx)(Me,{}),` Petunjuk arah ke resto`]})}),
    (0,M.jsxs)(`div`,{className:`flex gap-2.5 rounded-[14px] bg-secondary p-3 text-primary`,children:[
      (0,M.jsx)(gpInfoIco,{className:`mt-0.5 size-4 shrink-0`}),
      (0,M.jsxs)(`p`,{className:`text-[12.5px] leading-relaxed text-foreground/80`,children:[`Datang setelah toko menandai pesanan `,(0,M.jsx)(`b`,{children:`Siap Diambil`}),`. Pantau statusnya di halaman Pesanan.`]})
    ]})
  ]})
}

function gpRow({label:e,value:t,valueClassName:n}){
  return(0,M.jsxs)(`div`,{className:`flex items-center justify-between gap-3 text-[13.5px]`,children:[
    (0,M.jsx)(`span`,{className:`min-w-0 text-muted-foreground`,children:e}),
    (0,M.jsx)(`span`,{className:l(`shrink-0 font-bold`,n),children:t})
  ]})
}

var ct=()=>(0,M.jsx)(i,{showNav:!1,children:(0,M.jsx)(h,{redirect:`/checkout`,description:`Masuk untuk menyelesaikan pesanan.`,children:(0,M.jsx)(I,{})})});
export{ct as component};