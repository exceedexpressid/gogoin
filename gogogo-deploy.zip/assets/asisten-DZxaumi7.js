import{a as e}from"./chunk-Cyuzqnbw.js";import{n as t,t as n}from"./jsx-runtime-dIob5GyK.js";import{t as Link}from"./link-BjDnxAYt.js";import{t as AppShell}from"./AppShell-27FoYrsa.js";import{n as supabase}from"./client-DVq7Iik5.js";
import{calcDistanceTariff,calcSuruhTariff,formatRp as fmtSrvRp,useServiceTariffs}from"./service-tariffs.js";

var React = e(t(), 1);
var jsx = n();

function formatRp(val) {
  return "Rp " + Number(val || 0).toLocaleString("id-ID");
}

const WELCOME_MSG = {
  role: "assistant",
  text: "Halo! Saya Asisten AI GoGoGo. Saya bisa cek saldo GoGoGo Pay & poin Rewards kamu, status pesanan aktif, kode voucher, menu Go Makan, sembako Go Mart, serta tarif Go Riding, Go Mobil, Go Cargo, Go Suruh & Go Express!"
};

function AsistenPage() {
  const { tariffs } = useServiceTariffs();
  const [user, setUser] = React.useState(null);
  const [messages, setMessages] = React.useState([WELCOME_MSG]);
  const [input, setInput] = React.useState("");
  const [loading, setLoading] = React.useState(false);

  React.useEffect(() => {
    let active = true;
    (async () => {
      try {
        const { data: s } = await supabase.auth.getSession();
        const u = s?.session?.user || null;
        if (!active) return;
        setUser(u);
        if (!u) return;

        const { data: hist } = await supabase
          .from("ai_chat_messages")
          .select("role, message, created_at")
          .eq("user_id", u.id)
          .order("created_at", { ascending: true })
          .limit(20);

        if (active && hist && hist.length > 0) {
          setMessages([
            WELCOME_MSG,
            ...hist.map((h) => ({ role: h.role === "user" ? "user" : "assistant", text: h.message }))
          ]);
        }
      } catch (err) {
        console.error(err);
      }
    })();
    return () => {
      active = false;
    };
  }, []);

  const persistMsg = async (uid, role, message) => {
    if (!uid) return;
    try {
      await supabase.from("ai_chat_messages").insert({ user_id: uid, role, message });
    } catch {}
  };

  const askAssistant = async (questionText) => {
    const q = String(questionText ?? input).trim();
    if (!q || loading) return;
    setInput("");
    setMessages((prev) => [...prev, { role: "user", text: q }]);
    setLoading(true);
    persistMsg(user?.id, "user", q);

    try {
      const lower = q.toLowerCase();
      const [
        { data: rests },
        { data: menus },
        { data: vouchers },
        profRes,
        ptsRes,
        ordRes
      ] = await Promise.all([
        supabase.from("restaurants").select("*").eq("is_active", true),
        supabase.from("menu_items").select("*").eq("is_available", true),
        supabase.from("vouchers").select("*").eq("is_active", true),
        user ? supabase.from("profiles").select("wallet_balance, full_name").eq("id", user.id).maybeSingle() : Promise.resolve({ data: null }),
        user ? supabase.from("user_points").select("points").eq("user_id", user.id).maybeSingle() : Promise.resolve({ data: null }),
        user
          ? supabase
              .from("orders")
              .select("order_number, status, total, fulfillment_type, restaurants(name)")
              .eq("customer_id", user.id)
              .order("created_at", { ascending: false })
              .limit(3)
          : Promise.resolve({ data: [] })
      ]);

      const activeRests = rests || [];
      const activeMenus = menus || [];
      const restMap = new Map(activeRests.map((r) => [r.id, r]));

      let reply = "";
      if (lower.includes("voucher") || lower.includes("promo") || lower.includes("diskon")) {
        const vList = (vouchers || [])
          .map((v) => `• ${v.code}: ${v.title || ""} (${v.description || ""})`)
          .join("\n");
        reply = `Berikut kode voucher promo aktif GoGoGo hari ini:\n${vList || "Belum ada voucher aktif saat ini."}\n\nLangsung pilih atau masukkan kodenya di halaman Checkout ya!`;
      } else if (lower.includes("saldo") || lower.includes("pay") || lower.includes("poin") || lower.includes("reward")) {
        if (!user) {
          reply = "Untuk mengecek saldo GoGoGo Pay dan poin GoGoGo Rewards, silakan masuk ke akun kamu terlebih dahulu lewat menu Profil atau tombol Masuk di Beranda.";
        } else {
          const bal = Number(profRes?.data?.wallet_balance ?? 0);
          const pts = Number(ptsRes?.data?.points ?? 0);
          reply = `Dompet & Loyalitas Akun Kamu:\n• Saldo GoGoGo Pay: ${formatRp(bal)}\n• Poin GoGoGo Rewards: ${pts.toLocaleString("id-ID")} poin\n\nSaldo bisa langsung dipakai untuk Go Makan, Go Mart, Go Express, Go Riding, Go Mobil, Go Cargo, & Go Suruh!`;
        }
      } else if (lower.includes("pesanan") || lower.includes("status") || lower.includes("lacak") || lower.includes("order")) {
        if (!user) {
          reply = "Silakan masuk ke akun kamu terlebih dahulu untuk melacak pesanan Go Makan, Go Mart, Go Riding, Go Mobil, Cargo, Suruh, atau paket Go Express.";
        } else {
          const recents = ordRes?.data || [];
          if (recents.length === 0) {
            reply = "Kamu belum memiliki riwayat pesanan. Yuk coba Go Makan, Go Mart, Go Riding, Go Mobil, Cargo, Suruh, atau Go Express!";
          } else {
            const lines = recents
              .map(
                (o) =>
                  `• #${o.order_number} (${o.restaurants?.name || o.fulfillment_type.toUpperCase()}): status "${o.status}" — ${formatRp(o.total)}`
              )
              .join("\n");
            reply = `Ini 3 pesanan terakhirmu:\n${lines}\n\nBuka tab Aktivitas (/orders) untuk melihat peta pergerakan mitra secara langsung.`;
          }
        }
      } else if (lower.includes("suruh") || lower.includes("jam") || lower.includes("menit") || lower.includes("bantu") || lower.includes("antre")) {
        const sc = tariffs.tiers.suruh_hourly;
        const mMatch = lower.match(/(\d+)\s*menit/);
        const hMatch = lower.match(/(\d+(?:[.,]\d+)?)\s*jam/);
        const mins = mMatch ? Number(mMatch[1]) : hMatch ? Math.round(Number(hMatch[1].replace(",", ".")) * 60) : 90;
        const effMins = Math.max(Number(sc.baseMinutes || 60), mins);
        reply = `Tarif Go Suruh:\n• Biaya 1 jam pertama (${sc.baseMinutes} menit): ${fmtSrvRp(sc.baseHourFee)}\n• Selanjutnya: ${fmtSrvRp(sc.perMinute)} / menit\n• Simulasi ${effMins} menit: ${fmtSrvRp(calcSuruhTariff(sc, effMins))} (+ biaya layanan ${fmtSrvRp(tariffs.appFee)})\n\nBuka menu Go Suruh untuk langsung memilih durasi & menulis tugas!`;
      } else if (lower.includes("riding") || lower.includes("motor") || lower.includes("mobil") || lower.includes("cargo") || lower.includes("angkutan") || lower.includes("express") || lower.includes("kirim") || lower.includes("paket") || lower.includes("tarif") || lower.includes("ongkir")) {
        const kmMatch = lower.match(/(\d+(?:[.,]\d+)?)\s*km/);
        const km = kmMatch ? Math.max(0.5, Number(kmMatch[1].replace(",", "."))) : 5;
        const ts = tariffs.tiers;
        reply = `Daftar Tarif Resmi GoGoGo (simulasi jarak ${km} km):\n• 🏍️ Go Riding Reg: ${fmtSrvRp(calcDistanceTariff(ts.ride_reg, km))} (dasar ${fmtSrvRp(ts.ride_reg.baseFee)} ≤ ${ts.ride_reg.baseMaxKm} km, +${fmtSrvRp(ts.ride_reg.perKm)}/km)\n• 🛵 Go Riding Comfort (PCX/NMAX): ${fmtSrvRp(calcDistanceTariff(ts.ride_comfort, km))} (dasar ${fmtSrvRp(ts.ride_comfort.baseFee)} ≤ ${ts.ride_comfort.baseMaxKm} km, +${fmtSrvRp(ts.ride_comfort.perKm)}/km)\n• 🚗 Go Mobil Reg (LCGC): ${fmtSrvRp(calcDistanceTariff(ts.mobil_reg, km))} (dasar ${fmtSrvRp(ts.mobil_reg.baseFee)} ≤ ${ts.mobil_reg.baseMaxKm} km, +${fmtSrvRp(ts.mobil_reg.perKm)}/km)\n• 🚐 Go Mobil XL (6 seat/bagasi+): ${fmtSrvRp(calcDistanceTariff(ts.mobil_xl, km))} (dasar ${fmtSrvRp(ts.mobil_xl.baseFee)} ≤ ${ts.mobil_xl.baseMaxKm} km)\n• 🚙 Go Mobil Premium (Pajero/Innova): ${fmtSrvRp(calcDistanceTariff(ts.mobil_premium, km))} (dasar ${fmtSrvRp(ts.mobil_premium.baseFee)} ≤ ${ts.mobil_premium.baseMaxKm} km)\n• 🚚 Go Cargo (Angkutan Barang): ${fmtSrvRp(calcDistanceTariff(ts.cargo_std, km))} (dasar ${fmtSrvRp(ts.cargo_std.baseFee)} ≤ ${ts.cargo_std.baseMaxKm} km, +${fmtSrvRp(ts.cargo_std.perKm)}/km)\n• 📦 Go Express: mulai ${fmtSrvRp(calcDistanceTariff(ts.express_base, km))}\n(+ biaya layanan ${fmtSrvRp(tariffs.appFee)})`;
      } else if (lower.includes("mart") || lower.includes("sembako") || lower.includes("belanja") || lower.includes("beras") || lower.includes("minyak") || lower.includes("kebutuhan")) {
        const martRestIds = new Set(activeRests.filter((r) => r.merchant_type === "mart").map((r) => r.id));
        const martItems = activeMenus
          .filter((m) => martRestIds.has(m.restaurant_id))
          .slice(0, 6)
          .map((m) => `• ${m.name} (${restMap.get(m.restaurant_id)?.name || "Toko"}) — ${formatRp(m.price)}`)
          .join("\n");
        const martNames = activeRests
          .filter((r) => r.merchant_type === "mart")
          .slice(0, 4)
          .map((r) => r.name)
          .join(", ");
        reply = `Toko aktif di Go Mart: ${martNames || "belum tersedia"}.\n\nProduk kebutuhan harian terlaris:\n${martItems || "Silakan buka menu Go Mart untuk melihat daftar toko dan produk."}`;
      } else if (lower.includes("mitra") || lower.includes("daftar") || lower.includes("gabung") || lower.includes("kurir")) {
        reply = "Mau bergabung jadi bagian dari GoGoGo?\n• Daftar Mitra Restoran / Toko Mart di halaman Mitra (/mitra)\n• Daftar Driver / Kurir di halaman Daftar Kurir (/kurir)\nPendaftaran akan ditinjau admin GoGoGo.";
      } else {
        const foodRestIds = new Set(activeRests.filter((r) => r.merchant_type !== "mart").map((r) => r.id));
        const words = lower.split(/\s+/).filter((w) => w.length >= 3 && !["cari", "makan", "makanan", "rekomendasi", "yang", "enak", "mau", "dong"].includes(w));
        const matched = activeMenus.filter((m) => {
          const rName = String(restMap.get(m.restaurant_id)?.name || "").toLowerCase();
          return words.some((w) => String(m.name || "").toLowerCase().includes(w) || rName.includes(w));
        });
        const picks = (matched.length > 0 ? matched : activeMenus.filter((m) => foodRestIds.has(m.restaurant_id)))
          .slice(0, 5)
          .map((m) => `• ${m.name} (${restMap.get(m.restaurant_id)?.name || "Restoran"}) — ${formatRp(m.price)}`)
          .join("\n");
        reply = matched.length > 0
          ? `Saya menemukan menu yang cocok untukmu:\n${picks}\n\nKetuk Cari atau Go Makan untuk langsung pesan ya!`
          : `Rekomendasi menu pilihan di Go Makan:\n${picks || "Belum ada menu aktif."}\n\nAda promo apa, cek tarif Go Riding/Mobil/Cargo/Suruh, atau cek saldo? Ketik pertanyaanmu saja!`;
      }

      setMessages((prev) => [...prev, { role: "assistant", text: reply }]);
      persistMsg(user?.id, "assistant", reply);
    } catch {
      setMessages((prev) => [
        ...prev,
        { role: "assistant", text: "Maaf, sedang ada kendala membaca data. Coba tanyakan lagi sebentar ya!" }
      ]);
    } finally {
      setLoading(false);
    }
  };

  const quickPrompts = [
    "Tarif Go Riding, Mobil & Cargo 6 km",
    "Biaya Go Suruh 90 menit",
    "Cek saldo & poin saya",
    "Cek status pesanan terakhir",
    "Ada voucher promo apa?",
    "Produk Go Mart terlaris"
  ];

  return (0, jsx.jsx)(AppShell, {
    showBack: true,
    children: (0, jsx.jsxs)("div", {
      className: "flex min-h-[calc(100vh-140px)] flex-col px-4 py-4",
      children: [
        (0, jsx.jsxs)("div", {
          className: "mb-3 flex items-center justify-between gap-2 rounded-2xl bg-gradient-to-r from-primary to-blue-600 p-4 text-primary-foreground shadow-soft",
          children: [
            (0, jsx.jsxs)("div", {
              children: [
                (0, jsx.jsx)("h1", { className: "font-display text-base font-extrabold", children: "✨ Asisten AI GoGoGo" }),
                (0, jsx.jsx)("p", { className: "text-xs text-primary-foreground/85", children: "Cek saldo, promo, tarif Express & rekomendasi real-time" })
              ]
            }),
            (0, jsx.jsx)(Link, {
              to: "/pay",
              className: "shrink-0 rounded-full bg-white/20 px-3 py-1.5 text-[11px] font-bold hover:bg-white/30",
              children: "GoGoGo Pay →"
            })
          ]
        }),

        (0, jsx.jsx)("div", {
          className: "mb-3 flex flex-wrap gap-1.5",
          children: quickPrompts.map((p) =>
            (0, jsx.jsx)(
              "button",
              {
                type: "button",
                onClick: () => askAssistant(p),
                className: "rounded-full border border-border bg-card px-3 py-1.5 text-xs font-semibold hover:border-primary/40 hover:bg-primary/5",
                children: p
              },
              p
            )
          )
        }),

        (0, jsx.jsx)("div", {
          className: "flex-1 space-y-3 overflow-y-auto pb-4",
          children: messages.map((msg, idx) =>
            (0, jsx.jsx)(
              "div",
              {
                className: `flex ${msg.role === "user" ? "justify-end" : "justify-start"}`,
                children: (0, jsx.jsx)("div", {
                  className: `max-w-[88%] whitespace-pre-line rounded-2xl px-4 py-3 text-sm leading-relaxed ${
                    msg.role === "user"
                      ? "bg-primary text-primary-foreground rounded-br-sm"
                      : "bg-card border border-border text-foreground shadow-soft rounded-bl-sm"
                  }`,
                  children: msg.text
                })
              },
              idx
            )
          )
        }),

        (0, jsx.jsxs)("div", {
          className: "flex gap-2 pt-2",
          children: [
            (0, jsx.jsx)("input", {
              type: "text",
              value: input,
              onChange: (ev) => setInput(ev.target.value),
              onKeyDown: (ev) => ev.key === "Enter" && askAssistant(input),
              placeholder: "Ketik pertanyaanmu di sini...",
              className: "flex-1 rounded-xl border border-border bg-background px-3 py-2.5 text-sm"
            }),
            (0, jsx.jsx)("button", {
              type: "button",
              disabled: loading,
              onClick: () => askAssistant(input),
              className: "rounded-xl bg-primary px-4 py-2.5 text-xs font-bold text-primary-foreground disabled:opacity-50",
              children: loading ? "..." : "Kirim"
            })
          ]
        })
      ]
    })
  });
}

export { AsistenPage as component };
