import{a as e}from"./chunk-Cyuzqnbw.js";import{n as t,t as n}from"./jsx-runtime-dIob5GyK.js";import{t as Link}from"./link-BjDnxAYt.js";import{$o as toast}from"./index-CWsrv0HS.js";import{t as SuperAppShell}from"./SuperAppShell-CEcI2waY.js";import{n as supabase}from"./client-DVq7Iik5.js";

var React = e(t(), 1);
var jsx = n();

function formatRp(val) {
  return "Rp " + Number(val || 0).toLocaleString("id-ID");
}

function PayPage() {
  const [user, setUser] = React.useState(null);
  const [authLoaded, setAuthLoaded] = React.useState(false);
  const [balance, setBalance] = React.useState(0);
  const [points, setPoints] = React.useState(0);
  const [txs, setTxs] = React.useState([]);
  const [txFilter, setTxFilter] = React.useState("all");
  const [merchants, setMerchants] = React.useState([]);

  const [activeTab, setActiveTab] = React.useState("topup");
  const [topupAmount, setTopupAmount] = React.useState("100000");
  const [topupMethod, setTopupMethod] = React.useState("QRIS Instan");
  const [transferRecipient, setTransferRecipient] = React.useState("");
  const [transferAmount, setTransferAmount] = React.useState("");
  const [transferNote, setTransferNote] = React.useState("");

  const [merchantQuery, setMerchantQuery] = React.useState("");
  const [selectedMerchantId, setSelectedMerchantId] = React.useState("");
  const [merchantAmount, setMerchantAmount] = React.useState("");
  const [merchantNote, setMerchantNote] = React.useState("");
  const [receipt, setReceipt] = React.useState(null);
  const [busy, setBusy] = React.useState(false);

  const loadWallet = React.useCallback(async () => {
    try {
      const { data: s } = await supabase.auth.getSession();
      const u = s?.session?.user || null;
      setUser(u);
      setAuthLoaded(true);

      const { data: rests } = await supabase
        .from("restaurants")
        .select("id, name, category, merchant_type")
        .eq("is_active", true)
        .order("name", { ascending: true });
      const activeRests = rests || [];
      setMerchants(activeRests);
      if (activeRests.length > 0 && !selectedMerchantId) {
        setSelectedMerchantId(activeRests[0].id);
      }

      if (!u) return;

      const [{ data: prof }, { data: pt }, { data: list }] = await Promise.all([
        supabase.from("profiles").select("wallet_balance").eq("id", u.id).maybeSingle(),
        supabase.from("user_points").select("points").eq("user_id", u.id).maybeSingle(),
        supabase
          .from("wallet_transactions")
          .select("*")
          .eq("user_id", u.id)
          .order("created_at", { ascending: false })
          .limit(50)
      ]);

      setBalance(Number(prof?.wallet_balance ?? 0));
      setPoints(Number(pt?.points ?? 0));
      setTxs(list || []);
    } catch (err) {
      console.error(err);
      setAuthLoaded(true);
    }
  }, [selectedMerchantId]);

  React.useEffect(() => {
    loadWallet();
  }, [loadWallet]);

  const handleTopup = async (amt) => {
    if (!user) return toast.error("Masuk ke akun terlebih dahulu.");
    const num = Number(amt || topupAmount || 0);
    if (!Number.isFinite(num) || num < 10000) {
      toast.error("Minimal Top-Up adalah Rp 10.000");
      return;
    }
    setBusy(true);
    try {
      const { data, error } = await supabase.rpc("wallet_topup", {
        _amount: Math.round(num),
        _method: topupMethod
      });
      if (error || data?.success === false) {
        toast.error(data?.message || error?.message || "Top-up gagal.");
        return;
      }
      setReceipt({ title: "Top-Up Berhasil", amount: num, detail: `Via ${topupMethod}` });
      toast.success(`Top-Up ${formatRp(num)} berhasil masuk!`);
      await loadWallet();
    } finally {
      setBusy(false);
    }
  };

  const handleTransfer = async () => {
    if (!user) return toast.error("Masuk ke akun terlebih dahulu.");
    const target = transferRecipient.trim();
    const num = Number(transferAmount || 0);
    if (!target) return toast.error("Masukkan no. HP atau email tujuan.");
    if (!Number.isFinite(num) || num < 1000) return toast.error("Minimal transfer Rp 1.000.");
    if (num > balance) return toast.error("Saldo GoGoGo Pay tidak cukup.");

    setBusy(true);
    try {
      const { data, error } = await supabase.rpc("wallet_transfer", {
        _recipient: target,
        _amount: Math.round(num),
        _note: transferNote.trim()
      });
      if (error || data?.success === false) {
        toast.error(data?.message || error?.message || "Transfer gagal.");
        return;
      }
      setReceipt({
        title: "Transfer Saldo Terkirim",
        amount: num,
        detail: `Ke ${data?.recipient_name || target}`
      });
      toast.success(`Transfer ${formatRp(num)} ke ${data?.recipient_name || target} berhasil!`);
      setTransferAmount("");
      setTransferRecipient("");
      setTransferNote("");
      await loadWallet();
    } finally {
      setBusy(false);
    }
  };

  const handlePayMerchant = async () => {
    if (!user) return toast.error("Masuk ke akun terlebih dahulu.");
    const num = Number(merchantAmount || 0);
    if (!selectedMerchantId) return toast.error("Pilih merchant tujuan.");
    if (!Number.isFinite(num) || num < 1000) return toast.error("Minimal bayar merchant Rp 1.000.");
    if (num > balance) return toast.error("Saldo GoGoGo Pay tidak cukup.");

    setBusy(true);
    try {
      const { data, error } = await supabase.rpc("wallet_pay_merchant", {
        _restaurant_id: selectedMerchantId,
        _amount: Math.round(num),
        _note: merchantNote.trim()
      });
      if (error || data?.success === false) {
        toast.error(data?.message || error?.message || "Pembayaran merchant gagal.");
        return;
      }
      const mName = data?.restaurant_name || merchants.find((m) => m.id === selectedMerchantId)?.name || "Merchant";
      setReceipt({
        title: "Pembayaran QR / Toko Berhasil",
        amount: num,
        detail: mName
      });
      toast.success(`Pembayaran ${formatRp(num)} ke ${mName} berhasil!`);
      setMerchantAmount("");
      setMerchantNote("");
      await loadWallet();
    } finally {
      setBusy(false);
    }
  };

  const filteredMerchants = merchants.filter((m) => {
    if (!merchantQuery.trim()) return true;
    const q = merchantQuery.toLowerCase();
    return String(m.name || "").toLowerCase().includes(q) || String(m.id || "").toLowerCase().includes(q);
  });

  const filteredTxs = txs.filter((tx) => {
    if (txFilter === "in") return Number(tx.amount) >= 0;
    if (txFilter === "out") return Number(tx.amount) < 0;
    return true;
  });

  return (0, jsx.jsx)(SuperAppShell, {
    title: "GoGoGo Pay",
    subtitle: "Dompet digital, transfer saldo & bayar merchant instan",
    accent: "bg-primary",
    children: (0, jsx.jsxs)("div", {
      className: "space-y-4 px-4 py-4 pb-24",
      children: [
        // Balance Card
        (0, jsx.jsxs)("div", {
          className: "rounded-3xl gradient-primary p-5 text-white shadow-float",
          children: [
            (0, jsx.jsxs)("div", {
              className: "flex items-center justify-between gap-2",
              children: [
                (0, jsx.jsx)("span", { className: "text-xs font-semibold text-white/85", children: "Saldo Aktif GoGoGo Pay" }),
                (0, jsx.jsxs)(Link, {
                  to: "/rewards",
                  className: "rounded-full bg-white/20 px-2.5 py-1 text-[11px] font-bold hover:bg-white/30",
                  children: ["⭐ ", points.toLocaleString("id-ID"), " Poin →"]
                })
              ]
            }),
            (0, jsx.jsx)("p", { className: "mt-1.5 font-display text-3xl font-extrabold", children: user ? formatRp(balance) : "Rp 0" }),
            (0, jsx.jsx)("p", { className: "mt-1 text-[11px] text-white/80", children: user ? "Siap untuk checkout Go Makan, Go Mart, Go Express, Go Riding, Go Mobil, Go Cargo, Go Suruh, transfer sesama & QR toko." : "Masuk untuk melihat saldo & melakukan transaksi digital." })
          ]
        }),

        authLoaded && !user && (0, jsx.jsxs)("div", {
          className: "flex items-center justify-between gap-3 rounded-2xl border border-primary/30 bg-primary/5 p-3.5",
          children: [
            (0, jsx.jsx)("p", { className: "text-xs font-semibold text-primary", children: "Silakan masuk untuk memakai GoGoGo Pay." }),
            (0, jsx.jsx)(Link, {
              to: "/auth",
              className: "shrink-0 rounded-xl bg-primary px-3 py-2 text-xs font-bold text-primary-foreground",
              children: "Masuk"
            })
          ]
        }),

        receipt && (0, jsx.jsxs)("div", {
          className: "flex items-center justify-between gap-3 rounded-2xl border border-emerald-500/40 bg-emerald-500/10 p-3.5",
          children: [
            (0, jsx.jsxs)("div", {
              children: [
                (0, jsx.jsxs)("p", { className: "text-xs font-extrabold text-emerald-700 dark:text-emerald-300", children: ["✅ ", receipt.title] }),
                (0, jsx.jsxs)("p", { className: "text-[11px] text-muted-foreground", children: [receipt.detail, " · ", formatRp(receipt.amount)] })
              ]
            }),
            (0, jsx.jsx)("button", {
              type: "button",
              onClick: () => setReceipt(null),
              className: "text-xs font-bold text-muted-foreground",
              children: "Tutup"
            })
          ]
        }),

        // Action Tabs
        (0, jsx.jsx)("div", {
          className: "grid grid-cols-4 gap-1 rounded-2xl bg-secondary p-1",
          children: [
            { id: "topup", label: "➕ Isi" },
            { id: "transfer", label: "📤 Kirim" },
            { id: "merchant", label: "📱 Bayar" },
            { id: "history", label: "🧾 Mutasi" }
          ].map((t) =>
            (0, jsx.jsx)(
              "button",
              {
                type: "button",
                onClick: () => setActiveTab(t.id),
                className: `rounded-xl py-2 text-[11px] font-bold transition-colors ${
                  activeTab === t.id ? "bg-card text-primary shadow-sm" : "text-muted-foreground"
                }`,
                children: t.label
              },
              t.id
            )
          )
        }),

        activeTab === "topup" && (0, jsx.jsxs)("section", {
          className: "space-y-3 rounded-2xl bg-card p-4 shadow-soft",
          children: [
            (0, jsx.jsx)("h3", { className: "text-sm font-bold", children: "Isi Saldo GoGoGo Pay" }),
            (0, jsx.jsx)("div", {
              className: "grid grid-cols-3 gap-2",
              children: [20000, 50000, 100000, 200000, 300000, 500000].map((v) =>
                (0, jsx.jsx)(
                  "button",
                  {
                    type: "button",
                    onClick: () => setTopupAmount(String(v)),
                    className: `rounded-xl border py-2 text-xs font-bold transition-colors ${
                      Number(topupAmount) === v ? "border-primary bg-primary/10 text-primary" : "border-border bg-background"
                    }`,
                    children: formatRp(v)
                  },
                  v
                )
              )
            }),
            (0, jsx.jsxs)("div", {
              className: "grid grid-cols-3 gap-1.5",
              children: ["QRIS Instan", "Virtual Account", "Mitra GoGoGo"].map((ch) =>
                (0, jsx.jsx)(
                  "button",
                  {
                    type: "button",
                    onClick: () => setTopupMethod(ch),
                    className: `rounded-xl border px-2 py-2 text-[11px] font-semibold ${
                      topupMethod === ch ? "border-primary bg-primary/10 text-primary" : "border-border bg-background text-muted-foreground"
                    }`,
                    children: ch
                  },
                  ch
                )
              )
            }),
            (0, jsx.jsx)("input", {
              type: "number",
              value: topupAmount,
              onChange: (ev) => setTopupAmount(ev.target.value),
              placeholder: "Nominal lainnya...",
              className: "w-full rounded-xl border border-border bg-background px-3 py-2.5 text-sm"
            }),
            (0, jsx.jsx)("button", {
              type: "button",
              disabled: busy || !user,
              onClick: () => handleTopup(),
              className: "w-full rounded-xl bg-primary py-3 text-xs font-extrabold text-primary-foreground disabled:opacity-50",
              children: busy ? "Memproses..." : `Top-Up Sekarang (${formatRp(topupAmount || 0)})`
            })
          ]
        }),

        activeTab === "transfer" && (0, jsx.jsxs)("section", {
          className: "space-y-3 rounded-2xl bg-card p-4 shadow-soft",
          children: [
            (0, jsx.jsx)("h3", { className: "text-sm font-bold", children: "Transfer ke Sesama Pengguna GoGoGo" }),
            (0, jsx.jsx)("input", {
              type: "text",
              value: transferRecipient,
              onChange: (ev) => setTransferRecipient(ev.target.value),
              placeholder: "No. WhatsApp (628...) atau Email penerima",
              className: "w-full rounded-xl border border-border bg-background px-3 py-2.5 text-sm"
            }),
            (0, jsx.jsx)("input", {
              type: "number",
              value: transferAmount,
              onChange: (ev) => setTransferAmount(ev.target.value),
              placeholder: "Nominal transfer (Rp)",
              className: "w-full rounded-xl border border-border bg-background px-3 py-2.5 text-sm"
            }),
            (0, jsx.jsx)("input", {
              type: "text",
              value: transferNote,
              onChange: (ev) => setTransferNote(ev.target.value),
              placeholder: "Catatan transfer (opsional)",
              className: "w-full rounded-xl border border-border bg-background px-3 py-2 text-xs"
            }),
            (0, jsx.jsx)("button", {
              type: "button",
              disabled: busy || !user,
              onClick: handleTransfer,
              className: "w-full rounded-xl bg-primary py-3 text-xs font-extrabold text-primary-foreground disabled:opacity-50",
              children: busy ? "Mengirim Saldo..." : "Kirim Saldo Instan"
            })
          ]
        }),

        activeTab === "merchant" && (0, jsx.jsxs)("section", {
          className: "space-y-3 rounded-2xl bg-card p-4 shadow-soft",
          children: [
            (0, jsx.jsx)("h3", { className: "text-sm font-bold", children: "Bayar Langsung ke Merchant / Kasir Toko" }),
            (0, jsx.jsx)("input", {
              type: "text",
              value: merchantQuery,
              onChange: (ev) => setMerchantQuery(ev.target.value),
              placeholder: "Cari nama restoran atau toko Mart...",
              className: "w-full rounded-xl border border-border bg-background px-3 py-2 text-xs"
            }),
            (0, jsx.jsx)("select", {
              value: selectedMerchantId,
              onChange: (ev) => setSelectedMerchantId(ev.target.value),
              className: "w-full rounded-xl border border-border bg-background px-3 py-2.5 text-sm",
              children: filteredMerchants.map((m) =>
                (0, jsx.jsx)(
                  "option",
                  {
                    value: m.id,
                    children: `${m.merchant_type === "mart" ? "🛒 " : "🍽️ "}${m.name}`
                  },
                  m.id
                )
              )
            }),
            (0, jsx.jsx)("input", {
              type: "number",
              value: merchantAmount,
              onChange: (ev) => setMerchantAmount(ev.target.value),
              placeholder: "Nominal pembayaran di kasir (Rp)",
              className: "w-full rounded-xl border border-border bg-background px-3 py-2.5 text-sm"
            }),
            (0, jsx.jsx)("input", {
              type: "text",
              value: merchantNote,
              onChange: (ev) => setMerchantNote(ev.target.value),
              placeholder: "Catatan (misal: Bayar di meja / kasir)",
              className: "w-full rounded-xl border border-border bg-background px-3 py-2 text-xs"
            }),
            (0, jsx.jsx)("button", {
              type: "button",
              disabled: busy || !user || !selectedMerchantId,
              onClick: handlePayMerchant,
              className: "w-full rounded-xl bg-sky-600 py-3 text-xs font-extrabold text-white disabled:opacity-50",
              children: busy ? "Memproses..." : "Bayar Merchant Pakai GoGoGo Pay"
            })
          ]
        }),

        activeTab === "history" && (0, jsx.jsxs)("section", {
          className: "space-y-3 rounded-2xl bg-card p-4 shadow-soft",
          children: [
            (0, jsx.jsxs)("div", {
              className: "flex items-center justify-between gap-2",
              children: [
                (0, jsx.jsx)("h3", { className: "text-sm font-bold", children: "Mutasi GoGoGo Pay" }),
                (0, jsx.jsx)("div", {
                  className: "flex gap-1",
                  children: [
                    { id: "all", label: "Semua" },
                    { id: "in", label: "Masuk" },
                    { id: "out", label: "Keluar" }
                  ].map((f) =>
                    (0, jsx.jsx)(
                      "button",
                      {
                        type: "button",
                        onClick: () => setTxFilter(f.id),
                        className: `rounded-full px-2.5 py-1 text-[10px] font-bold ${
                          txFilter === f.id ? "bg-primary text-primary-foreground" : "bg-secondary text-muted-foreground"
                        }`,
                        children: f.label
                      },
                      f.id
                    )
                  )
                })
              ]
            }),
            filteredTxs.length === 0
              ? (0, jsx.jsx)("p", { className: "py-6 text-center text-xs text-muted-foreground", children: "Belum ada transaksi sesuai filter ini." })
              : (0, jsx.jsx)("div", {
                  className: "divide-y divide-border",
                  children: filteredTxs.map((tx) =>
                    (0, jsx.jsxs)(
                      "div",
                      {
                        className: "flex items-center justify-between py-2.5 gap-2",
                        children: [
                          (0, jsx.jsxs)("div", {
                            className: "min-w-0",
                            children: [
                              (0, jsx.jsx)("p", { className: "truncate text-xs font-semibold", children: tx.description }),
                              (0, jsx.jsx)("p", {
                                className: "text-[11px] text-muted-foreground",
                                children: new Date(tx.created_at).toLocaleString("id-ID")
                              })
                            ]
                          }),
                          (0, jsx.jsx)("span", {
                            className: `shrink-0 text-xs font-bold ${Number(tx.amount) >= 0 ? "text-emerald-600" : "text-rose-600"}`,
                            children: (Number(tx.amount) >= 0 ? "+ " : "- ") + formatRp(Math.abs(Number(tx.amount)))
                          })
                        ]
                      },
                      tx.id
                    )
                  )
                })
          ]
        })
      ]
    })
  });
}

export { PayPage as component };
