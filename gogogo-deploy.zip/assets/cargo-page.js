export { goCargoComponent as component } from "./go-transport-pages.js";
