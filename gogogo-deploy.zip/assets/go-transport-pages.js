import { a as e } from "./chunk-Cyuzqnbw.js";
import { n as t, t as n } from "./jsx-runtime-dIob5GyK.js";
import { t as Link } from "./link-BjDnxAYt.js";
import { $o as toast, ds as useNavigate, gpPt } from "./index-CWsrv0HS.js";
import { t as SuperAppShell } from "./SuperAppShell-CEcI2waY.js";
import { t as LocationPicker } from "./LocationPicker-wtR_rEKX.js";
import { t as OrderMiniMap } from "./OrderMiniMap-CiWQhAKt.js";
import { n as supabase } from "./client-DVq7Iik5.js";
import {
  calcDistanceTariff,
  calcSuruhTariff,
  formatRp,
  useServiceTariffs
} from "./service-tariffs.js";

var React = e(t(), 1);
var jsx = n();

const ABEPURA_CENTER = { lat: -2.6068, lng: 140.6692 };

const STATUS_LABEL = {
  searching_driver: "Mencari Mitra / Driver",
  accepted: "Driver Ditemukan",
  driver_assigned: "Menuju Titik Jemput",
  driver_arrived: "Tiba di Lokasi",
  picked_up: "Berangkat / Diproses",
  on_delivery: "Dalam Perjalanan",
  delivering: "Dalam Perjalanan",
  completed: "Selesai",
  cancelled: "Dibatalkan"
};

function calcHaversineKm(a, b) {
  if (!a || !b) return null;
  const R = 6371;
  const dLat = ((b.lat - a.lat) * Math.PI) / 180;
  const dLng = ((b.lng - a.lng) * Math.PI) / 180;
  const sinLat = Math.sin(dLat / 2);
  const sinLng = Math.sin(dLng / 2);
  const h =
    sinLat * sinLat +
    Math.cos((a.lat * Math.PI) / 180) *
      Math.cos((b.lat * Math.PI) / 180) *
      sinLng *
      sinLng;
  return R * (2 * Math.atan2(Math.sqrt(h), Math.sqrt(1 - h)));
}

function useServiceBookingData(fulfillmentType, tab) {
  const [user, setUser] = React.useState(null);
  const [authLoaded, setAuthLoaded] = React.useState(false);
  const [walletBalance, setWalletBalance] = React.useState(0);
  const [profile, setProfile] = React.useState(null);
  const [orders, setOrders] = React.useState([]);
  const [driverLocs, setDriverLocs] = React.useState({});

  const reload = React.useCallback(async () => {
    try {
      const { data: s } = await supabase.auth.getSession();
      const u = s?.session?.user || null;
      setUser(u);
      setAuthLoaded(true);
      if (!u) return;

      const [{ data: prof }, { data: list }] = await Promise.all([
        supabase.from("profiles").select("*").eq("id", u.id).maybeSingle(),
        supabase
          .from("orders")
          .select("*, order_items(*)")
          .eq("customer_id", u.id)
          .eq("fulfillment_type", fulfillmentType)
          .order("created_at", { ascending: false })
          .limit(30)
      ]);

      if (prof) {
        setProfile(prof);
        setWalletBalance(Number(prof.wallet_balance || 0));
      }
      const rows = list || [];
      setOrders(rows);
      const activeIds = rows
        .filter((o) => !["completed", "cancelled"].includes(o.status))
        .map((o) => o.id);
      if (activeIds.length > 0) {
        const { data: locs } = await supabase
          .from("courier_locations")
          .select("order_id, latitude, longitude")
          .in("order_id", activeIds);
        const mapLoc = {};
        for (const l of locs || []) {
          mapLoc[l.order_id] = { lat: Number(l.latitude), lng: Number(l.longitude) };
        }
        setDriverLocs(mapLoc);
      }
    } catch {
      setAuthLoaded(true);
    }
  }, [fulfillmentType]);

  React.useEffect(() => {
    reload();
  }, [reload]);

  React.useEffect(() => {
    if (tab !== "history" || !user) return;
    const tmr = setInterval(reload, 5000);
    return () => clearInterval(tmr);
  }, [tab, user, reload]);

  return { user, authLoaded, walletBalance, setWalletBalance, profile, orders, driverLocs, reload };
}

function useRoadDistance(pickupPoint, dropoffPoint) {
  const [distanceKm, setDistanceKm] = React.useState(3);
  const [manualDistance, setManualDistance] = React.useState(false);

  const pLat = pickupPoint?.lat ?? null;
  const pLng = pickupPoint?.lng ?? null;
  const dLat = dropoffPoint?.lat ?? null;
  const dLng = dropoffPoint?.lng ?? null;

  React.useEffect(() => {
    if (pLat == null || pLng == null || dLat == null || dLng == null) return;
    let active = true;
    const p = { lat: pLat, lng: pLng };
    const d = { lat: dLat, lng: dLng };
    const straightKm = calcHaversineKm(p, d);
    if (straightKm != null) {
      setDistanceKm(Math.max(0.5, Number((straightKm * 1.25).toFixed(1))));
      setManualDistance(false);
    }
    const coords = `${p.lng},${p.lat};${d.lng},${d.lat}?overview=false`;
    (async () => {
      for (const base of [
        "https://router.project-osrm.org/route/v1/driving",
        "https://routing.openstreetmap.de/routed-car/route/v1/driving"
      ]) {
        try {
          const res = await fetch(`${base}/${coords}`);
          if (!res.ok) continue;
          const json = await res.json();
          const dist = Number(json?.routes?.[0]?.distance);
          if (active && Number.isFinite(dist) && dist > 0) {
            setDistanceKm(Math.max(0.5, Number((dist / 1000).toFixed(1))));
            setManualDistance(false);
            break;
          }
        } catch {}
      }
    })();
    return () => {
      active = false;
    };
  }, [pLat, pLng, dLat, dLng]);

  return { distanceKm, setDistanceKm, manualDistance, setManualDistance };
}

function AuthBanner({ authLoaded, user, label }) {
  if (!authLoaded || user) return null;
  return (0, jsx.jsxs)("div", {
    className: "flex items-center justify-between gap-3 rounded-2xl border border-primary/30 bg-primary/5 p-3.5",
    children: [
      (0, jsx.jsxs)("div", {
        className: "min-w-0",
        children: [
          (0, jsx.jsx)("p", { className: "text-xs font-bold text-primary", children: label }),
          (0, jsx.jsx)("p", { className: "text-[11px] text-muted-foreground", children: "Alamat tersimpan & saldo GoGoGo Pay langsung sinkron." })
        ]
      }),
      (0, jsx.jsx)(Link, {
        to: "/auth",
        className: "shrink-0 rounded-xl bg-primary px-3 py-2 text-xs font-bold text-primary-foreground",
        children: "Masuk"
      })
    ]
  });
}

function PaymentSelector({ payMethod, setPayMethod, walletBalance, grandTotal }) {
  return (0, jsx.jsxs)("section", {
    className: "space-y-2 rounded-2xl bg-card p-4 shadow-soft",
    children: [
      (0, jsx.jsx)("h3", { className: "text-sm font-bold", children: "Metode Pembayaran" }),
      (0, jsx.jsxs)("div", {
        className: "grid grid-cols-2 gap-2",
        children: [
          (0, jsx.jsxs)("button", {
            type: "button",
            onClick: () => setPayMethod("cash"),
            className: `rounded-xl border p-2.5 text-left transition-colors ${
              payMethod === "cash" ? "border-primary bg-primary/10" : "border-border bg-background"
            }`,
            children: [
              (0, jsx.jsx)("p", { className: "text-xs font-bold", children: "💵 Tunai (COD)" }),
              (0, jsx.jsx)("p", { className: "text-[11px] text-muted-foreground", children: "Bayar langsung ke mitra" })
            ]
          }),
          (0, jsx.jsxs)("button", {
            type: "button",
            onClick: () => setPayMethod("wallet"),
            className: `rounded-xl border p-2.5 text-left transition-colors ${
              payMethod === "wallet" ? "border-primary bg-primary/10" : "border-border bg-background"
            }`,
            children: [
              (0, jsx.jsx)("p", { className: "text-xs font-bold", children: "💳 GoGoGo Pay" }),
              (0, jsx.jsxs)("p", {
                className: `text-[11px] ${walletBalance < grandTotal ? "font-semibold text-destructive" : "text-muted-foreground"}`,
                children: ["Saldo: ", formatRp(walletBalance)]
              })
            ]
          })
        ]
      }),
      payMethod === "wallet" &&
        walletBalance < grandTotal &&
        (0, jsx.jsx)(Link, {
          to: "/pay",
          className: "inline-block text-xs font-bold text-primary underline",
          children: "+ Isi Saldo GoGoGo Pay dulu →"
        })
    ]
  });
}

function BookingSuccessView({ title, emoji, createdOrder, onReset, onStopTimer, redirectSec, navigate, againLabel }) {
  return (0, jsx.jsx)(SuperAppShell, {
    title,
    subtitle: `#${createdOrder.order_number} · Mencari mitra terdekat`,
    back: true,
    children: (0, jsx.jsx)("div", {
      className: "space-y-4 px-4 py-6 pb-20",
      children: (0, jsx.jsxs)("div", {
        className: "rounded-3xl border border-primary/25 bg-card p-6 text-center shadow-card",
        children: [
          (0, jsx.jsx)("div", {
            className: "mx-auto grid size-16 place-items-center rounded-full bg-primary/10 text-3xl",
            children: emoji
          }),
          (0, jsx.jsxs)("h2", {
            className: "mt-3 font-display text-xl font-extrabold text-foreground",
            children: ["Pesanan #", createdOrder.order_number, " Dibuat!"]
          }),
          (0, jsx.jsxs)("p", {
            className: "mt-1 text-xs text-muted-foreground",
            children: [
              createdOrder.label,
              " · Total ",
              formatRp(createdOrder.total),
              " (",
              createdOrder.payment_method === "wallet" ? "Lunas GoGoGo Pay" : "Tunai COD",
              ")"
            ]
          }),
          (0, jsx.jsxs)("div", {
            className: "mt-4 space-y-1 rounded-2xl bg-secondary/70 p-3 text-left text-xs",
            children: [
              (0, jsx.jsxs)("p", { children: ["📍 ", (0, jsx.jsx)("span", { className: "font-semibold", children: createdOrder.pickup })] }),
              createdOrder.dropoff &&
                (0, jsx.jsxs)("p", { children: ["🏁 ", (0, jsx.jsx)("span", { className: "font-semibold", children: createdOrder.dropoff })] })
            ]
          }),
          createdOrder.pickupPoint &&
            (0, jsx.jsx)(OrderMiniMap, {
              className: "mt-4 h-44",
              restaurant: createdOrder.pickupPoint,
              customer: createdOrder.dropoffPoint || null,
              pickupLabel: "Lokasi Jemput",
              customerLabel: "Tujuan"
            }),
          redirectSec != null &&
            (0, jsx.jsxs)("p", {
              className: "mt-3 text-xs font-semibold text-primary",
              children: ["Membuka pelacakan perjalanan dalam ", redirectSec, " detik…"]
            }),
          (0, jsx.jsxs)("div", {
            className: "mt-4 space-y-2",
            children: [
              (0, jsx.jsx)("button", {
                type: "button",
                onClick: () => {
                  onStopTimer();
                  navigate({ to: "/orders" });
                },
                className: "w-full rounded-xl bg-primary py-3 text-xs font-extrabold text-primary-foreground shadow-md",
                children: "🗺️ Lacak Mitra Sekarang"
              }),
              (0, jsx.jsxs)("div", {
                className: "grid grid-cols-2 gap-2",
                children: [
                  (0, jsx.jsx)("button", {
                    type: "button",
                    onClick: () => {
                      onStopTimer();
                      navigate({ to: "/" });
                    },
                    className: "rounded-xl border border-border bg-background py-2.5 text-xs font-bold",
                    children: "🏠 Kembali ke Beranda"
                  }),
                  (0, jsx.jsx)("button", {
                    type: "button",
                    onClick: onReset,
                    className: "rounded-xl border border-border bg-background py-2.5 text-xs font-bold",
                    children: againLabel
                  })
                ]
              })
            ]
          })
        ]
      })
    })
  });
}

function ServiceHistoryList({ orders, driverLocs, emptyTitle, emptyDesc, onCreateNew, ctaLabel }) {
  if (!orders.length) {
    return (0, jsx.jsxs)("div", {
      className: "rounded-2xl bg-card p-6 text-center shadow-soft",
      children: [
        (0, jsx.jsx)("p", { className: "text-sm font-bold", children: emptyTitle }),
        (0, jsx.jsx)("p", { className: "mt-1 text-xs text-muted-foreground", children: emptyDesc }),
        (0, jsx.jsx)("button", {
          type: "button",
          onClick: onCreateNew,
          className: "mt-3 rounded-xl bg-primary px-4 py-2 text-xs font-bold text-primary-foreground",
          children: ctaLabel
        })
      ]
    });
  }
  return (0, jsx.jsx)("div", {
    className: "space-y-3",
    children: orders.map((sh) => {
      const hasPts = sh.pickup_latitude != null && sh.pickup_longitude != null;
      return (0, jsx.jsxs)(
        "div",
        {
          className: "space-y-2.5 rounded-2xl bg-card p-4 shadow-soft",
          children: [
            (0, jsx.jsxs)("div", {
              className: "flex items-center justify-between gap-2",
              children: [
                (0, jsx.jsxs)("span", {
                  className: "font-mono text-xs font-bold text-foreground",
                  children: ["#", sh.order_number, " · ", sh.delivery_tier_label || "Standar"]
                }),
                (0, jsx.jsx)("span", {
                  className: "rounded-full bg-primary/10 px-2.5 py-0.5 text-[11px] font-bold text-primary",
                  children: STATUS_LABEL[sh.status] || sh.status
                })
              ]
            }),
            (0, jsx.jsxs)("div", {
              className: "space-y-1 text-xs text-muted-foreground",
              children: [
                (0, jsx.jsxs)("p", { children: ["📍 ", (0, jsx.jsx)("span", { className: "font-semibold text-foreground", children: sh.pickup_address || "Lokasi Jemput" })] }),
                sh.customer_address &&
                  (0, jsx.jsxs)("p", { children: ["🏁 ", (0, jsx.jsx)("span", { className: "font-semibold text-foreground", children: sh.customer_address })] })
              ]
            }),
            hasPts &&
              (0, jsx.jsx)(OrderMiniMap, {
                className: "h-36",
                restaurant: { lat: Number(sh.pickup_latitude), lng: Number(sh.pickup_longitude) },
                customer: sh.latitude != null && sh.longitude != null ? { lat: Number(sh.latitude), lng: Number(sh.longitude) } : null,
                driver: driverLocs[sh.id] || null,
                pickupLabel: "Titik Jemput",
                customerLabel: "Tujuan"
              }),
            (0, jsx.jsxs)("div", {
              className: "flex items-center justify-between border-t border-border pt-2 text-xs",
              children: [
                (0, jsx.jsxs)("span", {
                  className: "font-extrabold text-primary",
                  children: [formatRp(sh.total), " · ", sh.payment_method === "wallet" ? "💳 GoGoGo Pay" : "💵 COD"]
                }),
                (0, jsx.jsx)(Link, {
                  to: "/orders",
                  className: "font-bold text-primary underline",
                  children: "Buka Peta Live →"
                })
              ]
            })
          ]
        },
        sh.id
      );
    })
  });
}

function DistanceServiceBooking({
  fulfillmentType,
  orderPrefix,
  pageTitle,
  pageSubtitle,
  heroEyebrow,
  heroTitle,
  heroDesc,
  heroEmoji,
  variantKeys,
  defaultVariant,
  pickupSectionTitle,
  pickupPlaceholder,
  dropoffSectionTitle,
  dropoffPlaceholder,
  variantSectionTitle,
  ctaVerb,
  extraControlsRender,
  buildExtraSummary
}) {
  const navigate = useNavigate();
  const { tariffs } = useServiceTariffs();
  const [tab, setTab] = React.useState("book");
  const { user, authLoaded, walletBalance, setWalletBalance, profile, orders, driverLocs, reload } =
    useServiceBookingData(fulfillmentType, tab);

  const initLp = gpPt();
  const [pickupAddress, setPickupAddress] = React.useState(() => initLp?.address || "");
  const [pickupPoint, setPickupPoint] = React.useState(() =>
    initLp ? { lat: initLp.latitude, lng: initLp.longitude } : null
  );
  const [showPickupMap, setShowPickupMap] = React.useState(false);

  const [dropoffAddress, setDropoffAddress] = React.useState("");
  const [dropoffPoint, setDropoffPoint] = React.useState(null);
  const [showDropoffMap, setShowDropoffMap] = React.useState(false);

  const [contactName, setContactName] = React.useState("");
  const [contactPhone, setContactPhone] = React.useState("");
  const [tierKey, setTierKey] = React.useState(defaultVariant);
  const [notes, setNotes] = React.useState("");
  const [payMethod, setPayMethod] = React.useState("cash");
  const [submitting, setSubmitting] = React.useState(false);
  const [createdOrder, setCreatedOrder] = React.useState(null);
  const [redirectSec, setRedirectSec] = React.useState(null);

  const { distanceKm, setDistanceKm, manualDistance, setManualDistance } = useRoadDistance(
    pickupPoint,
    dropoffPoint
  );

  React.useEffect(() => {
    if (!profile) return;
    setContactName((v) => v || profile.full_name || "");
    setContactPhone((v) => v || profile.phone || "");
    setPickupAddress((v) => v || profile.address || "");
    if (profile.latitude != null && profile.longitude != null) {
      setPickupPoint((v) => v || { lat: Number(profile.latitude), lng: Number(profile.longitude) });
    }
  }, [profile]);

  React.useEffect(() => {
    if (redirectSec == null) return;
    if (redirectSec <= 0) {
      navigate({ to: "/orders" });
      return;
    }
    const tmr = setTimeout(() => setRedirectSec((s) => (s == null ? null : s - 1)), 1000);
    return () => clearTimeout(tmr);
  }, [redirectSec, navigate]);

  const variants = variantKeys
    .map((k) => tariffs.tiers[k])
    .filter((v) => v && v.enabled !== false);
  const activeTier = variants.find((v) => v.key === tierKey) || variants[0] || tariffs.tiers[defaultVariant];
  const serviceFare = calcDistanceTariff(activeTier, distanceKm);
  const appFee = Number(tariffs.appFee ?? 2000);
  const grandTotal = serviceFare + appFee;

  const handleSubmit = async () => {
    if (!user) {
      toast.error(`Silakan masuk terlebih dahulu untuk memesan ${pageTitle}.`);
      navigate({ to: "/auth" });
      return;
    }
    if (!pickupAddress.trim() || !dropoffAddress.trim()) {
      toast.error("Isi titik jemput dan alamat tujuan terlebih dahulu.");
      return;
    }
    if (payMethod === "wallet" && walletBalance < grandTotal) {
      toast.error("Saldo GoGoGo Pay tidak mencukupi. Top up dulu di menu GoGoGo Pay.");
      return;
    }

    setSubmitting(true);
    try {
      const orderNum = orderPrefix + "-" + Date.now().toString().slice(-6);
      const pLat = pickupPoint?.lat ?? ABEPURA_CENTER.lat;
      const pLng = pickupPoint?.lng ?? ABEPURA_CENTER.lng;
      const dLat = dropoffPoint?.lat ?? pLat + 0.009;
      const dLng = dropoffPoint?.lng ?? pLng + 0.009;
      const extraInfo = buildExtraSummary ? buildExtraSummary() : "";
      const summary = `${activeTier.label} · ${Number(distanceKm).toFixed(1)} km${extraInfo ? " · " + extraInfo : ""}`;
      const combinedNotes = [
        `Layanan: ${activeTier.label}`,
        extraInfo,
        notes.trim() ? `Catatan: ${notes.trim()}` : ""
      ]
        .filter(Boolean)
        .join(" | ");

      const { data: ord, error: ordErr } = await supabase
        .from("orders")
        .insert({
          order_number: orderNum,
          customer_id: user.id,
          restaurant_id: null,
          customer_name: (contactName || profile?.full_name || "Pelanggan GoGoGo").trim(),
          customer_phone: (contactPhone || profile?.phone || "-").trim(),
          customer_address: dropoffAddress.trim(),
          pickup_address: pickupAddress.trim(),
          pickup_latitude: pLat,
          pickup_longitude: pLng,
          latitude: dLat,
          longitude: dLng,
          status: "searching_driver",
          fulfillment_type: fulfillmentType,
          payment_method: payMethod,
          payment_status: payMethod === "wallet" ? "paid" : "unpaid",
          delivery_tier: activeTier.key,
          delivery_tier_label: activeTier.label,
          subtotal: 0,
          admin_fee: 0,
          app_fee: appFee,
          delivery_fee: serviceFare,
          discount: 0,
          total: grandTotal,
          notes: combinedNotes || null
        })
        .select()
        .single();

      if (ordErr) throw ordErr;

      if (payMethod === "wallet") {
        const { data: wp, error: we } = await supabase.rpc("wallet_pay_order", {
          _order_id: ord.id,
          _amount: grandTotal,
          _description: `${activeTier.label} #${orderNum}`
        });
        if (we || wp?.success === false) {
          await supabase.from("orders").delete().eq("id", ord.id);
          throw new Error(wp?.message || we?.message || "Pembayaran GoGoGo Pay gagal.");
        }
        setWalletBalance(Number(wp?.wallet_balance ?? walletBalance - grandTotal));
      }

      const { error: itemErr } = await supabase.from("order_items").insert({
        order_id: ord.id,
        menu_item_id: null,
        menu_name: summary,
        quantity: 1,
        price: serviceFare,
        subtotal: serviceFare,
        restaurant_price: serviceFare,
        markup_amount: 0,
        notes: notes.trim() || null
      });
      if (itemErr) throw itemErr;

      toast.success(`Pesanan ${activeTier.label} berhasil! Mencari driver terdekat.`);
      setCreatedOrder({
        id: ord.id,
        order_number: orderNum,
        total: grandTotal,
        pickup: pickupAddress.trim(),
        dropoff: dropoffAddress.trim(),
        pickupPoint: { lat: pLat, lng: pLng },
        dropoffPoint: { lat: dLat, lng: dLng },
        payment_method: payMethod,
        label: activeTier.label
      });
      setRedirectSec(3);
      if (typeof window !== "undefined") window.scrollTo({ top: 0, behavior: "smooth" });
      await reload();
    } catch (err) {
      toast.error(err?.message || `Gagal membuat pesanan ${pageTitle}.`);
    } finally {
      setSubmitting(false);
    }
  };

  if (createdOrder) {
    return (0, jsx.jsx)(BookingSuccessView, {
      title: `${pageTitle} Dibuat`,
      emoji: heroEmoji,
      createdOrder,
      redirectSec,
      navigate,
      onStopTimer: () => setRedirectSec(null),
      onReset: () => {
        setRedirectSec(null);
        setCreatedOrder(null);
        setDropoffAddress("");
        setDropoffPoint(null);
        setNotes("");
      },
      againLabel: `${heroEmoji} Pesan Lagi`
    });
  }

  return (0, jsx.jsx)(SuperAppShell, {
    title: pageTitle,
    back: true,
    children: (0, jsx.jsxs)("div", {
      className: "space-y-4 px-4 py-4 pb-24",
      children: [
        (0, jsx.jsxs)("div", {
          className: "rounded-2xl gradient-primary p-4 text-primary-foreground shadow-soft",
          children: [
            (0, jsx.jsx)("p", { className: "text-[11px] font-bold uppercase tracking-wider opacity-85", children: heroEyebrow }),
            (0, jsx.jsxs)("h2", { className: "mt-1 font-display text-lg font-extrabold", children: [heroTitle, " ", heroEmoji] }),
            (0, jsx.jsx)("p", { className: "mt-0.5 text-xs text-primary-foreground/85", children: heroDesc })
          ]
        }),

        (0, jsx.jsx)("div", {
          className: "grid grid-cols-2 gap-1 rounded-2xl bg-secondary p-1",
          children: [
            { id: "book", label: `${heroEmoji} Pesan ${pageTitle}` },
            { id: "history", label: `🗺️ Riwayat (${orders.length})` }
          ].map((t) =>
            (0, jsx.jsx)(
              "button",
              {
                type: "button",
                onClick: () => setTab(t.id),
                className: `rounded-xl py-2 text-xs font-bold transition-colors ${
                  tab === t.id ? "bg-card text-primary shadow-sm" : "text-muted-foreground"
                }`,
                children: t.label
              },
              t.id
            )
          )
        }),

        (0, jsx.jsx)(AuthBanner, { authLoaded, user, label: `Masuk untuk memesan ${pageTitle}` }),

        tab === "history"
          ? (0, jsx.jsx)(ServiceHistoryList, {
              orders,
              driverLocs,
              emptyTitle: `Belum ada perjalanan ${pageTitle}`,
              emptyDesc: `Riwayat pemesanan ${pageTitle} dan posisi driver akan tampil di sini.`,
              onCreateNew: () => setTab("book"),
              ctaLabel: `Pesan ${pageTitle} Sekarang`
            })
          : (0, jsx.jsxs)("div", {
              className: "space-y-4",
              children: [
                (0, jsx.jsxs)("section", {
                  className: "space-y-3 rounded-2xl bg-card p-4 shadow-soft",
                  children: [
                    (0, jsx.jsxs)("div", {
                      className: "flex items-center justify-between",
                      children: [
                        (0, jsx.jsx)("h3", { className: "text-sm font-bold", children: pickupSectionTitle }),
                        (0, jsx.jsx)("button", {
                          type: "button",
                          onClick: () => setShowPickupMap((v) => !v),
                          className: "rounded-lg bg-primary/10 px-2.5 py-1 text-[11px] font-bold text-primary",
                          children: showPickupMap ? "Tutup Peta" : pickupPoint ? "✓ Titik Dipilih" : "📍 Pilih di Peta"
                        })
                      ]
                    }),
                    (0, jsx.jsx)("input", {
                      type: "text",
                      value: pickupAddress,
                      onChange: (ev) => setPickupAddress(ev.target.value),
                      placeholder: pickupPlaceholder,
                      className: "w-full rounded-xl border border-border bg-background px-3 py-2.5 text-sm"
                    }),
                    showPickupMap &&
                      (0, jsx.jsx)("div", {
                        className: "rounded-xl border border-border p-2.5",
                        children: (0, jsx.jsx)(LocationPicker, {
                          value: pickupPoint,
                          initialCenter: pickupPoint || ABEPURA_CENTER,
                          onChange: (pt) => {
                            setPickupPoint(pt);
                            if (!pickupAddress.trim()) {
                              setPickupAddress(`Titik Jemput (${pt.lat.toFixed(5)}, ${pt.lng.toFixed(5)})`);
                            }
                          }
                        })
                      }),
                    (0, jsx.jsxs)("div", {
                      className: "flex items-center justify-between pt-1",
                      children: [
                        (0, jsx.jsx)("h3", { className: "text-sm font-bold", children: dropoffSectionTitle }),
                        (0, jsx.jsx)("button", {
                          type: "button",
                          onClick: () => setShowDropoffMap((v) => !v),
                          className: "rounded-lg bg-primary/10 px-2.5 py-1 text-[11px] font-bold text-primary",
                          children: showDropoffMap ? "Tutup Peta" : dropoffPoint ? "✓ Titik Tujuan" : "🏁 Pilih di Peta"
                        })
                      ]
                    }),
                    (0, jsx.jsx)("input", {
                      type: "text",
                      value: dropoffAddress,
                      onChange: (ev) => setDropoffAddress(ev.target.value),
                      placeholder: dropoffPlaceholder,
                      className: "w-full rounded-xl border border-border bg-background px-3 py-2.5 text-sm"
                    }),
                    showDropoffMap &&
                      (0, jsx.jsx)("div", {
                        className: "rounded-xl border border-border p-2.5",
                        children: (0, jsx.jsx)(LocationPicker, {
                          value: dropoffPoint,
                          initialCenter: dropoffPoint || pickupPoint || ABEPURA_CENTER,
                          onChange: (pt) => {
                            setDropoffPoint(pt);
                            if (!dropoffAddress.trim()) {
                              setDropoffAddress(`Titik Tujuan (${pt.lat.toFixed(5)}, ${pt.lng.toFixed(5)})`);
                            }
                          }
                        })
                      }),
                    pickupPoint &&
                      dropoffPoint &&
                      (0, jsx.jsx)(OrderMiniMap, {
                        className: "h-36",
                        restaurant: pickupPoint,
                        customer: dropoffPoint,
                        pickupLabel: "Titik Jemput",
                        customerLabel: "Tujuan"
                      }),
                    (0, jsx.jsxs)("div", {
                      className: "grid grid-cols-2 gap-2",
                      children: [
                        (0, jsx.jsx)("input", {
                          type: "text",
                          value: contactName,
                          onChange: (ev) => setContactName(ev.target.value),
                          placeholder: "Nama pemesan",
                          className: "rounded-xl border border-border bg-background px-3 py-2 text-xs"
                        }),
                        (0, jsx.jsx)("input", {
                          type: "tel",
                          value: contactPhone,
                          onChange: (ev) => setContactPhone(ev.target.value),
                          placeholder: "No. WhatsApp (628...)",
                          className: "rounded-xl border border-border bg-background px-3 py-2 text-xs"
                        })
                      ]
                    })
                  ]
                }),

                (0, jsx.jsxs)("section", {
                  className: "space-y-3 rounded-2xl bg-card p-4 shadow-soft",
                  children: [
                    (0, jsx.jsx)("h3", { className: "text-sm font-bold", children: variantSectionTitle }),
                    (0, jsx.jsx)("div", {
                      className: "space-y-2",
                      children: variants.map((v) => {
                        const sel = v.key === activeTier.key;
                        const est = calcDistanceTariff(v, distanceKm);
                        return (0, jsx.jsxs)(
                          "button",
                          {
                            type: "button",
                            onClick: () => setTierKey(v.key),
                            className: `flex w-full items-center justify-between gap-3 rounded-xl border-2 p-3 text-left transition-colors ${
                              sel ? "border-primary bg-primary/5" : "border-border bg-background"
                            }`,
                            children: [
                              (0, jsx.jsxs)("div", {
                                className: "min-w-0",
                                children: [
                                  (0, jsx.jsxs)("p", {
                                    className: "text-sm font-extrabold",
                                    children: [v.emoji, " ", v.label, v.seats ? ` · ${v.seats}` : ""]
                                  }),
                                  (0, jsx.jsx)("p", {
                                    className: "text-xs text-muted-foreground",
                                    children: v.desc
                                  }),
                                  (0, jsx.jsxs)("p", {
                                    className: "mt-0.5 text-[11px] font-medium text-primary",
                                    children: [
                                      "Dasar ",
                                      formatRp(v.baseFee),
                                      " (≤ ",
                                      v.baseMaxKm,
                                      " km) · selanjutnya ",
                                      formatRp(v.perKm),
                                      "/km"
                                    ]
                                  })
                                ]
                              }),
                              (0, jsx.jsx)("span", {
                                className: "shrink-0 font-display text-sm font-extrabold text-primary",
                                children: formatRp(est)
                              })
                            ]
                          },
                          v.key
                        );
                      })
                    }),

                    extraControlsRender && extraControlsRender(),

                    (0, jsx.jsxs)("div", {
                      className: "flex items-center justify-between gap-3 rounded-xl bg-secondary/50 px-3 py-2.5",
                      children: [
                        (0, jsx.jsxs)("div", {
                          children: [
                            (0, jsx.jsx)("p", { className: "text-xs font-bold", children: "Jarak Perjalanan" }),
                            (0, jsx.jsx)("p", {
                              className: "text-[11px] text-muted-foreground",
                              children:
                                pickupPoint && dropoffPoint && !manualDistance
                                  ? "Otomatis rute jalan OSRM"
                                  : "Pilih kedua titik di peta atau isi manual"
                            })
                          ]
                        }),
                        (0, jsx.jsxs)("div", {
                          className: "flex items-center gap-1.5",
                          children: [
                            (0, jsx.jsx)("input", {
                              type: "number",
                              min: "0.5",
                              max: "100",
                              step: "0.1",
                              value: distanceKm,
                              onChange: (ev) => {
                                setManualDistance(true);
                                setDistanceKm(Math.max(0.5, Number(ev.target.value || 1)));
                              },
                              className: "w-16 rounded-lg border border-border bg-background px-2 py-1 text-center text-xs font-bold"
                            }),
                            (0, jsx.jsx)("span", { className: "text-xs font-bold", children: "km" })
                          ]
                        })
                      ]
                    }),
                    (0, jsx.jsx)("input", {
                      type: "text",
                      value: notes,
                      onChange: (ev) => setNotes(ev.target.value),
                      placeholder: "Catatan patokan jemput / detail tambahan (opsional)…",
                      className: "w-full rounded-xl border border-border bg-background px-3 py-2 text-xs"
                    })
                  ]
                }),

                (0, jsx.jsx)(PaymentSelector, { payMethod, setPayMethod, walletBalance, grandTotal }),

                (0, jsx.jsxs)("div", {
                  className: "space-y-2 rounded-2xl border border-primary/20 bg-primary/5 p-4",
                  children: [
                    (0, jsx.jsxs)("div", {
                      className: "flex justify-between text-xs",
                      children: [
                        (0, jsx.jsxs)("span", {
                          children: ["Tarif ", activeTier.label, " (", Number(distanceKm).toFixed(1), " km)"]
                        }),
                        (0, jsx.jsx)("span", { className: "font-bold", children: formatRp(serviceFare) })
                      ]
                    }),
                    (0, jsx.jsxs)("div", {
                      className: "flex justify-between text-xs",
                      children: [
                        (0, jsx.jsx)("span", { children: "Biaya Layanan Aplikasi" }),
                        (0, jsx.jsx)("span", { className: "font-bold", children: formatRp(appFee) })
                      ]
                    }),
                    (0, jsx.jsxs)("div", {
                      className: "flex justify-between border-t border-primary/20 pt-2 text-sm font-extrabold text-primary",
                      children: [
                        (0, jsx.jsx)("span", { children: "Total Bayar" }),
                        (0, jsx.jsx)("span", { children: formatRp(grandTotal) })
                      ]
                    }),
                    (0, jsx.jsx)("button", {
                      type: "button",
                      disabled: submitting || !user || (payMethod === "wallet" && walletBalance < grandTotal),
                      onClick: handleSubmit,
                      className: "mt-3 w-full rounded-xl bg-primary py-3 text-xs font-extrabold text-primary-foreground shadow-md disabled:opacity-50",
                      children: submitting ? "Mencari Driver Terdekat..." : `${ctaVerb} ${activeTier.label} · ${formatRp(grandTotal)}`
                    })
                  ]
                })
              ]
            })
      ]
    })
  });
}

export function GoRidingPage() {
  return (0, jsx.jsx)(DistanceServiceBooking, {
    fulfillmentType: "ride",
    orderPrefix: "RDE",
    pageTitle: "Go Riding",
    heroEyebrow: "Ojek Motor Online",
    heroTitle: "Go Riding — Cepat & Lincah",
    heroDesc: "Pilih Motor Reguler (mulai Rp 10 rb) atau Comfort PCX/NMAX (mulai Rp 12 rb) untuk perjalanan nyaman.",
    heroEmoji: "🏍️",
    variantKeys: ["ride_reg", "ride_comfort"],
    defaultVariant: "ride_reg",
    pickupSectionTitle: "1. Titik Jemput",
    pickupPlaceholder: "Alamat atau patokan jemput kamu...",
    dropoffSectionTitle: "2. Tujuan Perjalanan",
    dropoffPlaceholder: "Mau diantar ke mana?",
    variantSectionTitle: "3. Pilih Tipe Motor",
    ctaVerb: "Pesan"
  });
}

export function GoMobilPage() {
  return (0, jsx.jsx)(DistanceServiceBooking, {
    fulfillmentType: "car",
    orderPrefix: "MBL",
    pageTitle: "Go Mobil",
    heroEyebrow: "Taksi Online Nyaman",
    heroTitle: "Go Mobil — Reg, XL & Premium",
    heroDesc: "Tersedia LCGC hemat (Agya/Brio), XL 6 penumpang/bagasi ekstra, hingga mobil mewah Pajero/Innova.",
    heroEmoji: "🚗",
    variantKeys: ["mobil_reg", "mobil_xl", "mobil_premium"],
    defaultVariant: "mobil_reg",
    pickupSectionTitle: "1. Titik Jemput Penumpang",
    pickupPlaceholder: "Alamat jemput mobil...",
    dropoffSectionTitle: "2. Alamat Tujuan",
    dropoffPlaceholder: "Tujuan pengantaran...",
    variantSectionTitle: "3. Pilih Kelas Mobil",
    ctaVerb: "Pesan"
  });
}

const CARGO_KINDS = [
  "Perabot / Furnitur",
  "Bahan Bangunan / Proyek",
  "Stok Toko / Sembako",
  "Pindahan Kost / Rumah",
  "Elektronik / Alat Berat"
];

export function GoCargoPage() {
  const [cargoKind, setCargoKind] = React.useState(CARGO_KINDS[0]);
  const [needHelper, setNeedHelper] = React.useState(false);

  return (0, jsx.jsx)(DistanceServiceBooking, {
    fulfillmentType: "cargo",
    orderPrefix: "CRG",
    pageTitle: "Go Cargo",
    heroEyebrow: "Angkutan Barang",
    heroTitle: "Go Cargo — Pickup & Kiriman Besar",
    heroDesc: "Angkutan barang praktis mulai Rp 60 rb untuk ≤ 4,2 km dan hanya Rp 4 rb/km selanjutnya.",
    heroEmoji: "🚚",
    variantKeys: ["cargo_std"],
    defaultVariant: "cargo_std",
    pickupSectionTitle: "1. Lokasi Muat Barang",
    pickupPlaceholder: "Alamat penjemputan barang...",
    dropoffSectionTitle: "2. Lokasi Bongkar / Tujuan",
    dropoffPlaceholder: "Alamat tujuan pengiriman barang...",
    variantSectionTitle: "3. Tarif Angkutan & Muatan",
    ctaVerb: "Pesan",
    buildExtraSummary: () => `${cargoKind}${needHelper ? " + Bantuan Angkut" : ""}`,
    extraControlsRender: () =>
      (0, jsx.jsxs)("div", {
        className: "space-y-2 pt-1",
        children: [
          (0, jsx.jsx)("p", { className: "text-xs font-semibold text-muted-foreground", children: "Jenis Muatan Barang" }),
          (0, jsx.jsx)("div", {
            className: "flex flex-wrap gap-1.5",
            children: CARGO_KINDS.map((k) =>
              (0, jsx.jsx)(
                "button",
                {
                  type: "button",
                  onClick: () => setCargoKind(k),
                  className: `rounded-full px-3 py-1.5 text-xs font-semibold transition-colors ${
                    cargoKind === k ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground"
                  }`,
                  children: k
                },
                k
              )
            )
          }),
          (0, jsx.jsxs)("label", {
            className: "flex items-center gap-2 pt-1 text-xs font-semibold",
            children: [
              (0, jsx.jsx)("input", {
                type: "checkbox",
                checked: needHelper,
                onChange: (ev) => setNeedHelper(ev.target.checked),
                className: "size-4 accent-primary"
              }),
              "Minta driver bantu naik-turunkan barang ke bagasi"
            ]
          })
        ]
      })
  });
}

const SURUH_CATEGORIES = [
  "🛒 Titip Belanja Pasar / Toko",
  "🏦 Antre / Urus Dokumen",
  "🏡 Bantuan Rumah / Acara",
  "📦 Ambil / Antar Titipan"
];

const SURUH_DURATIONS = [
  { mins: 60, label: "1 Jam (60 mnt)" },
  { mins: 75, label: "1j 15m (75 mnt)" },
  { mins: 90, label: "1,5 Jam (90 mnt)" },
  { mins: 120, label: "2 Jam (120 mnt)" },
  { mins: 180, label: "3 Jam (180 mnt)" }
];

export function GoSuruhPage() {
  const navigate = useNavigate();
  const { tariffs } = useServiceTariffs();
  const suruhCfg = tariffs.tiers.suruh_hourly;
  const [tab, setTab] = React.useState("book");
  const { user, authLoaded, walletBalance, setWalletBalance, profile, orders, driverLocs, reload } =
    useServiceBookingData("suruh", tab);

  const initLp = gpPt();
  const [taskCat, setTaskCat] = React.useState(SURUH_CATEGORIES[0]);
  const [taskDesc, setTaskDesc] = React.useState("");
  const [durationMins, setDurationMins] = React.useState(60);
  const [pickupAddress, setPickupAddress] = React.useState(() => initLp?.address || "");
  const [pickupPoint, setPickupPoint] = React.useState(() =>
    initLp ? { lat: initLp.latitude, lng: initLp.longitude } : null
  );
  const [showPickupMap, setShowPickupMap] = React.useState(false);
  const [dropoffAddress, setDropoffAddress] = React.useState("");
  const [dropoffPoint, setDropoffPoint] = React.useState(null);
  const [showDropoffMap, setShowDropoffMap] = React.useState(false);
  const [contactName, setContactName] = React.useState("");
  const [contactPhone, setContactPhone] = React.useState("");
  const [payMethod, setPayMethod] = React.useState("cash");
  const [submitting, setSubmitting] = React.useState(false);
  const [createdOrder, setCreatedOrder] = React.useState(null);
  const [redirectSec, setRedirectSec] = React.useState(null);

  React.useEffect(() => {
    if (!profile) return;
    setContactName((v) => v || profile.full_name || "");
    setContactPhone((v) => v || profile.phone || "");
    setPickupAddress((v) => v || profile.address || "");
    if (profile.latitude != null && profile.longitude != null) {
      setPickupPoint((v) => v || { lat: Number(profile.latitude), lng: Number(profile.longitude) });
    }
  }, [profile]);

  React.useEffect(() => {
    if (redirectSec == null) return;
    if (redirectSec <= 0) {
      navigate({ to: "/orders" });
      return;
    }
    const tmr = setTimeout(() => setRedirectSec((s) => (s == null ? null : s - 1)), 1000);
    return () => clearTimeout(tmr);
  }, [redirectSec, navigate]);

  const serviceFare = calcSuruhTariff(suruhCfg, durationMins);
  const extraMins = Math.max(0, durationMins - Number(suruhCfg.baseMinutes || 60));
  const appFee = Number(tariffs.appFee ?? 2000);
  const grandTotal = serviceFare + appFee;

  const handleSubmit = async () => {
    if (!user) {
      toast.error("Silakan masuk untuk memesan Go Suruh.");
      navigate({ to: "/auth" });
      return;
    }
    if (!taskDesc.trim() || !pickupAddress.trim()) {
      toast.error("Jelaskan tugas yang dibutuhkan & isi lokasi tugas.");
      return;
    }
    if (payMethod === "wallet" && walletBalance < grandTotal) {
      toast.error("Saldo GoGoGo Pay tidak cukup. Top up dulu di menu GoGoGo Pay.");
      return;
    }

    setSubmitting(true);
    try {
      const orderNum = "SRH-" + Date.now().toString().slice(-6);
      const pLat = pickupPoint?.lat ?? ABEPURA_CENTER.lat;
      const pLng = pickupPoint?.lng ?? ABEPURA_CENTER.lng;
      const dLat = dropoffPoint?.lat ?? pLat;
      const dLng = dropoffPoint?.lng ?? pLng;
      const summary = `${taskCat} · ${durationMins} menit`;
      const combinedNotes = `${taskCat} (${durationMins} mnt) | Tugas: ${taskDesc.trim()}`;

      const { data: ord, error: ordErr } = await supabase
        .from("orders")
        .insert({
          order_number: orderNum,
          customer_id: user.id,
          restaurant_id: null,
          customer_name: (contactName || profile?.full_name || "Pelanggan GoGoGo").trim(),
          customer_phone: (contactPhone || profile?.phone || "-").trim(),
          customer_address: dropoffAddress.trim() || pickupAddress.trim(),
          pickup_address: pickupAddress.trim(),
          pickup_latitude: pLat,
          pickup_longitude: pLng,
          latitude: dLat,
          longitude: dLng,
          status: "searching_driver",
          fulfillment_type: "suruh",
          payment_method: payMethod,
          payment_status: payMethod === "wallet" ? "paid" : "unpaid",
          delivery_tier: "suruh_hourly",
          delivery_tier_label: "Go Suruh",
          subtotal: 0,
          admin_fee: 0,
          app_fee: appFee,
          delivery_fee: serviceFare,
          discount: 0,
          total: grandTotal,
          notes: combinedNotes
        })
        .select()
        .single();

      if (ordErr) throw ordErr;

      if (payMethod === "wallet") {
        const { data: wp, error: we } = await supabase.rpc("wallet_pay_order", {
          _order_id: ord.id,
          _amount: grandTotal,
          _description: `Go Suruh (${durationMins} mnt) #${orderNum}`
        });
        if (we || wp?.success === false) {
          await supabase.from("orders").delete().eq("id", ord.id);
          throw new Error(wp?.message || we?.message || "Pembayaran GoGoGo Pay gagal.");
        }
        setWalletBalance(Number(wp?.wallet_balance ?? walletBalance - grandTotal));
      }

      const { error: itemErr } = await supabase.from("order_items").insert({
        order_id: ord.id,
        menu_item_id: null,
        menu_name: summary,
        quantity: 1,
        price: serviceFare,
        subtotal: serviceFare,
        restaurant_price: serviceFare,
        markup_amount: 0,
        notes: taskDesc.trim()
      });
      if (itemErr) throw itemErr;

      toast.success("Pesanan Go Suruh dibuat! Mencari mitra terdekat.");
      setCreatedOrder({
        id: ord.id,
        order_number: orderNum,
        total: grandTotal,
        pickup: pickupAddress.trim(),
        dropoff: dropoffAddress.trim() || null,
        pickupPoint: { lat: pLat, lng: pLng },
        dropoffPoint: dropoffPoint,
        payment_method: payMethod,
        label: `Go Suruh (${durationMins} menit)`
      });
      setRedirectSec(3);
      if (typeof window !== "undefined") window.scrollTo({ top: 0, behavior: "smooth" });
      await reload();
    } catch (err) {
      toast.error(err?.message || "Gagal membuat pesanan Go Suruh.");
    } finally {
      setSubmitting(false);
    }
  };

  if (createdOrder) {
    return (0, jsx.jsx)(BookingSuccessView, {
      title: "Go Suruh Dibuat",
      emoji: "🙋",
      createdOrder,
      redirectSec,
      navigate,
      onStopTimer: () => setRedirectSec(null),
      onReset: () => {
        setRedirectSec(null);
        setCreatedOrder(null);
        setTaskDesc("");
      },
      againLabel: "🙋 Pesan Go Suruh Lagi"
    });
  }

  return (0, jsx.jsx)(SuperAppShell, {
    title: "Go Suruh",
    back: true,
    children: (0, jsx.jsxs)("div", {
      className: "space-y-4 px-4 py-4 pb-24",
      children: [
        (0, jsx.jsxs)("div", {
          className: "rounded-2xl gradient-primary p-4 text-primary-foreground shadow-soft",
          children: [
            (0, jsx.jsx)("p", { className: "text-[11px] font-bold uppercase tracking-wider opacity-85", children: "Asisten & Suruhan Pribadi" }),
            (0, jsx.jsx)("h2", { className: "mt-1 font-display text-lg font-extrabold", children: "Go Suruh — Siap Bantu Urusanmu 🙋" }),
            (0, jsx.jsxs)("p", {
              className: "mt-0.5 text-xs text-primary-foreground/85",
              children: [
                "Tarif transparan ",
                formatRp(suruhCfg.baseHourFee),
                "/jam pertama (",
                suruhCfg.baseMinutes,
                " menit), selanjutnya ",
                formatRp(suruhCfg.perMinute),
                "/menit."
              ]
            })
          ]
        }),

        (0, jsx.jsx)("div", {
          className: "grid grid-cols-2 gap-1 rounded-2xl bg-secondary p-1",
          children: [
            { id: "book", label: "🙋 Buat Tugas" },
            { id: "history", label: `🗺️ Riwayat (${orders.length})` }
          ].map((t) =>
            (0, jsx.jsx)(
              "button",
              {
                type: "button",
                onClick: () => setTab(t.id),
                className: `rounded-xl py-2 text-xs font-bold transition-colors ${
                  tab === t.id ? "bg-card text-primary shadow-sm" : "text-muted-foreground"
                }`,
                children: t.label
              },
              t.id
            )
          )
        }),

        (0, jsx.jsx)(AuthBanner, { authLoaded, user, label: "Masuk untuk memesan Go Suruh" }),

        tab === "history"
          ? (0, jsx.jsx)(ServiceHistoryList, {
              orders,
              driverLocs,
              emptyTitle: "Belum ada tugas Go Suruh",
              emptyDesc: "Pesanan suruhan, titip belanja, atau antre kamu akan muncul di sini.",
              onCreateNew: () => setTab("book"),
              ctaLabel: "Buat Tugas Pertama"
            })
          : (0, jsx.jsxs)("div", {
              className: "space-y-4",
              children: [
                (0, jsx.jsxs)("section", {
                  className: "space-y-3 rounded-2xl bg-card p-4 shadow-soft",
                  children: [
                    (0, jsx.jsx)("h3", { className: "text-sm font-bold", children: "1. Pilih Jenis Tugas & Deskripsi" }),
                    (0, jsx.jsx)("div", {
                      className: "flex flex-wrap gap-1.5",
                      children: SURUH_CATEGORIES.map((cat) =>
                        (0, jsx.jsx)(
                          "button",
                          {
                            type: "button",
                            onClick: () => setTaskCat(cat),
                            className: `rounded-full px-3 py-1.5 text-xs font-semibold transition-colors ${
                              taskCat === cat ? "bg-primary text-primary-foreground" : "bg-secondary text-foreground"
                            }`,
                            children: cat
                          },
                          cat
                        )
                      )
                    }),
                    (0, jsx.jsx)("textarea", {
                      rows: 3,
                      value: taskDesc,
                      onChange: (ev) => setTaskDesc(ev.target.value),
                      placeholder: "Contoh: Tolong belikan galon 2 buah & antre obat di Apotek Abepura lalu antar ke rumah...",
                      className: "w-full rounded-xl border border-border bg-background px-3 py-2.5 text-sm"
                    })
                  ]
                }),

                (0, jsx.jsxs)("section", {
                  className: "space-y-3 rounded-2xl bg-card p-4 shadow-soft",
                  children: [
                    (0, jsx.jsx)("h3", { className: "text-sm font-bold", children: "2. Durasi Waktu Kerja Mitra" }),
                    (0, jsx.jsx)("div", {
                      className: "flex flex-wrap gap-1.5",
                      children: SURUH_DURATIONS.map((d) =>
                        (0, jsx.jsx)(
                          "button",
                          {
                            type: "button",
                            onClick: () => setDurationMins(d.mins),
                            className: `rounded-xl border px-3 py-2 text-xs font-bold transition-colors ${
                              durationMins === d.mins ? "border-primary bg-primary text-primary-foreground" : "border-border bg-background"
                            }`,
                            children: d.label
                          },
                          d.mins
                        )
                      )
                    }),
                    (0, jsx.jsxs)("div", {
                      className: "flex items-center justify-between rounded-xl bg-secondary/60 px-3 py-2.5",
                      children: [
                        (0, jsx.jsxs)("div", {
                          children: [
                            (0, jsx.jsx)("p", { className: "text-xs font-bold", children: "Sesuaikan Menit" }),
                            (0, jsx.jsxs)("p", {
                              className: "text-[11px] text-muted-foreground",
                              children: [
                                extraMins === 0
                                  ? `Paket 1 jam (${suruhCfg.baseMinutes} mnt)`
                                  : `1 jam + ${extraMins} mnt ekstra (+${formatRp(extraMins * suruhCfg.perMinute)})`
                              ]
                            })
                          ]
                        }),
                        (0, jsx.jsxs)("div", {
                          className: "flex items-center gap-1.5",
                          children: [
                            (0, jsx.jsx)("button", {
                              type: "button",
                              onClick: () => setDurationMins((m) => Math.max(suruhCfg.baseMinutes, m - 5)),
                              className: "grid size-8 place-items-center rounded-lg bg-card font-bold shadow-sm",
                              children: "−"
                            }),
                            (0, jsx.jsxs)("span", {
                              className: "min-w-16 text-center text-xs font-extrabold",
                              children: [durationMins, " mnt"]
                            }),
                            (0, jsx.jsx)("button", {
                              type: "button",
                              onClick: () => setDurationMins((m) => Math.min(480, m + 5)),
                              className: "grid size-8 place-items-center rounded-lg bg-card font-bold shadow-sm",
                              children: "+"
                            })
                          ]
                        })
                      ]
                    })
                  ]
                }),

                (0, jsx.jsxs)("section", {
                  className: "space-y-3 rounded-2xl bg-card p-4 shadow-soft",
                  children: [
                    (0, jsx.jsxs)("div", {
                      className: "flex items-center justify-between",
                      children: [
                        (0, jsx.jsx)("h3", { className: "text-sm font-bold", children: "3. Lokasi Tugas & Titik Antar" }),
                        (0, jsx.jsx)("button", {
                          type: "button",
                          onClick: () => setShowPickupMap((v) => !v),
                          className: "rounded-lg bg-primary/10 px-2.5 py-1 text-[11px] font-bold text-primary",
                          children: showPickupMap ? "Tutup Peta" : pickupPoint ? "✓ Titik Utama" : "📍 Pilih di Peta"
                        })
                      ]
                    }),
                    (0, jsx.jsx)("input", {
                      type: "text",
                      value: pickupAddress,
                      onChange: (ev) => setPickupAddress(ev.target.value),
                      placeholder: "Alamat titik temu / lokasi tugas utama *",
                      className: "w-full rounded-xl border border-border bg-background px-3 py-2.5 text-sm"
                    }),
                    showPickupMap &&
                      (0, jsx.jsx)("div", {
                        className: "rounded-xl border border-border p-2.5",
                        children: (0, jsx.jsx)(LocationPicker, {
                          value: pickupPoint,
                          initialCenter: pickupPoint || ABEPURA_CENTER,
                          onChange: (pt) => {
                            setPickupPoint(pt);
                            if (!pickupAddress.trim()) setPickupAddress(`Titik Peta (${pt.lat.toFixed(5)}, ${pt.lng.toFixed(5)})`);
                          }
                        })
                      }),
                    (0, jsx.jsxs)("div", {
                      className: "flex items-center justify-between pt-1",
                      children: [
                        (0, jsx.jsx)("span", { className: "text-xs font-semibold text-muted-foreground", children: "Alamat tujuan akhir / pengembalian (opsional)" }),
                        (0, jsx.jsx)("button", {
                          type: "button",
                          onClick: () => setShowDropoffMap((v) => !v),
                          className: "rounded-lg bg-secondary px-2 py-1 text-[11px] font-bold text-primary",
                          children: showDropoffMap ? "Tutup Peta" : dropoffPoint ? "✓ Tujuan Ada" : "🏁 Peta Tujuan"
                        })
                      ]
                    }),
                    (0, jsx.jsx)("input", {
                      type: "text",
                      value: dropoffAddress,
                      onChange: (ev) => setDropoffAddress(ev.target.value),
                      placeholder: "Alamat antar kembali jika berbeda dari lokasi utama...",
                      className: "w-full rounded-xl border border-border bg-background px-3 py-2 text-xs"
                    }),
                    showDropoffMap &&
                      (0, jsx.jsx)("div", {
                        className: "rounded-xl border border-border p-2.5",
                        children: (0, jsx.jsx)(LocationPicker, {
                          value: dropoffPoint,
                          initialCenter: dropoffPoint || pickupPoint || ABEPURA_CENTER,
                          onChange: (pt) => {
                            setDropoffPoint(pt);
                            if (!dropoffAddress.trim()) setDropoffAddress(`Tujuan (${pt.lat.toFixed(5)}, ${pt.lng.toFixed(5)})`);
                          }
                        })
                      }),
                    (0, jsx.jsxs)("div", {
                      className: "grid grid-cols-2 gap-2",
                      children: [
                        (0, jsx.jsx)("input", {
                          type: "text",
                          value: contactName,
                          onChange: (ev) => setContactName(ev.target.value),
                          placeholder: "Nama pemesan",
                          className: "rounded-xl border border-border bg-background px-3 py-2 text-xs"
                        }),
                        (0, jsx.jsx)("input", {
                          type: "tel",
                          value: contactPhone,
                          onChange: (ev) => setContactPhone(ev.target.value),
                          placeholder: "No. WhatsApp (628...)",
                          className: "rounded-xl border border-border bg-background px-3 py-2 text-xs"
                        })
                      ]
                    })
                  ]
                }),

                (0, jsx.jsx)(PaymentSelector, { payMethod, setPayMethod, walletBalance, grandTotal }),

                (0, jsx.jsxs)("div", {
                  className: "space-y-2 rounded-2xl border border-primary/20 bg-primary/5 p-4",
                  children: [
                    (0, jsx.jsxs)("div", {
                      className: "flex justify-between text-xs",
                      children: [
                        (0, jsx.jsxs)("span", { children: ["Biaya 1 Jam Pertama (", suruhCfg.baseMinutes, " mnt)"] }),
                        (0, jsx.jsx)("span", { className: "font-bold", children: formatRp(suruhCfg.baseHourFee) })
                      ]
                    }),
                    extraMins > 0 &&
                      (0, jsx.jsxs)("div", {
                        className: "flex justify-between text-xs",
                        children: [
                          (0, jsx.jsxs)("span", { children: ["Tambahan (", extraMins, " mnt × ", formatRp(suruhCfg.perMinute), ")"] }),
                          (0, jsx.jsx)("span", { className: "font-bold", children: formatRp(extraMins * suruhCfg.perMinute) })
                        ]
                      }),
                    (0, jsx.jsxs)("div", {
                      className: "flex justify-between text-xs",
                      children: [
                        (0, jsx.jsx)("span", { children: "Biaya Layanan Aplikasi" }),
                        (0, jsx.jsx)("span", { className: "font-bold", children: formatRp(appFee) })
                      ]
                    }),
                    (0, jsx.jsxs)("div", {
                      className: "flex justify-between border-t border-primary/20 pt-2 text-sm font-extrabold text-primary",
                      children: [
                        (0, jsx.jsx)("span", { children: "Total Biaya Jasa" }),
                        (0, jsx.jsx)("span", { children: formatRp(grandTotal) })
                      ]
                    }),
                    (0, jsx.jsx)("p", {
                      className: "text-[11px] text-muted-foreground",
                      children: "* Dana titip belanja / pembayaran di lokasi (jika ada) dibayar terpisah sesuai struk asli."
                    }),
                    (0, jsx.jsx)("button", {
                      type: "button",
                      disabled: submitting || !user || (payMethod === "wallet" && walletBalance < grandTotal),
                      onClick: handleSubmit,
                      className: "mt-3 w-full rounded-xl bg-primary py-3 text-xs font-extrabold text-primary-foreground shadow-md disabled:opacity-50",
                      children: submitting ? "Mencari Mitra Go Suruh..." : `Pesan Go Suruh · ${formatRp(grandTotal)}`
                    })
                  ]
                })
              ]
            })
      ]
    })
  });
}

export const goRidingComponent = GoRidingPage;
export const goMobilComponent = GoMobilPage;
export const goCargoComponent = GoCargoPage;
export const goSuruhComponent = GoSuruhPage;
