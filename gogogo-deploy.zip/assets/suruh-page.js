export { goSuruhComponent as component } from "./go-transport-pages.js";
