export { goMobilComponent as component } from "./go-transport-pages.js";
