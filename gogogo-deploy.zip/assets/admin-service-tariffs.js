import { a as e } from "./chunk-Cyuzqnbw.js";
import { n as t, t as n } from "./jsx-runtime-dIob5GyK.js";
import { n as supabase } from "./client-DVq7Iik5.js";
import { i as useQueryClient } from "./queryOptions-kMMPsoVQ.js";
import { $o as toast } from "./index-CWsrv0HS.js";
import {
  DEFAULT_SERVICE_TARIFFS,
  SERVICE_TARIFFS_KEY,
  calcDistanceTariff,
  calcSuruhTariff,
  formatRp,
  mergeServiceTariffs,
  useServiceTariffs
} from "./service-tariffs.js";

var React = e(t(), 1);
var jsx = n();

const TIER_ORDER = [
  "ride_reg",
  "ride_comfort",
  "mobil_reg",
  "mobil_xl",
  "mobil_premium",
  "cargo_std",
  "express_base"
];

function ServiceTariffsCard() {
  const qc = useQueryClient();
  const { tariffs, loading } = useServiceTariffs();
  const [draft, setDraft] = React.useState(null);
  const [saving, setSaving] = React.useState(false);

  const cur = draft ?? tariffs ?? DEFAULT_SERVICE_TARIFFS;
  const suruh = cur.tiers.suruh_hourly;

  const updateTier = (key, patch) => {
    setDraft((prev) => {
      const base = prev ?? mergeServiceTariffs(tariffs);
      return {
        ...base,
        tiers: {
          ...base.tiers,
          [key]: { ...base.tiers[key], ...patch }
        }
      };
    });
  };

  const handleSave = async () => {
    const clean = mergeServiceTariffs(cur);
    setSaving(true);
    try {
      const { error } = await supabase
        .from("app_settings")
        .upsert({ key: SERVICE_TARIFFS_KEY, value: clean }, { onConflict: "key" });
      if (error) throw error;
      qc.setQueryData(["service-tariffs"], clean);
      qc.invalidateQueries({ queryKey: ["service-tariffs"] });
      setDraft(null);
      toast.success("Tarif Go Riding, Mobil, Cargo, Express & Go Suruh disimpan.");
    } catch (err) {
      toast.error(err?.message || "Gagal menyimpan tarif layanan.");
    } finally {
      setSaving(false);
    }
  };

  return (0, jsx.jsxs)("div", {
    className: "rounded-2xl bg-card p-4 shadow-soft space-y-4",
    children: [
      (0, jsx.jsxs)("div", {
        className: "flex flex-wrap items-start justify-between gap-2",
        children: [
          (0, jsx.jsxs)("div", {
            children: [
              (0, jsx.jsx)("p", {
                className: "font-display font-bold",
                children: "Tarif Layanan (Go Riding, Mobil, Cargo, Express & Go Suruh)"
              }),
              (0, jsx.jsx)("p", {
                className: "mt-1 text-sm text-muted-foreground",
                children: "Atur tarif dasar, batas kilometer/durasi dasar, dan biaya per km atau per menit untuk semua layanan baru."
              })
            ]
          }),
          (0, jsx.jsx)("button", {
            type: "button",
            onClick: () => setDraft(DEFAULT_SERVICE_TARIFFS),
            className: "rounded-lg border border-border px-2.5 py-1 text-xs font-semibold text-muted-foreground hover:bg-secondary",
            children: "Reset Default"
          })
        ]
      }),

      (0, jsx.jsxs)("div", {
        className: "rounded-xl border border-primary/20 bg-primary/5 p-3",
        children: [
          (0, jsx.jsx)("label", {
            className: "block text-xs font-bold text-primary",
            children: "Biaya Layanan Platform / Aplikasi (Rp)"
          }),
          (0, jsx.jsxs)("div", {
            className: "mt-1.5 flex items-center gap-3",
            children: [
              (0, jsx.jsx)("input", {
                type: "number",
                min: 0,
                step: 500,
                disabled: loading || saving,
                value: cur.appFee,
                onChange: (ev) =>
                  setDraft((prev) => ({
                    ...(prev ?? mergeServiceTariffs(tariffs)),
                    appFee: Math.max(0, Number(ev.target.value || 0))
                  })),
                className: "h-9 w-36 rounded-lg border border-input bg-background px-3 text-sm font-bold"
              }),
              (0, jsx.jsx)("span", {
                className: "text-xs text-muted-foreground",
                children: "Berlaku sebagai biaya aplikasi per transaksi layanan."
              })
            ]
          })
        ]
      }),

      (0, jsx.jsx)("div", {
        className: "space-y-3",
        children: TIER_ORDER.map((key) => {
          const item = cur.tiers[key];
          const sample6Km = calcDistanceTariff(item, 6);
          return (0, jsx.jsxs)(
            "div",
            {
              className: "rounded-xl border border-border p-3 space-y-2.5",
              children: [
                (0, jsx.jsxs)("div", {
                  className: "flex items-center justify-between gap-2",
                  children: [
                    (0, jsx.jsxs)("div", {
                      className: "min-w-0",
                      children: [
                        (0, jsx.jsxs)("p", {
                          className: "text-sm font-bold",
                          children: [item.emoji, " ", item.label]
                        }),
                        (0, jsx.jsx)("p", {
                          className: "text-xs text-muted-foreground",
                          children: item.desc
                        })
                      ]
                    }),
                    (0, jsx.jsx)("label", {
                      className: "inline-flex cursor-pointer items-center gap-1.5 text-xs font-semibold",
                      children: [
                        (0, jsx.jsx)("input", {
                          type: "checkbox",
                          checked: item.enabled !== false,
                          disabled: loading || saving,
                          onChange: (ev) => updateTier(key, { enabled: ev.target.checked }),
                          className: "size-4 accent-primary"
                        }),
                        "Aktif"
                      ]
                    })
                  ]
                }),
                (0, jsx.jsxs)("div", {
                  className: "grid grid-cols-3 gap-2",
                  children: [
                    (0, jsx.jsxs)("label", {
                      className: "block space-y-1",
                      children: [
                        (0, jsx.jsx)("span", { className: "text-[11px] font-medium text-muted-foreground", children: "Tarif Dasar (Rp)" }),
                        (0, jsx.jsx)("input", {
                          type: "number",
                          min: 0,
                          step: 500,
                          disabled: loading || saving,
                          value: item.baseFee,
                          onChange: (ev) => updateTier(key, { baseFee: Math.max(0, Number(ev.target.value || 0)) }),
                          className: "h-9 w-full rounded-lg border border-input bg-background px-2.5 text-sm font-semibold"
                        })
                      ]
                    }),
                    (0, jsx.jsxs)("label", {
                      className: "block space-y-1",
                      children: [
                        (0, jsx.jsx)("span", { className: "text-[11px] font-medium text-muted-foreground", children: "Maks Dasar (km)" }),
                        (0, jsx.jsx)("input", {
                          type: "number",
                          min: 0.5,
                          step: 0.1,
                          disabled: loading || saving,
                          value: item.baseMaxKm,
                          onChange: (ev) => updateTier(key, { baseMaxKm: Math.max(0.1, Number(ev.target.value || 0.1)) }),
                          className: "h-9 w-full rounded-lg border border-input bg-background px-2.5 text-sm font-semibold"
                        })
                      ]
                    }),
                    (0, jsx.jsxs)("label", {
                      className: "block space-y-1",
                      children: [
                        (0, jsx.jsx)("span", { className: "text-[11px] font-medium text-muted-foreground", children: "Per km lanjut (Rp)" }),
                        (0, jsx.jsx)("input", {
                          type: "number",
                          min: 0,
                          step: 500,
                          disabled: loading || saving,
                          value: item.perKm,
                          onChange: (ev) => updateTier(key, { perKm: Math.max(0, Number(ev.target.value || 0)) }),
                          className: "h-9 w-full rounded-lg border border-input bg-background px-2.5 text-sm font-semibold"
                        })
                      ]
                    })
                  ]
                }),
                (0, jsx.jsxs)("p", {
                  className: "text-[11px] text-muted-foreground",
                  children: [
                    "≤ ",
                    item.baseMaxKm,
                    " km = ",
                    formatRp(item.baseFee),
                    " · Simulasi 6 km = ",
                    (0, jsx.jsx)("span", { className: "font-bold text-primary", children: formatRp(sample6Km) })
                  ]
                })
              ]
            },
            key
          );
        })
      }),

      (0, jsx.jsxs)("div", {
        className: "rounded-xl border border-primary/30 bg-secondary/30 p-3 space-y-2.5",
        children: [
          (0, jsx.jsxs)("div", {
            className: "flex items-center justify-between gap-2",
            children: [
              (0, jsx.jsxs)("div", {
                children: [
                  (0, jsx.jsxs)("p", { className: "text-sm font-bold", children: [suruh.emoji, " ", suruh.label] }),
                  (0, jsx.jsx)("p", { className: "text-xs text-muted-foreground", children: suruh.desc })
                ]
              }),
              (0, jsx.jsxs)("label", {
                className: "inline-flex cursor-pointer items-center gap-1.5 text-xs font-semibold",
                children: [
                  (0, jsx.jsx)("input", {
                    type: "checkbox",
                    checked: suruh.enabled !== false,
                    disabled: loading || saving,
                    onChange: (ev) => updateTier("suruh_hourly", { enabled: ev.target.checked }),
                    className: "size-4 accent-primary"
                  }),
                  "Aktif"
                ]
              })
            ]
          }),
          (0, jsx.jsxs)("div", {
            className: "grid grid-cols-3 gap-2",
            children: [
              (0, jsx.jsxs)("label", {
                className: "block space-y-1",
                children: [
                  (0, jsx.jsx)("span", { className: "text-[11px] font-medium text-muted-foreground", children: "Biaya 1 Jam (Rp)" }),
                  (0, jsx.jsx)("input", {
                    type: "number",
                    min: 0,
                    step: 1000,
                    disabled: loading || saving,
                    value: suruh.baseHourFee,
                    onChange: (ev) => updateTier("suruh_hourly", { baseHourFee: Math.max(0, Number(ev.target.value || 0)) }),
                    className: "h-9 w-full rounded-lg border border-input bg-background px-2.5 text-sm font-semibold"
                  })
                ]
              }),
              (0, jsx.jsxs)("label", {
                className: "block space-y-1",
                children: [
                  (0, jsx.jsx)("span", { className: "text-[11px] font-medium text-muted-foreground", children: "Durasi Awal (Mnt)" }),
                  (0, jsx.jsx)("input", {
                    type: "number",
                    min: 15,
                    step: 5,
                    disabled: loading || saving,
                    value: suruh.baseMinutes,
                    onChange: (ev) => updateTier("suruh_hourly", { baseMinutes: Math.max(15, Number(ev.target.value || 60)) }),
                    className: "h-9 w-full rounded-lg border border-input bg-background px-2.5 text-sm font-semibold"
                  })
                ]
              }),
              (0, jsx.jsxs)("label", {
                className: "block space-y-1",
                children: [
                  (0, jsx.jsx)("span", { className: "text-[11px] font-medium text-muted-foreground", children: "Per Menit (Rp)" }),
                  (0, jsx.jsx)("input", {
                    type: "number",
                    min: 0,
                    step: 500,
                    disabled: loading || saving,
                    value: suruh.perMinute,
                    onChange: (ev) => updateTier("suruh_hourly", { perMinute: Math.max(0, Number(ev.target.value || 0)) }),
                    className: "h-9 w-full rounded-lg border border-input bg-background px-2.5 text-sm font-semibold"
                  })
                ]
              })
            ]
          }),
          (0, jsx.jsxs)("p", {
            className: "text-[11px] text-muted-foreground",
            children: [
              "Simulasi 90 menit (1,5 jam) = ",
              (0, jsx.jsx)("span", { className: "font-bold text-primary", children: formatRp(calcSuruhTariff(suruh, 90)) })
            ]
          })
        ]
      }),

      (0, jsx.jsxs)("div", {
        className: "flex items-center gap-2",
        children: [
          (0, jsx.jsx)("button", {
            type: "button",
            disabled: saving || loading,
            onClick: handleSave,
            className: "h-10 rounded-xl bg-primary px-5 text-sm font-bold text-primary-foreground shadow-sm transition-opacity hover:opacity-95 disabled:opacity-50",
            children: saving ? "Menyimpan..." : "Simpan Tarif Layanan"
          }),
          draft &&
            (0, jsx.jsx)("button", {
              type: "button",
              disabled: saving,
              onClick: () => setDraft(null),
              className: "h-10 rounded-xl border border-border px-4 text-sm font-semibold text-muted-foreground hover:bg-secondary",
              children: "Batalkan"
            })
        ]
      })
    ]
  });
}

export { ServiceTariffsCard };
