const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/leaflet-src-543Eu7F2.js","assets/chunk-Cyuzqnbw.js"])))=>i.map(i=>d[i]);
import{a as e}from"./chunk-Cyuzqnbw.js";import{n as t,t as n}from"./jsx-runtime-dIob5GyK.js";import{t as r}from"./preload-helper-zJ_50EbN.js";import{$ as i,X as a,et as o,jo as s,mo as c,nt as l,tt as u}from"./index-CWsrv0HS.js";var d=e(t(),1),f=n();function p(e){if(!e)return null;let t=Number(e.lat),n=Number(e.lng);return!Number.isFinite(t)||!Number.isFinite(n)||Math.abs(t)>90||Math.abs(n)>180?null:{lat:t,lng:n}}function m(e){return`<span style="display:block;width:16px;height:16px;border-radius:9999px;background:${e};border:2px solid #ffffff;box-shadow:0 1px 3px rgba(0,0,0,0.4)"></span>`}function h({restaurant:t,customer:n,driver:drv,fallbackLink:h,fallbackLabel:g=`Buka di Google Maps`,pickupLabel:pkLbl=`Titik Jemput / Resto`,customerLabel:cuLbl=`Tujuan Pelanggan`,className:_,interactive:iv=!0}){
  let sPt=p(t),cPt=p(n),drvPt=p(drv),
  sLat=sPt?.lat??null,sLng=sPt?.lng??null,
  cLat=cPt?.lat??null,cLng=cPt?.lng??null,
  dLat=drvPt?.lat??null,dLng=drvPt?.lng??null,
  v=(0,d.useRef)(null),
  mapRef=(0,d.useRef)(null),
  libRef=(0,d.useRef)(null),
  drvMkRef=(0,d.useRef)(null),
  drvInitRef=(0,d.useRef)(drvPt),
  lblRef=(0,d.useRef)({pkLbl,cuLbl}),
  [y,b]=(0,d.useState)(null),
  [x,S]=(0,d.useState)(()=>u()?`satellite`:`streets`),
  C=(0,d.useRef)(x),
  w=(0,d.useRef)(null);
  C.current=x,drvInitRef.current=drvPt,lblRef.current={pkLbl,cuLbl};
  (0,d.useEffect)(()=>{S(i())},[]);
  (0,d.useEffect)(()=>{w.current?.(x)},[x]);
  let T=e=>{S(e),o(e)},E=/(^|\s)h-/.test(_??``);
  return(0,d.useEffect)(()=>{
    let i=!1,o=null,userMoved=!1,autoFit=!1;
    if(!v.current)return;
    let s=sLat!=null&&sLng!=null?{lat:sLat,lng:sLng}:null,
    c=cLat!=null&&cLng!=null?{lat:cLat,lng:cLng}:null,
    dp=drvInitRef.current;
    if(!s&&!c&&!dp)return void b(`Lokasi belum tersedia.`);
    return b(null),(async()=>{
      try{
        let t=(await r(async()=>{let{default:t}=await import(`./leaflet-src-543Eu7F2.js`).then(t=>e(t.default,1));return{default:t}},__vite__mapDeps([0,1]))).default;
        if(i||!v.current)return;
        libRef.current=t;
        let lbls=lblRef.current,n=[];
        s&&n.push({pos:s,label:lbls.pkLbl,color:`#F29D18`});
        c&&n.push({pos:c,label:lbls.cuLbl,color:`#16a34a`});
        o=t.map(v.current,{zoomControl:iv,attributionControl:!0,dragging:iv,touchZoom:iv,scrollWheelZoom:iv,doubleClickZoom:iv,boxZoom:iv,keyboard:iv});
        mapRef.current=o;
        w.current=a(t,o,C.current,()=>S(`streets`));
        o.on(`dragstart`,()=>{userMoved=!0});
        o.on(`zoomstart`,ev=>{!autoFit&&ev?.originalEvent&&(userMoved=!0)});
        let doFit=pts=>{
          if(i||!o||!pts||!pts.length)return;
          autoFit=!0;
          try{
            pts.length>1?o.fitBounds(pts,{padding:[32,32],animate:!1}):o.setView(pts[0],15,{animate:!1})
          }catch{}
          setTimeout(()=>{autoFit=!1},80)
        };
        let l=[];
        n.forEach(e=>{
          let mk=t.divIcon({html:m(e.color),className:``,iconSize:[16,16],iconAnchor:[8,8]});
          t.marker([e.pos.lat,e.pos.lng],{icon:mk,title:e.label}).addTo(o).bindTooltip(e.label,{direction:`top`,offset:[0,-8]});
          l.push([e.pos.lat,e.pos.lng])
        });
        if(dp){
          let dIco=t.divIcon({html:m(`#124BC2`),className:``,iconSize:[18,18],iconAnchor:[9,9]});
          drvMkRef.current=t.marker([dp.lat,dp.lng],{icon:dIco,title:`🛵 Posisi Kurir`,zIndexOffset:900}).addTo(o).bindTooltip(`🛵 Posisi Kurir`,{direction:`top`,offset:[0,-8]});
          l.push([dp.lat,dp.lng])
        }
        let usedCache=!1;
        if(s&&c){
          let wp=[s,c],pts=wp.map(x=>[x.lat,x.lng]),fb=t.polyline(pts,{color:`#124BC2`,weight:3.5,opacity:.5,dashArray:`6 6`}).addTo(o),
          rk=`gogogo:mini-route:${wp.map(x=>`${x.lat.toFixed(4)},${x.lng.toFixed(4)}`).join(`;`)}`,
          drawRoad=(rp,refit)=>{
            if(i||!o)return;
            try{fb.remove()}catch{}
            t.polyline(rp,{color:`#ffffff`,weight:7.5,opacity:.95,lineJoin:`round`}).addTo(o);
            t.polyline(rp,{color:`#124BC2`,weight:4.5,opacity:.98,lineJoin:`round`}).addTo(o);
            refit&&!userMoved&&doFit(dp?[...rp,[dp.lat,dp.lng]]:rp)
          };
          try{
            let cached=sessionStorage.getItem(rk);
            if(cached){
              let parsed=JSON.parse(cached);
              Array.isArray(parsed)&&parsed.length>1&&(usedCache=!0,drawRoad(parsed,!0))
            }
          }catch{}
          if(!usedCache){
            doFit(l);
            let coords=wp.map(x=>`${x.lng},${x.lat}`).join(`;`),qStr=`?overview=full&geometries=geojson&steps=false`;
            (async()=>{
              for(let base of [`https://router.project-osrm.org/route/v1/driving`,`https://routing.openstreetmap.de/routed-car/route/v1/driving`]){
                try{
                  let res=await fetch(`${base}/${coords}${qStr}`);
                  if(!res.ok)continue;
                  let json=await res.json(),cArr=json?.routes?.[0]?.geometry?.coordinates;
                  if(Array.isArray(cArr)&&cArr.length>1){
                    let rp=cArr.map(([ln,lt])=>[Number(lt),Number(ln)]);
                    try{sessionStorage.setItem(rk,JSON.stringify(rp))}catch{}
                    drawRoad(rp,!0);
                    break
                  }
                }catch{}
              }
            })()
          }
        }else doFit(l);
        setTimeout(()=>{!i&&o&&o.invalidateSize()},60)
      }catch{i||b(`Peta gagal dimuat.`)}
    })(),()=>{
      i=!0,w.current=null,drvMkRef.current=null,mapRef.current=null,libRef.current=null;
      if(o)try{o.remove()}catch{}
    }
  },[sLat,sLng,cLat,cLng,iv]),
  (0,d.useEffect)(()=>{
    let o=mapRef.current,t=libRef.current;
    if(!o||!t)return;
    if(dLat==null||dLng==null){
      if(drvMkRef.current){try{drvMkRef.current.remove()}catch{}drvMkRef.current=null}
      return
    }
    if(drvMkRef.current)drvMkRef.current.setLatLng([dLat,dLng]);
    else{
      let dIco=t.divIcon({html:m(`#124BC2`),className:``,iconSize:[18,18],iconAnchor:[9,9]});
      drvMkRef.current=t.marker([dLat,dLng],{icon:dIco,title:`🛵 Posisi Kurir`,zIndexOffset:900}).addTo(o).bindTooltip(`🛵 Posisi Kurir`,{direction:`top`,offset:[0,-8]})
    }
  },[dLat,dLng]),
  y?(0,f.jsxs)(`div`,{className:`space-y-2 rounded-xl bg-secondary p-3 text-xs text-muted-foreground ${_??``}`,children:[(0,f.jsxs)(`div`,{className:`flex items-start gap-2`,children:[(0,f.jsx)(c,{className:`mt-0.5 size-4 shrink-0 text-warning`}),(0,f.jsx)(`span`,{children:y})]}),h&&(0,f.jsxs)(`a`,{href:h,target:`_blank`,rel:`noopener noreferrer`,className:`inline-flex items-center gap-1 font-semibold text-primary underline`,children:[(0,f.jsx)(s,{className:`size-3.5`}),` `,g]})]}):(0,f.jsxs)(`div`,{className:`relative ${E?``:`h-48`} ${_??``}`,children:[(0,f.jsx)(`div`,{ref:v,className:`h-full w-full overflow-hidden rounded-xl bg-secondary`}),u()&&(0,f.jsx)(l,{mode:x,onChange:T})]})}export{h as t};