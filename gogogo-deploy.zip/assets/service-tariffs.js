import { n as supabase } from "./client-DVq7Iik5.js";
import { n as useQuery, t as queryOptions } from "./queryOptions-kMMPsoVQ.js";

export const SERVICE_TARIFFS_KEY = "service_tariffs";

export const DEFAULT_SERVICE_TARIFFS = {
  appFee: 2000,
  tiers: {
    ride_reg: {
      key: "ride_reg",
      service: "ride",
      label: "Go Riding Reg",
      desc: "Motor reguler harian",
      emoji: "🏍️",
      baseFee: 10000,
      baseMaxKm: 4.2,
      perKm: 1500,
      eta: "10–20 mnt",
      enabled: true
    },
    ride_comfort: {
      key: "ride_comfort",
      service: "ride",
      label: "Go Riding Comfort",
      desc: "Motor besar (PCX / NMAX)",
      emoji: "🛵",
      baseFee: 12000,
      baseMaxKm: 4.2,
      perKm: 1500,
      eta: "10–20 mnt",
      enabled: true
    },
    mobil_reg: {
      key: "mobil_reg",
      service: "car",
      label: "Go Mobil Reg",
      desc: "Mobil kecil (Agya, Ayla, Brio / LCGC)",
      emoji: "🚗",
      seats: "4 penumpang",
      baseFee: 21000,
      baseMaxKm: 4.2,
      perKm: 4000,
      eta: "15–30 mnt",
      enabled: true
    },
    mobil_xl: {
      key: "mobil_xl",
      service: "car",
      label: "Go Mobil XL",
      desc: "Kapasitas 6 penumpang atau bagasi extra",
      emoji: "🚐",
      seats: "6 penumpang / Bagasi+",
      baseFee: 24000,
      baseMaxKm: 4.2,
      perKm: 4000,
      eta: "15–30 mnt",
      enabled: true
    },
    mobil_premium: {
      key: "mobil_premium",
      service: "car",
      label: "Go Mobil Premium",
      desc: "Mobil mewah (Pajero, Innova, dsb)",
      emoji: "🚙",
      seats: "VIP Eksekutif",
      baseFee: 30000,
      baseMaxKm: 4.2,
      perKm: 4000,
      eta: "15–30 mnt",
      enabled: true
    },
    cargo_std: {
      key: "cargo_std",
      service: "cargo",
      label: "Go Cargo",
      desc: "Angkutan barang, toko & pindahan",
      emoji: "🚚",
      baseFee: 60000,
      baseMaxKm: 4.2,
      perKm: 4000,
      eta: "30–60 mnt",
      enabled: true
    },
    suruh_hourly: {
      key: "suruh_hourly",
      service: "suruh",
      label: "Go Suruh",
      desc: "Jasa bantuan belanja, antre & urus keperluan",
      emoji: "🙋",
      baseHourFee: 55000,
      baseMinutes: 60,
      perMinute: 1000,
      eta: "Sesuai durasi",
      enabled: true
    },
    express_base: {
      key: "express_base",
      service: "express",
      label: "Go Express",
      desc: "Kirim dokumen & paket cepat",
      emoji: "📦",
      baseFee: 8000,
      baseMaxKm: 2.0,
      perKm: 3000,
      eta: "45–90 mnt",
      enabled: true
    }
  }
};

export function mergeServiceTariffs(raw) {
  const src = raw && typeof raw === "object" ? raw : {};
  const srcTiers = src.tiers && typeof src.tiers === "object" ? src.tiers : {};
  const tiers = {};
  for (const [k, def] of Object.entries(DEFAULT_SERVICE_TARIFFS.tiers)) {
    const cur = srcTiers[k] && typeof srcTiers[k] === "object" ? srcTiers[k] : {};
    tiers[k] = {
      ...def,
      ...cur,
      key: k,
      service: def.service,
      enabled: typeof cur.enabled === "boolean" ? cur.enabled : def.enabled
    };
    if (k === "suruh_hourly") {
      tiers[k].baseHourFee = Math.max(0, Number(cur.baseHourFee ?? def.baseHourFee));
      tiers[k].baseMinutes = Math.max(15, Number(cur.baseMinutes ?? def.baseMinutes));
      tiers[k].perMinute = Math.max(0, Number(cur.perMinute ?? def.perMinute));
    } else {
      tiers[k].baseFee = Math.max(0, Number(cur.baseFee ?? def.baseFee));
      tiers[k].baseMaxKm = Math.max(0.1, Number(cur.baseMaxKm ?? def.baseMaxKm));
      tiers[k].perKm = Math.max(0, Number(cur.perKm ?? def.perKm));
    }
  }
  return {
    appFee: Math.max(0, Number(src.appFee ?? DEFAULT_SERVICE_TARIFFS.appFee)),
    tiers
  };
}

export function calcDistanceTariff(cfg, distanceKm) {
  const baseFee = Math.max(0, Number(cfg?.baseFee ?? 0));
  const maxKm = Math.max(0.1, Number(cfg?.baseMaxKm ?? 4.2));
  const perKm = Math.max(0, Number(cfg?.perKm ?? 0));
  const km = Math.max(0.1, Number(distanceKm || 0));
  if (km <= maxKm) return Math.round(baseFee);
  return Math.round(baseFee + (km - maxKm) * perKm);
}

export function calcSuruhTariff(cfg, durationMinutes) {
  const baseHourFee = Math.max(0, Number(cfg?.baseHourFee ?? 55000));
  const baseMinutes = Math.max(15, Number(cfg?.baseMinutes ?? 60));
  const perMinute = Math.max(0, Number(cfg?.perMinute ?? 1000));
  const mins = Math.max(baseMinutes, Math.round(Number(durationMinutes || baseMinutes)));
  if (mins <= baseMinutes) return Math.round(baseHourFee);
  return Math.round(baseHourFee + (mins - baseMinutes) * perMinute);
}

export function formatRp(val) {
  const n = Number.isFinite(Number(val)) ? Math.round(Number(val)) : 0;
  return "Rp " + n.toLocaleString("id-ID");
}

export const DIRECT_SERVICE_TYPES = new Set(["express", "ride", "car", "cargo", "suruh"]);

export function isDirectServiceType(ft) {
  return DIRECT_SERVICE_TYPES.has(String(ft || ""));
}

export function getServiceOrderMeta(order) {
  const ft = String(order?.fulfillment_type || "delivery");
  const tierLabel = String(order?.delivery_tier_label || "").trim();
  const tierKey = String(order?.delivery_tier || "");
  if (ft === "ride") {
    const label = tierLabel || (tierKey === "ride_comfort" ? "Go Riding Comfort" : "Go Riding Reg");
    return {
      key: "ride",
      brand: label,
      shortName: "Go Riding",
      emoji: tierKey === "ride_comfort" ? "🛵" : "🏍️",
      badgeClass: "bg-sky-500/15 text-sky-700 dark:text-sky-300",
      pickupLabel: "Arahkan ke Titik Jemput",
      pickupMissing: "Titik jemput belum ada",
      arrivedBtn: "Geser: Tiba di Titik Jemput",
      pickupAction: "Geser: Penumpang Dijemput",
      startAction: "Geser: Mulai Perjalanan",
      routeTo: "/riding",
      isDirect: true
    };
  }
  if (ft === "car") {
    const label = tierLabel || (tierKey === "mobil_premium" ? "Go Mobil Premium" : tierKey === "mobil_xl" ? "Go Mobil XL" : "Go Mobil Reg");
    return {
      key: "car",
      brand: label,
      shortName: "Go Mobil",
      emoji: tierKey === "mobil_xl" ? "🚐" : tierKey === "mobil_premium" ? "🚙" : "🚗",
      badgeClass: "bg-indigo-500/15 text-indigo-700 dark:text-indigo-300",
      pickupLabel: "Arahkan ke Titik Jemput",
      pickupMissing: "Titik jemput belum ada",
      arrivedBtn: "Geser: Tiba di Titik Jemput",
      pickupAction: "Geser: Penumpang Masuk Mobil",
      startAction: "Geser: Mulai Perjalanan",
      routeTo: "/mobil",
      isDirect: true
    };
  }
  if (ft === "cargo") {
    return {
      key: "cargo",
      brand: tierLabel || "Go Cargo",
      shortName: "Go Cargo",
      emoji: "🚚",
      badgeClass: "bg-amber-500/15 text-amber-800 dark:text-amber-300",
      pickupLabel: "Arahkan ke Lokasi Muat",
      pickupMissing: "Lokasi muat belum ada",
      arrivedBtn: "Geser: Tiba di Lokasi Muat",
      pickupAction: "Geser: Barang Dimuat",
      startAction: "Geser: Mulai Angkut Cargo",
      routeTo: "/cargo",
      isDirect: true
    };
  }
  if (ft === "suruh") {
    return {
      key: "suruh",
      brand: tierLabel || "Go Suruh",
      shortName: "Go Suruh",
      emoji: "🙋",
      badgeClass: "bg-purple-500/15 text-purple-700 dark:text-purple-300",
      pickupLabel: "Arahkan ke Lokasi Tugas",
      pickupMissing: "Lokasi tugas belum ada",
      arrivedBtn: "Geser: Tiba di Lokasi Tugas",
      pickupAction: "Geser: Mulai Kerjakan Tugas",
      startAction: "Geser: Tugas Sedang Dijalankan",
      routeTo: "/suruh",
      isDirect: true
    };
  }
  if (ft === "express") {
    return {
      key: "express",
      brand: "Go Express",
      shortName: "Go Express",
      emoji: "📦",
      badgeClass: "bg-orange-500/15 text-orange-700 dark:text-orange-300",
      pickupLabel: "Arahkan ke Titik Jemput",
      pickupMissing: "Titik jemput belum ada",
      arrivedBtn: "Geser: Tiba di Titik Jemput",
      pickupAction: "Geser: Paket Dijemput",
      startAction: "Geser untuk Mulai Antar",
      routeTo: "/express",
      isDirect: true
    };
  }
  if (ft === "pickup") {
    return {
      key: "pickup",
      brand: "Go Makan",
      shortName: "Ambil Sendiri",
      emoji: "🛍️",
      badgeClass: "bg-accent/20 text-accent-foreground",
      pickupLabel: "Arahkan ke Restoran",
      pickupMissing: "Titik restoran belum ada",
      arrivedBtn: "Geser: Tiba di Restoran",
      pickupAction: "Geser untuk Ambil Pesanan",
      startAction: "Geser untuk Mulai Antar",
      routeTo: "/food",
      isDirect: false
    };
  }
  const isMart = order?.restaurants?.merchant_type === "mart";
  return {
    key: "delivery",
    brand: isMart ? "Go Mart" : "Go Makan",
    shortName: isMart ? "Go Mart" : "Go Makan",
    emoji: isMart ? "🛒" : "🍽️",
    badgeClass: "bg-primary/15 text-primary",
    pickupLabel: isMart ? "Arahkan ke Toko" : "Arahkan ke Restoran",
    pickupMissing: isMart ? "Titik toko belum ada" : "Titik restoran belum ada",
    arrivedBtn: isMart ? "Geser: Tiba di Toko" : "Geser: Tiba di Restoran",
    pickupAction: "Geser untuk Ambil Pesanan",
    startAction: "Geser untuk Mulai Antar",
    routeTo: isMart ? "/mart" : "/food",
    isDirect: false
  };
}

export const serviceTariffsQueryOptions = queryOptions({
  queryKey: ["service-tariffs"],
  staleTime: 60000,
  queryFn: async () => {
    try {
      const { data, error } = await supabase
        .from("app_settings")
        .select("value")
        .eq("key", SERVICE_TARIFFS_KEY)
        .maybeSingle();
      if (error) throw error;
      return mergeServiceTariffs(data?.value);
    } catch {
      return DEFAULT_SERVICE_TARIFFS;
    }
  }
});

export function useServiceTariffs() {
  const q = useQuery(serviceTariffsQueryOptions);
  return {
    tariffs: q.data ?? DEFAULT_SERVICE_TARIFFS,
    loading: q.isLoading,
    refetch: q.refetch
  };
}
